﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ViewModels.Merchandises
{
    public class IndexViewModel
    {
        //Filter
        public List<FilterStatus> FilterStatus { get; set; }
        public List<FilterVendor> FilterVendor { get; set; }
        public List<FilterCategory> FilterCategory { get; set; }

        //Grid
        public List<MerchandiseViewModel> List { get; set; }

        //Drop down list
        public IEnumerable<SelectListItem> ListStatus { get; set; }
        public IEnumerable<SelectListItem> ListVendor { get; set; }
        public IEnumerable<SelectListItem> ListCategory { get; set; }

        //Process result message
        public string Message { get; set; }
    }
}
