﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.Remarkss
{
    public class RemarksViewModel
    {
        public string RemarksNo { get; set; }
        public string Remarks { get; set; }
        public string SuggestDocNo { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public Boolean IsActive { get; set; }

        //Add for Form
        public string FileName { get; set; }
    }
}