﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.UserGroups
{
    public class UserGroupViewModel
    {
        public string UserGroupNo { get; set; }
        public string GroupName { get; set; }
        public string Description { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public Boolean IsActive { get; set; }
    }
}
