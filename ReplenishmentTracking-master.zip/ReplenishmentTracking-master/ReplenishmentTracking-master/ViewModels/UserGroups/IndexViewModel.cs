﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.UserGroups
{
    public class IndexViewModel
    {
        //Grid
        public List<UserGroupViewModel> List { get; set; }

        //Process result message
        public string Message { get; set; }
    }
}
