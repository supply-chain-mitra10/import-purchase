﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ViewModels.Reports
{
    public class IndexReportViewModel
    {
        //Drop down list
        public IEnumerable<SelectListItem> ListVendor { get; set; }
        public IEnumerable<SelectListItem> ListCategory { get; set; }

        //Process result message
        public string Message { get; set; }
    }
}
