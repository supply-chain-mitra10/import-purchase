﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace ViewModels.Users
{
    public class UserViewModel
    {
        public string UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string NIK { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Password { get; set; }
        public Byte? InvalidLogin { get; set; }
        public Byte? Status { get; set; }
        public DateTime? JoinAt { get; set; }
        public DateTime? ExpiredAt { get; set; }
        public string UserGroupNo { get; set; }
        public string CompanyNo { get; set; }
        public string BranchNo { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }

        //Drop down list
        public IEnumerable<SelectListItem> ListCompany { get; set; }
        public IEnumerable<SelectListItem> ListLocation { get; set; }
    }
}
