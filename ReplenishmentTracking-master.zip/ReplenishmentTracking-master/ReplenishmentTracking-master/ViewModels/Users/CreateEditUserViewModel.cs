﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.Users
{
    public class CreateEditUserViewModel
    {
        public int Id { get; set; }
        public string UserID { get; set; }
        public string Username { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Email can not empty!")]
        [EmailAddress(ErrorMessage = "Email is not Valid!")]
        public string Email { get; set; }
        public string Phone { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Password can not empty!")]
        public string Password { get; set; }
        public string Role { get; set; }
        public string DeviceID { get; set; }
        public string RefreshToken { get; set; }
        public int? InvalidLogin { get; set; }
        public int? Status { get; set; }
        public DateTime? JoinAt { get; set; }
        public DateTime ExpiredAt { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string CreatedBy { get; set; }
        public Boolean IsActive { get; set; }
      
    }
}
