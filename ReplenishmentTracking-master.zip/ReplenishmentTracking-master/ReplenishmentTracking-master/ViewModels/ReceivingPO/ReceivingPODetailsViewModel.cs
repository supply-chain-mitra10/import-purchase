﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.ReceivingPO
{
    public class ReceivingPODetailsViewModel
    {
        public string PurchaseOrderNo { get; set; }
        public string Comment { get; set; }
        public DateTime PostingDate { get; set; }
        public string VendorInvNo { get; set; }
        public string GRNo { get; set; }
        public string UOM { get; set; }
        public string SubCategory { get; set; }
        public string Brand { get; set; }
        public int Quantity { get; set; }
        public string VendorNo { get; set; }
        public string MasterBrand { get; set; }
        public string ItemNo { get; set; }
        public char AuditActivity { get; set; }
        public DateTime? AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }
    }
}
