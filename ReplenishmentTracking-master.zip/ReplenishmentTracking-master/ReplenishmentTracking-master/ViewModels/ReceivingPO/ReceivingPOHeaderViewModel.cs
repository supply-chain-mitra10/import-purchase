﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.ReceivingPO
{
    public class ReceivingPOHeaderViewModel
    {
        public string ReceivingPONo { get; set; }
        public string PurchaseOrderNo { get; set; }
        public string Type { get; set; }
        public string SiteNo { get; set; }
        public string Category { get; set; }
        public char AuditActivity { get; set; } 
        public DateTime? AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }
    }
}
