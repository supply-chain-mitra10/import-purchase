﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.Imports
{
    public class CreateEditImportViewModel
    {
        public string SuggestDocNo { get; set; }
        public string FileName { get; set; }
        public string FileType { get; set; }
        public string FilePath { get; set; }
        public string Extension { get; set; }
        public int? Size { get; set; }
        public string Category { get; set; }
        public string Vendor { get; set; }
        public string SuggestDocStatus { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }
    }
}
