﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.Imports
{
    public class FilterVendor
    {
        public int IdVendor { get; set; }
        public string NameVendor { get; set; }
    }
}
