﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.ProformaInvoices
{
    public class CreateEditProformaInvoiceDetailsViewModel
    {
        public string ProformaInvoiceNo { get; set; }
        public string ItemNo { get; set; }
        public string VendorItemCode { get; set; }
        public string HSCode { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public decimal TotalCBM { get; set; }
        public decimal UnitPrice { get; set; }
        public string CurrencyCodeLocale { get; set; }
        public decimal CurrencyAmountLocale { get; set; }
        public decimal CurrentRateLocale { get; set; }
        public string CurrencyCodeOther { get; set; }
        public decimal CurrencyAmountOther { get; set; }
        public decimal CurrentRateOther { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }
    }
}
