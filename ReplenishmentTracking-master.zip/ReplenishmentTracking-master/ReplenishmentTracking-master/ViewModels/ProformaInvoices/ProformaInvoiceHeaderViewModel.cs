﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.ProformaInvoices
{
    public class ProformaInvoiceHeaderViewModel
    {
        public string ProformaInvoiceNo { get; set; }
        public DateTime ProformaInvoiceDate { get; set; }
        public string PIPath { get; set; }
        public string VendorPIPath { get; set; }
        public Boolean VendorPIUploaded { get; set; }
        public string QuotationNo { get; set; }
        public string VendorNo { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }
    }
}