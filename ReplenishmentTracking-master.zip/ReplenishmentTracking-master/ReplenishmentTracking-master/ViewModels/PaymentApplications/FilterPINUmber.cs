﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.PaymentApplications
{
    public class FilterPINUmber
    {
        public int IdPINo { get; set; }
        public string PINumber { get; set; }
    }
}
