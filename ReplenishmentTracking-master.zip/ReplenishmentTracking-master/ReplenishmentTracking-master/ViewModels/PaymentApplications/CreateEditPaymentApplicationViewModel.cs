﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ViewModels.PaymentApplications
{
    public class CreateEditPaymentApplicationViewModel
    {
        public string PaymentAppNo { get; set; }
        public DateTime PaymentDate { get; set; }
        public string Division { get; set; }
        public string PaymentReceiver { get; set; }
        public decimal Amount { get; set; }
        public string AmountText { get; set; }
        public string CurrencyCodeLocale { get; set; }
        public decimal CurrencyAmountLocale { get; set; }
        public decimal CurrentRateLocale { get; set; }
        public string CurrencyCodeOther { get; set; }
        public decimal CurrencyAmountOther { get; set; }
        public decimal CurrentRateOther { get; set; }
        public string Notes { get; set; }
        public string PaymentTypeNo { get; set; }
        public string PurchaseOrderNo { get; set; }
        public string Forwarder { get; set; }
        public string Party { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string ApprovedBy { get; set; }
        public string AgreedBy { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }

        //Drop down list
        public IEnumerable<SelectListItem> ListPI { get; set; }
        public IEnumerable<SelectListItem> ListPO { get; set; }

    }
}
