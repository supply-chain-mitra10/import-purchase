﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.PaymentApplications
{
    public class FilterPONumber
    {
        public int IdPONo { get; set; }
        public string PONumber { get; set; }
    }
}
