﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.PurchaseOrders
{
    public class FilterSuggest
    {
        public int IdFile { get; set; }
        public string FileCode { get; set; }
    }
}
