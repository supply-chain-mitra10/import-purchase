﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ViewModels.PurchaseOrders
{
    public class IndexPOViewModel
    {
        //Filter
        public List<FilterVendor> FilterVendor { get; set; }
        public List<FilterSuggest> FilterSuggest { get; set; }

        //Grid
        public List<CreateEditPurchaseOrderViewModel> List { get; set; }

        //Drop down list
        public IEnumerable<SelectListItem> ListVendor { get; set; }
        public IEnumerable<SelectListItem> ListSuggest { get; set; }

        //Process result message
        public string Message { get; set; }
    }
}
