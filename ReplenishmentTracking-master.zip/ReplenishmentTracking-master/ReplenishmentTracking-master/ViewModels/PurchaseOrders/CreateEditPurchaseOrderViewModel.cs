﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.PurchaseOrders
{
    public class CreateEditPurchaseOrderViewModel
    {
        //Header
        public string PurchaseOrderNo { get; set; }
        public DateTime PurchaseOrderDate { get; set; }
        public string TermOfPayment { get; set; }
        public DateTime? LeadTimeDeliveryExpire { get; set; }
        public DateTime? PODateExpire { get; set; }
        public string POPath { get; set; }
        public DateTime? EstimationDate { get; set; }
        public DateTime? EstimationArrival { get; set; }
        public string SPPBNo { get; set; }
        public DateTime? ETDInputDate { get; set; }
        public string ETDInputBy { get; set; }
        public DateTime? ETAInputDate { get; set; }
        public string ETAInputBy { get; set; }
        public DateTime? SPPBInputDate { get; set; }
        public string SPPBInputBy { get; set; }
        public string VendorNo { get; set; }
        public string SiteNo { get; set; }
        public string ProformaInvoiceNo { get; set; }
        public string ReceivingPONo { get; set; }

        //Detail
        public string ItemNo { get; set; }
        public string LV { get; set; }
        public string UOM { get; set; }
        public int? QuantityOrder { get; set; }
        public decimal? UnitPrice { get; set; }
        public bool? Extra { get; set; }
        public decimal? Discount { get; set; }
        public decimal? Total { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }

        //Add for View
        public string SuggestDocNo { get; set; }
    }
}
