﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.PurchaseOrders
{
    public class PurchaseOrderDetailsViewModel
    {
        public string PurchaseOrderNo { get; set; }
        public string ItemNo { get; set; }
        public string LV { get; set; }
        public string UOM { get; set; }
        public int QuantityOrder { get; set; }
        public decimal UnitPrice { get; set; }
        public Boolean Extra { get; set; }
        public decimal Discount { get; set; }
        public decimal Total { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }
    }
}
