﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.PurchaseOrders
{
    public class ExcelPurchaseOrder
    {
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string PONumber { get; set; }
    }
}
