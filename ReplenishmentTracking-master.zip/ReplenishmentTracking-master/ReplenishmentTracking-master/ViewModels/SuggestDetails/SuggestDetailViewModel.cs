﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.Imports
{
    public class SuggestDetailViewModel
    {
        public string SuggestDocNo { get; set; }
        public string SiteNo { get; set; }
        public string SiteName { get; set; }
        public string VendorNo { get; set; }
        public string VendorName { get; set; }
        public string MasterBrand { get; set; }
        public string ItemNo { get; set; }
        public string ItemName { get; set; }
        public string Category { get; set; }
        public decimal? SystemSuggestQty { get; set; }
        public decimal? AverageSales { get; set; }
        public int? LeadTime { get; set; }
        public int? HighestAvgLeadTimeActual { get; set; }
        public decimal? SafetyStockDays { get; set; }
        public decimal? OrderPeriod { get; set; }
        public decimal? MinimumStock { get; set; }
        public decimal? MaximumStock { get; set; }
        public int? ReorderPoint { get; set; }
        public int? OptimumMax { get; set; }
        public int? OptimumMaxMultiple { get; set; }
        public decimal? StockOnHand { get; set; }
        public decimal? OutstandingPO { get; set; }
        public decimal? OutstandingTR { get; set; }
        public decimal? OutstandingTO { get; set; }
        public int? MultiplePurchaseQty { get; set; }
        public int? OutstandingTRfromOtherStore { get; set; }
        public decimal? CalculatedSuggest { get; set; }
        public decimal? CalculatedStockDaysSuggest { get; set; }
        public decimal? CalculatedTotalStockDays { get; set; }
        public decimal? ReviseMDSuggest { get; set; }
        public decimal? ReviseMDStockDaysSuggest { get; set; }
        public decimal? ReviseMDTotalStockDays { get; set; }
        public decimal? TotalSuggest { get; set; }
        public int? ICSuggest_TotalQty { get; set; }
        public decimal? ICSuggest_QtyCBM { get; set; }
        public decimal? ICSuggest_TotalCBM { get; set; }
        public int? MDRevise_TotalQty { get; set; }
        public decimal? MDRevise_QtyCBM { get; set; }
        public decimal? MDRevise_TotalCBM { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public Boolean IsActive { get; set; }
    }
}
