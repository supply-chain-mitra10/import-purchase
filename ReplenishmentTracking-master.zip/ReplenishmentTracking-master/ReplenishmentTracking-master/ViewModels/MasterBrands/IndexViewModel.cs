﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.MasterBrands
{
    public class IndexViewModel
    {
        //Grid
        public List<MasterBrandViewModel> List { get; set; }

        //Process result message
        public string Message { get; set; }
    }
}
