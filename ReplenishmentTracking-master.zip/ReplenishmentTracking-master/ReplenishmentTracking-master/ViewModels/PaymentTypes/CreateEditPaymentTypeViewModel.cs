﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.PaymentTypes
{
    public class CreateEditPaymentTypeViewModel
    {
        public string PaymentTypeNo { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public byte PaymentPart { get; set; }
        public string AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }
    }
}
