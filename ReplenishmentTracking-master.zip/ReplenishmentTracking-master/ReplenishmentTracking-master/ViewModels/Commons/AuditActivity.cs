﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.Commons
{
    public static class AuditActivity
    {
        public const string Insert = "I";
        public const string Update = "U";
        public const string Delete = "D";
    }
}
