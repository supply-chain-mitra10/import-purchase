﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.Commons
{
    public static class SuggestDocStatus
    {
        public const string New = "New";
        public const string Reject = "Reject";
        public const string WaitingICApproval = "Waiting IC Approval";
        public const string Confirm = "Confirm";
        public const string Open = "Open";
        public const string Revise = "Revise";
        public const string Close = "Close";
        public const string ApprovedbyMD = "Approved by MD";
        public const string OpenImport = "Open Import";
        public const string PaymentLC = "Payment LC";
        public const string SubmittoFinance = "Submit to Finance";
        public const string ReceivefromFinance = "Receive from Finance";
        public const string Release = "Release";
        public const string GoodsReceived = "Goods Received";
    }
}
