﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.Items
{
    public class IndexViewModel
    {
        //Grid
        public List<ItemViewModel> List { get; set; }

        //Process result message
        public string Message { get; set; }
    }
}
