﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.MenuCategorys
{
    public class IndexViewModel
    {
        //Grid
        public List<MenuCategoryViewModel> List { get; set; }

        //Process result message
        public string Message { get; set; }
    }
}
