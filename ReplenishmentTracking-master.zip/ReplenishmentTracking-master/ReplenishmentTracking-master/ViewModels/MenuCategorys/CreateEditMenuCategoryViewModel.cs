﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.MenuCategorys
{
    public class CreateEditMenuCategoryViewModel
    {
        public string MenuCategoryNo { get; set; }
        public string MenuCategoryName { get; set; }
        public char AuditActivity { get; set; }
        public DateTime AuditDateTime { get; set; }
        public string AuditUsername { get; set; }
        public bool IsActive { get; set; }
    }
}
