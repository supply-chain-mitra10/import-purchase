﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ViewModels.InventoryControls
{
    public class DetailInventoryControlViewModel
    {
        public long Id { get; set; }
        public string Code { get; set; }
        public string FileName { get; set; }     
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UploadDate { get; set; }
        public string UploadBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public long? Sequence { get; set; }
        public string Category { get; set; }
        public string Vendor { get; set; }
        public string Status { get; set; }
        public bool? ApproveByIC { get; set; }
        public bool? ApproveByMD { get; set; }
        public bool? RejectByIC { get; set; }
        public bool? RejectByMD { get; set; }
        public DateTime? Timestamp { get; set; }
        public bool? IsActive { get; set; }
    }
}
