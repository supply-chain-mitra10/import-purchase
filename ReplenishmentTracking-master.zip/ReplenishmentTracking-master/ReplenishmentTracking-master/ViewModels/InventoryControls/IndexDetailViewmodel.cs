﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.InventoryControls
{
    public class IndexDetailViewmodel
    {
        //Grid
        public List<DetailInventoryControlViewModel> ListDetail { get; set; }

        //Process result message
        public string Message { get; set; }
    }
}
