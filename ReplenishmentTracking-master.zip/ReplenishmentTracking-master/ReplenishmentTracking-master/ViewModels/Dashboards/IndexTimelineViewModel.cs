﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ViewModels.Dashboards
{
    public class IndexTimelineViewModel
    {
        //Grid
        public List<TimelineViewModel> List { get; set; }

        //Drop down list
        public IEnumerable<SelectListItem> ListStatus { get; set; }
        public IEnumerable<SelectListItem> ListVendor { get; set; }
        public IEnumerable<SelectListItem> ListCategory { get; set; }

        //Process result message
        public string Message { get; set; }
    }
}
