﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModels.Dashboards
{
    public class DashboardViewModel
    {
        public int Id { get; set; }
        public string Department { get; set; }
        public int TotalNew { get; set; }
        public int TotalOpen { get; set; }
        public int TotalReject { get; set; }
        public int TotalConfirm { get; set; }
        public int TotalApprove { get; set; }
        public int TotalRevise { get; set; }
        public int TotalRelease { get; set; }
        public int TotalClose { get; set; }
        public int TotalWait { get; set; }
        public int TotalOpenIM { get; set; }
        public int TotalSubmit { get; set; }
        public int TotalReturn { get; set; }
        public int TotalLC { get; set; }
        public int TotalReceived { get; set; }
        public string[] Status { get; set; }
        public string Notes { get; set; }

    }
}
