﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ViewModels.Dashboards
{
    public class TimelineViewModel
    {
        //Stored Procedure : sp_TimelineFile
        public int ID { get; set; }
        public string History_Tracking { get; set; }
        public int Interval { get; set; }
        
    }
}
