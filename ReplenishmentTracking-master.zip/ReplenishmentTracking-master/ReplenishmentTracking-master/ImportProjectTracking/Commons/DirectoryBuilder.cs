﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;

namespace ImportProjectTracking.Commons
{
    public class DirectoryBuilder
    {
        private static string DIR_IPTIC = ConfigurationManager.AppSettings["PathIPT-IC"];
        private static string DIR_IPTMD = ConfigurationManager.AppSettings["PathIPT-MD"];
        private static string DIR_IPTIMPORT = ConfigurationManager.AppSettings["PathIPT-Import"];
        private static string DIR_IPTPI = ConfigurationManager.AppSettings["PathIPT-PI"];
        private static string DIR_IPTPO = ConfigurationManager.AppSettings["PathIPT-PO"];
        private static string DIR_IPTIMAGES = ConfigurationManager.AppSettings["PathIPT-Images"];
        private static string DIR_IPTDC = ConfigurationManager.AppSettings["PathIPT-DC"];
        private static string DIR_ICUPLOAD = ConfigurationManager.AppSettings["PathICUpload"];
        private static string DIR_ICDOWNLOAD = ConfigurationManager.AppSettings["PathICDownload"];
        private static string DIR_MDUPLOAD = ConfigurationManager.AppSettings["PathMDUpload"];
        private static string DIR_MDDOWNLOAD = ConfigurationManager.AppSettings["PathMDDownload"];
        private static string DIR_MDPI = ConfigurationManager.AppSettings["PathMDPI"];
        private static string DIR_MDPO = ConfigurationManager.AppSettings["PathMDPO"];
        private static string DIR_MDIMAGES = ConfigurationManager.AppSettings["PathMDImages"];
        private static string DIR_IMPORTUPLOAD = ConfigurationManager.AppSettings["PathImportUpload"];
        private static string DIR_IMPORTDOWNLOAD = ConfigurationManager.AppSettings["PathImportDownload"];      
        private static string DIR_IMPORTDOWNPIFEE = ConfigurationManager.AppSettings["PathImportDownloadWithFeePI"];
        private static string DIR_IMPORTDOWNPIWHFEE = ConfigurationManager.AppSettings["PathImportDownloadWithoutFeePI"];
        private static string DIR_IMPORTDOWNPOFEE = ConfigurationManager.AppSettings["PathImportDownloadWithFeePO"];
        private static string DIR_IMPORTDOWNPOWHFEE = ConfigurationManager.AppSettings["PathImportDownloadWithoutFeePO"];
        private static string DIR_DCUPLOAD = ConfigurationManager.AppSettings["PathDCUpload"];
        private static string DIR_DCDOWNLOAD = ConfigurationManager.AppSettings["PathDCDownload"];
        private static string DIR_IPTHISTIC = ConfigurationManager.AppSettings["PathIPTHist-IC"];
        private static string DIR_IPTHISTMD = ConfigurationManager.AppSettings["PathIPTHist-MD"];
        private static string DIR_IPTHISTIMPORT = ConfigurationManager.AppSettings["PathIPTHist-Import"];
        private static string DIR_IPTHISTDC = ConfigurationManager.AppSettings["PathIPTHist-DC"];

        public static void CreateDirectoryIPT()
        {
            Directory.CreateDirectory(DIR_IPTIC);
            Directory.CreateDirectory(DIR_IPTMD);
            Directory.CreateDirectory(DIR_IPTIMPORT);
            Directory.CreateDirectory(DIR_IPTPI);
            Directory.CreateDirectory(DIR_IPTPO);
            Directory.CreateDirectory(DIR_IPTIMAGES);
            Directory.CreateDirectory(DIR_IPTDC);
            Directory.CreateDirectory(DIR_ICUPLOAD);
            Directory.CreateDirectory(DIR_ICDOWNLOAD);
            Directory.CreateDirectory(DIR_MDUPLOAD);
            Directory.CreateDirectory(DIR_MDDOWNLOAD);
            Directory.CreateDirectory(DIR_MDPI);
            Directory.CreateDirectory(DIR_MDPO);
            Directory.CreateDirectory(DIR_MDIMAGES);
            Directory.CreateDirectory(DIR_IMPORTUPLOAD);
            Directory.CreateDirectory(DIR_IMPORTDOWNLOAD);
            Directory.CreateDirectory(DIR_IMPORTDOWNPIFEE);
            Directory.CreateDirectory(DIR_IMPORTDOWNPIWHFEE);
            Directory.CreateDirectory(DIR_IMPORTDOWNPOFEE);
            Directory.CreateDirectory(DIR_IMPORTDOWNPOWHFEE);
            Directory.CreateDirectory(DIR_DCUPLOAD);
            Directory.CreateDirectory(DIR_DCDOWNLOAD);
            Directory.CreateDirectory(DIR_IPTHISTIC);
            Directory.CreateDirectory(DIR_IPTHISTMD);
            Directory.CreateDirectory(DIR_IPTHISTIMPORT);
            Directory.CreateDirectory(DIR_IPTHISTDC);
        }

    }
}
