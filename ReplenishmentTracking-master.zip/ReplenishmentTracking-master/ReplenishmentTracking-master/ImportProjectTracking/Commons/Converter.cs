﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ImportProjectTracking.Commons
{
    public class Converter
    {
        //Get Byte value from File
        public static byte[] GetByteFromFile(string fPath)
        {
            // get all the bytes of the file into memory  
            byte[] fContents = File.ReadAllBytes(fPath);
            return fContents;
        }

    }
}
