﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ImportProjectTracking.ReportViewer
{
    public partial class OutstandingPO : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                RenderReport();
            }
        }

        private void RenderReport()
        {
            DataTable dt = GetSPdata();
            OutstandingPOReportViewer.ProcessingMode = ProcessingMode.Local;
            OutstandingPOReportViewer.LocalReport.ReportPath = Server.MapPath("~/Report/RDLC/Rpt_OutstandingPO.rdlc");

            OutstandingPOReportViewer.LocalReport.DataSources.Clear();
            OutstandingPOReportViewer.LocalReport.DataSources.Add(new ReportDataSource("OutstandingPO", dt));

            //Add Report Parameter
            //OutstandingPOReportViewer.LocalReport.SetParameters(new Microsoft.Reporting.WebForms.ReportParameter("",""));
        }

        private DataTable GetSPdata()
        {
            DataTable resultTable = new DataTable();

            string cnnString = ConfigurationManager.ConnectionStrings["IMPORTPURCHASE"].ConnectionString;
            SqlConnection cnn = new SqlConnection(cnnString);
            SqlCommand cmd = new SqlCommand();

            try
            {
                cmd.Connection = cnn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "rpt_OutstandingPO";
                cmd.Parameters.Add(new SqlParameter("@FileID", null )); //@FileID null = All Analysis file
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(resultTable);
            }
            catch (Exception ex)
            {
                throw ex;
            }  

            return resultTable;
        }

    }
}