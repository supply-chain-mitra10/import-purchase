﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Providers.PurchaseOrders;

namespace ImportProjectTracking.ReportViewer
{
    public partial class IMPORT_POWithoutFee : System.Web.UI.Page
    {
        private PurchaseOrderRepository repository = new PurchaseOrderRepository();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                string param1 = "";
                if (Request.QueryString["IdFile"] != null)
                {
                    param1 = Request.QueryString["IdFile"].ToString();
                }
                string[] files = param1.Split(';');

                foreach (var item in files)
                {
                    if (item != "" && item != null && item != "true")
                    {
                        RenderReport(item);
                    }
                }
            }
        }

        private void RenderReport(string filesCode)
        {
            //Get file code for SP parameter
            var dataFile = repository.GetFileByDocNo(filesCode);

            DataTable dt = GetSPdata(dataFile.SuggestDocNo);
            IMPORTPOWHFeeReportViewer.ProcessingMode = ProcessingMode.Local;
            IMPORTPOWHFeeReportViewer.LocalReport.ReportPath = Server.MapPath("~/Report/RDLC/IMPORT_POWithoutFee.rdlc");

            IMPORTPOWHFeeReportViewer.LocalReport.DataSources.Clear();
            IMPORTPOWHFeeReportViewer.LocalReport.DataSources.Add(new ReportDataSource("POWithoutFee", dt));
        }

        private DataTable GetSPdata(string fCode)
        {
            DataTable resultTable = new DataTable();

            string cnnString = ConfigurationManager.ConnectionStrings["IMPORTPURCHASE"].ConnectionString;
            SqlConnection cnn = new SqlConnection(cnnString);
            SqlCommand cmd = new SqlCommand();

            try
            {
                cmd.Connection = cnn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_IMPORT_POWithoutFee";
                cmd.Parameters.Add(new SqlParameter("@FileCode", fCode));
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(resultTable);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultTable;
        }

    }
}