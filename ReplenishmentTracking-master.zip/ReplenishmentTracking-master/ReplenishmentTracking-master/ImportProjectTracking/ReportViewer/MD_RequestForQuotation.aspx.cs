﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Providers.Merchandises;

namespace ImportProjectTracking.ReportViewer
{
    public partial class MD_Quotation : System.Web.UI.Page
    {
        private MerchandiseRepository repository = new MerchandiseRepository();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                string param1 = "";
                if (Request.QueryString["SuggestDocNo"] != null)
                {
                    param1 = Request.QueryString["SuggestDocNo"].ToString();
                }
                string[] files = param1.Split(';');

                foreach (var item in files)
                {
                    if (item != "" && item != null && item != "true")
                    {
                        RenderReport(item);
                    }
                }
            }
        }

        private void RenderReport(string filesCode)
        {
            //Get file code for SP parameter
            var dataFile = repository.GetFileByDocNo(filesCode);

            DataTable dt = GetSPdata(dataFile.SuggestDocNo);
            MDQuotationReportViewer.ProcessingMode = ProcessingMode.Local;
            MDQuotationReportViewer.LocalReport.ReportPath = Server.MapPath("~/Report/RDLC/MD_RequestForQuotation.rdlc");

            MDQuotationReportViewer.LocalReport.DataSources.Clear();
            MDQuotationReportViewer.LocalReport.DataSources.Add(new ReportDataSource("Quotation", dt));
        }

        private DataTable GetSPdata(string docNo)
        {
            DataTable resultTable = new DataTable();

            string cnnString = ConfigurationManager.ConnectionStrings["REPLENISHMENTConnectionString"].ConnectionString;
            SqlConnection cnn = new SqlConnection(cnnString);
            SqlCommand cmd = new SqlCommand();

            try
            {
                cmd.Connection = cnn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_MD_RequestForQuotation";
                cmd.Parameters.Add(new SqlParameter("@DocNo", docNo)); //@DocNo null = All Analysis file
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(resultTable);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultTable;
        }
    }
}