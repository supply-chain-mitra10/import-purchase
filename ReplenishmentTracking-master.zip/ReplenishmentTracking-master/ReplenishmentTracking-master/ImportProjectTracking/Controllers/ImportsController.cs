﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using Providers.Imports;
using Providers.PurchaseOrders;
using Providers.Remarkss;
using ViewModels.Imports;
using ViewModels.PurchaseOrders;
using ViewModels.PaymentApplications;
using ViewModels.Dashboards;
using ViewModels.ProcessResult;
using ViewModels.Remarkss;
using ImportProjectTracking.Commons;
using Providers.PaymentApplications;
using Providers.ProformaInvoices;

namespace ImportProjectTracking.Controllers
{
    public class ImportsController : Controller
    {
        private ImportBussinessLogic bussinessLogic = new ImportBussinessLogic();
        private ProformaInvoiceBussinessLogic bussinessLogicPI = new ProformaInvoiceBussinessLogic();
        private PurchaseOrderBussinessLogic bussinessLogicPO = new PurchaseOrderBussinessLogic();
        private PaymentApplicationBussinessLogic bussinessLogicPA = new PaymentApplicationBussinessLogic();
        private RemarksBussinessLogic bussinessLogicRemark = new RemarksBussinessLogic();
        private ProcessResult result = new ProcessResult();
        public string flag = "0";

        // GET: Imports
        [Authorize]
        [OutputCacheAttribute(VaryByParam = "*", Duration = 0, NoStore = true)]
        public ActionResult Index(string message)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.ListPayment = bussinessLogic.GetListPayment();
            viewModel.Message = message;

            return View(viewModel);
        }

        //Details PO
        public ActionResult DetailsPO(string IdParam, string PoNumber)
        {
            CreateEditPurchaseOrderViewModel viewModel = new CreateEditPurchaseOrderViewModel();
            viewModel = bussinessLogicPO.GetPODetails(IdParam, PoNumber);
            ViewBag.Title = "Purchase Order Details";
            ViewBag.Header = "Purchase Order Details";

            return View("DetailsPO", viewModel);
        }

        //Files Timeline
        public ActionResult FilesTimeline(string IdParam)
        {
            var viewModel = new IndexTimelineViewModel();
            viewModel.List = bussinessLogic.ListTimeline(IdParam);
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View(viewModel);
        }

        //Menu Payment Import
        public ActionResult IndexPayment(string IdParam)
        {
            var viewModel = new IndexPOViewModel();
            viewModel.List = bussinessLogicPO.List(IdParam);
            viewModel.ListSuggest = bussinessLogic.GetListSuggest();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            return View(viewModel);
        }

        //Update process for Payment later after Receive
        public ActionResult PaymentLater(string IdParam)
        {
            flag = "7"; //7 = Payment Later

            string[] files = IdParam.Split(';');
            result = bussinessLogic.PayLater(files, flag, Session["UserID"].ToString());

            //Get Model for Index
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

        //Submit process for send to Finance Dept
        public ActionResult SubmitFinance(string IdParam)
        {
            flag = "4"; //4 = submit to finance

            string[] files = IdParam.Split(';');
            result = bussinessLogic.SubmitToFinance(files, flag, Session["UserID"].ToString());

            //Get Model for Index
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

        //Update process for Receive from Finance Dept
        public ActionResult ReceiveFinance(string IdParam)
        {
            flag = "5"; //5 = Receive from Finance

            string[] files = IdParam.Split(';');
            result = bussinessLogic.ReceiveFromFinance(files, flag, Session["UserID"].ToString());

            //Get Model for Index
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

        //Update Payment process for Return from Finance
        public ActionResult UpdatePayment(CreateEditPurchaseOrderViewModel model)
        {
            flag = "6"; //6 = Update Payment

            //Save Updated payment info
            result = bussinessLogicPO.SavePO(model, flag, "", "", "", Session["UserID"].ToString());

            //Get Model for Index
            var viewModel = new IndexPOViewModel();
            viewModel.List = bussinessLogicPO.List(model.PurchaseOrderNo);
            viewModel.ListSuggest = bussinessLogic.GetListSuggest();
            viewModel.ListVendor = bussinessLogic.GetListVendor();

            return View("IndexPayment", viewModel);
        }

        //Save Payment Application form
        public ActionResult SavePayApplication(CreateEditPaymentApplicationViewModel model)
        {
            flag = "8"; //8 = Save Payment Application form

            if (model.PurchaseOrderNo != "" && model.PurchaseOrderNo != null)
            {
                result = bussinessLogicPA.SavePAbyPO(model, Session["UserID"].ToString());
            }
            //else if (model.PINUmber != "" && model.PINUmber != null)
            //{
            //    result = bussinessLogicPA.SavePAbyPI(model, Session["UserID"].ToString());
            //}

            //Get Model for Index
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

        //Approval process for Release Purchase Import
        public ActionResult ReleaseFile(string IdParam)
        {
            flag = "2";
            string[] files = IdParam.Split(';');

            //Get Model for Index
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    var modelRelease = new ImportViewModel();
                    modelRelease = bussinessLogic.GetFileDet(item);
                    result = bussinessLogic.SaveFile(modelRelease, flag, Session["UserID"].ToString());
                }
            }

            return View("Index", viewModel);
        }

        //Revise process by Import
        public ActionResult RevisePI(string IdParam)
        {
            flag="3"; //3 = Revise
            string[] files = IdParam.Split(';');

            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            //Set Revise PI and PO
            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    result = bussinessLogic.GetRevise(item, flag, Session["UserID"].ToString());
                    ViewBag.Error = result.Message;
                }
            }

            return View("Index", viewModel);
        }

        //Index Create Payment Application
        public ActionResult GetPayApplication()
        {
            var viewModel = bussinessLogicPA.GetCreateEditPaymentApp();
            viewModel.ListPI = bussinessLogicPI.GetListPI();
            viewModel.ListPO = bussinessLogicPO.GetListPO();
            ViewBag.Title = "Form Payment Application";
            ViewBag.Header = "Form Payment Application";

            return View("PaymentApplication", viewModel);
        }

        //Index Input Estimation Date
        public ActionResult InputETD(string IdParam)
        {
            string[] files = IdParam.Split(';');

            var viewModel = bussinessLogicPO.GetCreateEditPayment(files);
            ViewBag.Title = "Input Estimation Date";
            ViewBag.Header = "Input Estimation Date";

            return PartialView("InputETD", viewModel);
        }

        //Index Input Estimation Arrival
        public ActionResult InputETA(string IdParam)
        {
            string[] files = IdParam.Split(';');

            var viewModel = bussinessLogicPO.GetCreateEditPayment(files);
            ViewBag.Title = "Input Estimation Arrival";
            ViewBag.Header = "Input Estimation Arrival";

            return PartialView("InputETA", viewModel);
        }

        //Index Input SPPB Number
        public ActionResult InputSPPB(string IdParam)
        {
            string[] files = IdParam.Split(';');

            var viewModel = bussinessLogicPO.GetCreateEditPayment(files);
            ViewBag.Title = "Input SPPB Number";
            ViewBag.Header = "Input SPPB Number";

            return PartialView("InputSPPB", viewModel);
        }

        //Remarks
        public ActionResult Remarks(string IdParam)
        {
            RemarksViewModel model = new RemarksViewModel();
            model = bussinessLogic.GetRemarksDetail(IdParam);
            ViewBag.Title = "Remarks of File Status";
            ViewBag.Header = "Remarks of File Status";

            return View("Remarks", model);
        }

        //Save process for Remarks
        public ActionResult SaveRemarks(RemarksViewModel model)
        {
            //Save remarks
            result = bussinessLogicRemark.SaveRemarksData(model, Session["UserID"].ToString());

            //Get Model for Index
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

        //Download PI Quotation from MD
        public ActionResult DownloadPIQuotation(string IdParam)
        {
            string[] files = IdParam.Split(';');

            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            var pathPIWithFee = ConfigurationManager.AppSettings["PathImportDownloadWithoutFeePI"];
            var pathPIServer = ConfigurationManager.AppSettings["PathIPT-PI"];

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    string piPath = bussinessLogic.GetPIDetail(item);
                    int pos = piPath.LastIndexOf("\\") + 1;
                    string FileName = piPath.Substring(pos, piPath.Length - pos);
                    byte[] fileContent = Converter.GetByteFromFile(pathPIServer + FileName);
                    System.IO.File.WriteAllBytes(pathPIWithFee + FileName, fileContent);
                }
            }

            //Update status for downloaded
            //result = bussinessLogic.SaveFile(modelPI, modelPI.FileName, modelPI.Extension, (Int64)modelPI.Size, physicalPath + modelPI.FileName, flag, Session["UserID"].ToString());
            //bussinessLogic.WriteFile(modelPI.FileName, physicalPath + modelPI.FileName);

            return View("Index", viewModel);
        }

        //Download approved PI
        public ActionResult DownloadPI(string IdParam)
        {
            string[] files = IdParam.Split(';');

            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            var pathPIWithoutFee = ConfigurationManager.AppSettings["PathImportDownloadWithFeePI"];
            var pathPIServer = ConfigurationManager.AppSettings["PathIPT-PI"];

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    string piPath = bussinessLogic.GetPIDetail(item);
                    int pos = piPath.LastIndexOf("\\") + 1;
                    string FileName = piPath.Substring(pos, piPath.Length - pos);
                    byte[] fileContent = Converter.GetByteFromFile(pathPIServer + FileName);
                    System.IO.File.WriteAllBytes(pathPIWithoutFee + FileName, fileContent);
                }
            }

            //Update status for downloaded
            //result = bussinessLogic.GetUpdate(IdParam, Session["UserID"].ToString());
            return View("Index", viewModel);
        }

        //Download approved PO Without Fee
        public ActionResult DownloadPO(string IdParam)
        {
            string[] files = IdParam.Split(';');

            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            var pathPOWithoutFee = ConfigurationManager.AppSettings["PathImportDownloadWithoutFeePO"];
            var pathPOServer = ConfigurationManager.AppSettings["PathIPT-PO"];

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    string poPath = bussinessLogic.GetPODetail(item);
                    int pos = poPath.LastIndexOf("\\") + 1;
                    string fileName = poPath.Substring(pos, poPath.Length - pos);
                    string fileNamePDF = fileName.Substring(0, fileName.IndexOf('.')) + ".pdf";
                    //byte[] fileContent = Converter.GetByteFromFile(pathPOServer + FileName);
                    //System.IO.File.WriteAllBytes(pathPOWithoutFee + FileName, fileContent);

                    //bussinessLogic.GeneratePDF(pathPOWithoutFee + fileNamePDF, Convert.ToInt64(item), Session["UserID"].ToString());
                }
            }
            //Update status for downloaded
            //result = bussinessLogic.GetUpdate(IdParam, Session["UserID"].ToString());

            return View("Index", viewModel);
        }

        //Download approved PO With Fee
        public ActionResult DownloadPOFee(string IdParam)
        {
            string[] files = IdParam.Split(';');

            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            var pathPOWithFee = ConfigurationManager.AppSettings["PathImportDownloadWithFeePO"];
            var pathPOServer = ConfigurationManager.AppSettings["PathIPT-PO"];

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    string poPath = bussinessLogic.GetPODetail(item);
                    int pos = poPath.LastIndexOf("\\") + 1;
                    string FileName = poPath.Substring(pos, poPath.Length - pos);
                    byte[] fileContent = Converter.GetByteFromFile(pathPOServer + FileName);
                    System.IO.File.WriteAllBytes(pathPOWithFee + FileName, fileContent);
                }
            }
            //Update status for downloaded
            //result = bussinessLogic.SaveFile(model, model.FileName, model.Extension, (Int64)model.Size, physicalPath + model.FileName, flag, Session["UserID"].ToString());
            //bussinessLogic.WriteFile(model.FileName, physicalPath + model.FileName);

            return View("Index", viewModel);
        }

        //Download Analysis File from IC
        public ActionResult Download(string IdParam)
        {
            string[] files = IdParam.Split(';');

            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            var physicalPath = ConfigurationManager.AppSettings["PathImportDownload"];
            var physicalPathIC = ConfigurationManager.AppSettings["PathIPT-IC"];
            var physicalPathMD = ConfigurationManager.AppSettings["PathIPT-MD"];

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    var model = bussinessLogic.GetFileDet(item);
                    byte[] fileContent = null;
                    if (model.FileName.Contains("_REVISE"))
                    {
                        fileContent = Converter.GetByteFromFile(physicalPathMD + model.FileName);
                    }
                    else
                    {
                        fileContent = Converter.GetByteFromFile(physicalPathIC + model.FileName);
                    }
                    System.IO.File.WriteAllBytes(physicalPath + model.FileName, fileContent);
                }
            }
            //Update status for downloaded
            //result = bussinessLogic.SaveFile(model, model.FileName, model.Extension, (Int64)model.Size, physicalPath + model.FileName, flag, Session["UserID"].ToString());
            //bussinessLogic.WriteFile(model.FileName, physicalPath + model.FileName);

            return View("Index", viewModel);
        }      

    }
}