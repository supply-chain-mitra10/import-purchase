﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.Mvc;
using Providers.Directorys;
using ViewModels.Directorys;
using ViewModels.ProcessResult;

namespace ImportProjectTracking.Controllers
{
    public class DirectorysController : BaseController
    {
        private DirectoryBussinessLogic bussinessLogic = new DirectoryBussinessLogic();
        private ProcessResult result = new ProcessResult();

        // GET: Directory
        public ActionResult Index(string message, IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List(model, page, IdFilter);
            viewModel.Message = message;
            return View(viewModel);
        }

        //Action Create 
        public ActionResult CreateDirectory()
        {
            var viewModel = bussinessLogic.GetCreateEdit();

            ViewBag.Title = "Create Directory";
            ViewBag.Header = "Create Directory";
            return PartialView("CreateEdit", viewModel);
        }

        //Action Edit 
        public ActionResult EditDirectory(string IdParam)
        {
            var viewModel = bussinessLogic.GetCreateEdit(IdParam);

            ViewBag.Title = "Edit Directory";
            ViewBag.Header = "Edit Directory";
            return PartialView("CreateEdit", viewModel);
        }

        //Action Delete 
        public ActionResult DeleteDirectory(string IdParam)
        {
            result = bussinessLogic.GetDelete(IdParam);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetSave(CreateEditDirectoryViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
                ViewBag.Header = (model.DirectoryName == "" || model.DirectoryName == string.Empty) ? "Create Directory" : "Edit Directory";

                var viewModel = bussinessLogic.GetCreateEdit();

                result.ProcessFailed("ValidationError");
                return Json(new { result, partialView = RenderPartialViewToString("CreateEdit", viewModel) }, JsonRequestBehavior.AllowGet);
            }
            result = bussinessLogic.SaveDirectory(model, Session["UserID"].ToString());
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }
    }
}