﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Providers.Items;
using ViewModels.Items;
using ViewModels.ProcessResult;

namespace ImportProjectTracking.Controllers
{
    public class ItemsController : BaseController
    {
        private ItemBussinessLogic bussinessLogic = new ItemBussinessLogic();
        private ProcessResult result = new ProcessResult();

        // GET: Items
        public ActionResult Index(string message, IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List(model, page, IdFilter);
            viewModel.Message = message;
            return View(viewModel);
        }

        //Action Create 
        public ActionResult CreateItem()
        {
            var viewModel = bussinessLogic.GetCreateEdit();

            ViewBag.Title = "Create Item";
            ViewBag.Header = "Create Item";
            return PartialView("CreateEdit", viewModel);
        }

        //Action Edit 
        public ActionResult EditItem(string IdParam)
        {
            var viewModel = bussinessLogic.GetCreateEdit(IdParam);

            ViewBag.Title = "Edit Item";
            ViewBag.Header = "Edit Item";
            return PartialView("CreateEdit", viewModel);
        }

        //Action Delete 
        public ActionResult DeleteItem(string IdParam)
        {
            result = bussinessLogic.GetDelete(IdParam);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetSave(CreateEditItemViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
                ViewBag.Header = (model.ItemNo == "" || model.ItemNo == string.Empty) ? "Create Item" : "Edit Item";

                var viewModel = bussinessLogic.GetCreateEdit();

                result.ProcessFailed("ValidationError");
                return Json(new { result, partialView = RenderPartialViewToString("CreateEdit", viewModel) }, JsonRequestBehavior.AllowGet);
            }
            result = bussinessLogic.SaveItem(model, Session["UserID"].ToString());
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }
    }
}