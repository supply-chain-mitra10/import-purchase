﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using ViewModels.Users;
using ViewModels.Dashboards;
using Providers.Users;
using Providers.Dashboards;


namespace ImportProjectTracking.Controllers
{
    public class HomeController : Controller
    {
        private UserBussinessLogic bussinessLogic = new UserBussinessLogic();
        private DashboardBussinessLogic bussinessLogicDashboard = new DashboardBussinessLogic();
        public ActionResult Login()
        {
            UserViewModel viewModel = new UserViewModel();
            viewModel.ListCompany = bussinessLogic.GetListCompany();
            viewModel.ListLocation = bussinessLogic.GetListLocation();
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(UserViewModel objUser)
        {
            if (ModelState.IsValid)
            {
                string cekPass = Commons.Crypto.GenerateSHA512String(objUser.Password);

                var obj = bussinessLogic.GetUserLogged(objUser.Username, cekPass);
                if (obj != null)
                {
                    Session["UserID"] = obj.UserId.ToString();
                    Session["UserName"] = obj.Username.ToString();
                    return RedirectToAction("Index");
                }
            }
            return View(objUser);
        }

        [Authorize]
        public ActionResult Index()
        {
            if (Session["UserID"] != null)
            {
                //Create Directory
                if (!Directory.Exists(ConfigurationManager.AppSettings["PathIPT-DC"]))
                {
                    Commons.DirectoryBuilder.CreateDirectoryIPT();
                }

                var viewModel = new DashboardViewModel();
                viewModel = bussinessLogicDashboard.GetDashboard();
                
                //Warning notif for Dashboard
                string userLogon = Session["UserID"].ToString();
                var userData = bussinessLogic.GetUserDetail(userLogon);

                if (userData.UserGroupNo.Contains("IC"))
                {
                    if (viewModel.TotalRevise != 0)
                    {
                        viewModel.Notes = "Reminder : Please check the Revised Analysis document!!";
                    }
                }
                else if (userData.UserGroupNo.Contains("MD"))
                {
                    if (viewModel.TotalOpen != 0)
                    {
                        viewModel.Notes = "Reminder : Please crosscheck the Analysis document!!";
                    }
                }
                //else if (userGroup.GroupName == "Import")
                //{
                //    if (viewModel.TotalRelease != 0)
                //    {
                //        viewModel.Notes = "Reminder : Please check the Released Analysis document!!";
                //    }
                //}

                return View(viewModel);
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
    }
}