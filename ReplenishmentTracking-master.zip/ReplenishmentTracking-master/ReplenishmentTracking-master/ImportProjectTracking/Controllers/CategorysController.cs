﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Providers.Categorys;
using ViewModels.Categorys;
using ViewModels.ProcessResult;

namespace ImportProjectTracking.Controllers
{
    public class CategorysController : BaseController
    {
        private CategoryBussinessLogic bussinessLogic = new CategoryBussinessLogic();
        private ProcessResult result = new ProcessResult();

        // GET: Categorys
        public ActionResult Index(string message, IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List(model, page, IdFilter);
            viewModel.Message = message;
            return View(viewModel);
        }

        //Action Create 
        public ActionResult CreateCategory()
        {
            var viewModel = bussinessLogic.GetCreateEdit();

            ViewBag.Title = "Create Category";
            ViewBag.Header = "Create Category";
            return PartialView("CreateEdit", viewModel);
        }

        //Action Edit 
        public ActionResult EditCategory(string IdParam)
        {
            var viewModel = bussinessLogic.GetCreateEdit(IdParam);

            ViewBag.Title = "Edit Category";
            ViewBag.Header = "Edit Category";
            return PartialView("CreateEdit", viewModel);
        }

        //Action Delete 
        public ActionResult DeleteCategory(string IdParam)
        {
            result = bussinessLogic.GetDelete(IdParam);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetSave(CreateEditCategoryViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
                ViewBag.Header = (model.Category == "" || model.Category == string.Empty) ? "Create Category" : "Edit Category";

                var viewModel = bussinessLogic.GetCreateEdit();

                result.ProcessFailed("ValidationError");
                return Json(new { result, partialView = RenderPartialViewToString("CreateEdit", viewModel) }, JsonRequestBehavior.AllowGet);
            }
            result = bussinessLogic.SaveCategory(model, Session["UserID"].ToString());
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }
    }
}