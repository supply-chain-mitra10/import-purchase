﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Configuration;
using Providers.DistributionCenters;
using Providers.Remarkss;
using ViewModels.DistributionCenters;
using ViewModels.PurchaseOrders;
using ViewModels.Dashboards;
using ViewModels.Remarkss;
using ViewModels.ProcessResult;
using Providers.PurchaseOrders;

namespace ImportProjectTracking.Controllers
{
    public class DistributionCentersController : Controller
    {
        private DistributionCenterBussinessLogic bussinessLogic = new DistributionCenterBussinessLogic();
        private PurchaseOrderBussinessLogic bussinessLogicPO = new PurchaseOrderBussinessLogic();
        private RemarksBussinessLogic bussinessLogicRemark = new RemarksBussinessLogic();
        private ProcessResult result = new ProcessResult();
        public string flag = "0";

        // GET: DistributionCenters
        [Authorize]
        [OutputCacheAttribute(VaryByParam = "*", Duration = 0, NoStore = true)]
        public ActionResult Index(string message)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.Message = message;

            return View(viewModel);
        }

        //Menu Payment Import
        public ActionResult IndexDetail(string IdParam)
        {
            var viewModel = new IndexPOViewModel();
            viewModel.List = bussinessLogicPO.List(IdParam);
            //viewModel.ListSuggest = bussinessLogic.GetListSuggest();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            return View(viewModel);
        }

        //Details PO
        public ActionResult DetailsPO(string IdParam, string ItemNo)
        {
            CreateEditPurchaseOrderViewModel viewModel = new CreateEditPurchaseOrderViewModel();
            viewModel = bussinessLogicPO.GetPODetails(IdParam, ItemNo);
            ViewBag.Title = "Purchase Order Details";
            ViewBag.Header = "Purchase Order Details";

            return View("DetailsPO", viewModel);
        }

        //Files Timeline
        public ActionResult FilesTimeline(string IdParam)
        {
            var viewModel = new IndexTimelineViewModel();
            viewModel.List = bussinessLogic.ListTimeline(IdParam);
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View(viewModel);
        }

        //Index Upload
        public ActionResult IndexUpload()
        {
            var viewModel = bussinessLogic.GetCreateEdit();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase file, DistributionCenterViewModel model)
        {
            ViewBag.Header = "Upload Files";

            try
            {
                if (file != null && file.ContentLength > 0)
                {
                    try
                    {
                        var fileName = Path.GetFileName(file.FileName);
                        var extensionFile = Path.GetExtension(file.FileName);
                        var fileSize = Convert.ToInt64(file.ContentLength);
                        var physicalPath = ConfigurationManager.AppSettings["PathDCUpload"];
                        var physicalPathServer = ConfigurationManager.AppSettings["PathIPT-DC"];
                        var physicalPathHist = ConfigurationManager.AppSettings["PathIPTHist-DC"];

                        //Auto rename uploaded suggest files
                        string miliscnd = DateTime.Now.ToString("fffff");
                        string fileNameCustom = DateTime.Now.ToString("yyyyMMdd") + miliscnd + "_" + fileName;

                        if (physicalPath != "" && physicalPathServer != "" && fileName != "")
                        {
                            //If file exists
                            if (System.IO.File.Exists(physicalPath + fileNameCustom))
                            {
                                System.IO.File.Move(physicalPath + fileNameCustom, physicalPathHist + fileNameCustom + ".old");
                            }
                            if (System.IO.File.Exists(physicalPathServer + fileNameCustom))
                            {
                                System.IO.File.Move(physicalPathServer + fileNameCustom, physicalPathHist + fileNameCustom + ".old");
                            }

                            //save file to local
                            physicalPath = Path.Combine(@"" + physicalPath, fileNameCustom);
                            file.SaveAs(physicalPath);
                            //save file to server
                            physicalPathServer = Path.Combine(@"" + physicalPathServer, fileNameCustom);
                            file.SaveAs(physicalPathServer);

                            if (file.ContentLength > 0)
                            {
                                if (fileName.EndsWith(".csv") || fileName.EndsWith(".xlsx"))
                                {
                                    result = bussinessLogic.SaveFile(model, fileNameCustom, extensionFile, physicalPath, Session["UserID"].ToString());
                                }
                            }

                            if (result.Message != null)
                            {
                                @ViewBag.Message = result.Message;
                            }

                        }
                        else
                        {
                            @ViewBag.Message = "Unknown extension file.";
                        }
                    }
                    catch (Exception ex)
                    {
                        ViewBag.Message = "ERROR:" + ex.Message.ToString();
                    }
                }
                else
                {
                    ViewBag.Message = "Please select the file to upload.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "ERROR:" + ex.Message.ToString();
            }

            //Get Dropdownlist
            var viewModel = bussinessLogic.GetCreateEdit();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.ListVendor = bussinessLogic.GetListVendor();

            return View("IndexUpload", viewModel);
        }   

        //Remarks
        public ActionResult Remarks(string IdParam)
        {
            RemarksViewModel model = new RemarksViewModel();
            model = bussinessLogic.GetRemarksDetail(IdParam);
            ViewBag.Title = "Remarks of File Status";
            ViewBag.Header = "Remarks of File Status";

            return View("Remarks", model);
        }

        //Save process for Remarks
        public ActionResult SaveRemarks(RemarksViewModel model)
        {
            //Save remarks
            result = bussinessLogicRemark.SaveRemarksData(model, Session["UserID"].ToString());

            //Get Model for Index
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

    }
}