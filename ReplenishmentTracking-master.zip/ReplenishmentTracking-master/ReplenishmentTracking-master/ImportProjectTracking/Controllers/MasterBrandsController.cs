﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Providers.MasterBrands;
using ViewModels.MasterBrands;
using ViewModels.ProcessResult;

namespace ImportProjectTracking.Controllers
{
    public class MasterBrandsController : BaseController
    {
        private MasterBrandBussinessLogic bussinessLogic = new MasterBrandBussinessLogic();
        private ProcessResult result = new ProcessResult();

        // GET: MasterBrands
        public ActionResult Index(string message, IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List(model, page, IdFilter);
            viewModel.Message = message;
            return View(viewModel);
        }

        ////Action Create 
        //public ActionResult CreateMasterBrand()
        //{
        //    var viewModel = bussinessLogic.GetCreateEdit();

        //    ViewBag.Title = "Create MasterBrand";
        //    ViewBag.Header = "Create MasterBrand";
        //    return PartialView("CreateEdit", viewModel);
        //}

        ////Action Edit 
        //public ActionResult EditMasterBrand(string IdParam)
        //{
        //    var viewModel = bussinessLogic.GetCreateEdit(IdParam);

        //    ViewBag.Title = "Edit MasterBrand";
        //    ViewBag.Header = "Edit MasterBrand";
        //    return PartialView("CreateEdit", viewModel);
        //}

        ////Action Delete 
        //public ActionResult DeleteMasterBrand(int IdParam)
        //{
        //    result = bussinessLogic.GetDelete(IdParam);
        //    return Json(result, JsonRequestBehavior.AllowGet);
        //}

        //[HttpPost]
        //public ActionResult GetSave(CreateEditMasterBrandViewModel model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
        //        ViewBag.Header = model.Id == 0 ? "Create MasterBrand" : "Edit MasterBrand";

        //        var viewModel = bussinessLogic.GetCreateEdit();

        //        result.ProcessFailed("ValidationError");
        //        return Json(new { result, partialView = RenderPartialViewToString("CreateEdit", viewModel) }, JsonRequestBehavior.AllowGet);
        //    }
        //    result = bussinessLogic.SaveMasterBrand(model, Session["UserID"].ToString());
        //    return Json(new { result }, JsonRequestBehavior.AllowGet);
        //}
    }
}