﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text.RegularExpressions;
using System.IO;
using System.Data;
using System.Configuration;
using Providers.Merchandises;
using Providers.PurchaseOrders;
using Providers.ProformaInvoices;
using Providers.Remarkss;
using Providers.Imports;
using ViewModels.Merchandises;
using ViewModels.ProformaInvoices;
using ViewModels.PurchaseOrders;
using ViewModels.Dashboards;
using ViewModels.Imports;
using ViewModels.ProcessResult;
using ViewModels.Remarkss;
using ImportProjectTracking.Commons;


namespace ImportProjectTracking.Controllers
{
    public class MerchandisesController : BaseController
    {
        private MerchandiseBussinessLogic bussinessLogic = new MerchandiseBussinessLogic();
        private PurchaseOrderBussinessLogic bussinessLogicPO = new PurchaseOrderBussinessLogic();
        private ProformaInvoiceBussinessLogic bussinessLogicPI = new ProformaInvoiceBussinessLogic();
        private ImportBussinessLogic bussinessLogicImport = new ImportBussinessLogic();
        private RemarksBussinessLogic bussinessLogicRemark = new RemarksBussinessLogic();
        private ProcessResult result = new ProcessResult();
        public string flag = "0";

        // GET: Merchandises
        [OutputCacheAttribute(VaryByParam = "*", Duration = 0, NoStore = true)]
        public ActionResult Index()
        {
            var viewModel = new ViewModels.Merchandises.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            //viewModel.Message = message;

            return View(viewModel);
        }

        //Index Details
        public ActionResult IndexDetail(string IdParam)
        {
            var viewModel = new IndexSuggestDetailViewModel();
            viewModel.List = bussinessLogicImport.ListItems(IdParam);
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            return View(viewModel);
        }

        //Details Item
        public ActionResult DetailsItem(string IdParam, string IdParam2)
        {
            SuggestDetailViewModel modelRevise = new SuggestDetailViewModel();
            modelRevise = bussinessLogicImport.GetItemDet(IdParam, IdParam2);
            ViewBag.Title = "Item Details";
            ViewBag.Header = "Item Details";

            return View("DetailsItem", modelRevise);
        }

        //Index Revise by Form
        public ActionResult IndexRevise(string IdParam)
        {
            var viewModel = new IndexSuggestDetailViewModel();
            viewModel.List = bussinessLogicImport.ListItems(IdParam);
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            return View(viewModel);
        }

        //Revise MD process by Form
        public ActionResult CreateEditItem(string IdParam, string IdParam2)
        {
            SuggestDetailViewModel modelRevise = new SuggestDetailViewModel();
            modelRevise = bussinessLogicImport.GetItemDet(IdParam, IdParam2);
            ViewBag.Title = "Revise Item";
            ViewBag.Header = "Revise Item";

            return View("CreateEditItem", modelRevise);
        }

        //Files Timeline
        public ActionResult FilesTimeline(string IdParam)
        {
            var viewModel = new IndexTimelineViewModel();
            viewModel.List = bussinessLogic.ListTimeline(IdParam);
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View(viewModel);
        }

        //Approval process for MD
        public ActionResult ApproveFile(string IdParam)
        {
            flag = "2";

            string[] files = IdParam.Split(';');

            var viewModel = new ViewModels.Merchandises.IndexViewModel();
            MerchandiseViewModel modelConfirm = new MerchandiseViewModel();

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    modelConfirm = bussinessLogic.GetFileDet(item);
                    result = bussinessLogic.SaveFile(modelConfirm, modelConfirm.FileName, modelConfirm.Extension, Convert.ToInt32(modelConfirm.Size), "", flag, Session["UserID"].ToString());
                }
            }

            //Get Model for Index
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.Message = result.Message;
            ViewBag.Error = result.Message;

            return View("Index", viewModel);
        }

        //Close Suggest process
        public ActionResult CloseFile(string IdParam)
        {
            string[] files = IdParam.Split(';');

            MerchandiseViewModel modelClose = new MerchandiseViewModel();

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    modelClose = bussinessLogic.GetFileDet(item);
                    var result = bussinessLogic.GetClose(item, Session["UserID"].ToString());
                }
            }

            //Get Model for Index
            var viewModel = new ViewModels.Merchandises.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

        //Revise process by MD (Upload)
        //public ActionResult ReviseFile(long IdParam, string message, IndexViewModel model, int? page = null)
        //{
        //    //var viewModel = new IndexViewModel();
        //    MerchandiseViewModel modelRevise = new MerchandiseViewModel();
        //    modelRevise = bussinessLogic.GetFileDet(IdParam);
        //    result = bussinessLogic.GetRevise(IdParam, Session["UserID"].ToString());

        //    //Get Model for IndexUpload
        //    modelRevise.ListCategory = bussinessLogic.GetListCategory();
        //    modelRevise.ListVendor = bussinessLogic.GetListVendor();

        //    //viewModel.List = bussinessLogic.List(model, "", page);
        //    //viewModel.ListStatus = bussinessLogic.GetListStatus();
        //    //viewModel.ListVendor = bussinessLogic.GetListVendor();
        //    //viewModel.ListCategory = bussinessLogic.GetListCategory();

        //    return View("IndexUpload", modelRevise);
        //}

        

        //Index Input PI Number
        public ActionResult InputPINumber(string IdParam)
        {
            var viewModel = bussinessLogicPI.GetCreateEditPI(IdParam);
            ViewBag.Title = "Upload Performa Invoice";
            ViewBag.Header = "Upload Performa Invoice";

            return View("InputPINumber", viewModel);
        }

        //Index Input PO Number
        public ActionResult InputPONumber(string IdParam)
        {
            var viewModel = bussinessLogicPO.GetCreateEditPO(IdParam);
            ViewBag.Title = "Input Purchase Order Number";
            ViewBag.Header = "Input Purchase Order Number";

            return View("InputPONumber", viewModel);
        }

        //Remarks
        public ActionResult Remarks(string IdParam)
        {
            RemarksViewModel model = new RemarksViewModel();
            model = bussinessLogic.GetRemarksDetail(IdParam);
            ViewBag.Title = "Remarks of File Status";
            ViewBag.Header = "Remarks of File Status";

            return View("Remarks", model);
        }

        //Save process for Remarks
        public ActionResult SaveRemarks(RemarksViewModel model)
        {
            //Save remarks
            result = bussinessLogicRemark.SaveRemarksData(model, Session["UserID"].ToString());

            //Get Model for Index
            var viewModel = new ViewModels.Merchandises.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

        public ActionResult IndexUpload()
        {
            var viewModel = bussinessLogic.GetCreateEdit();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase file, MerchandiseViewModel model)
        {
            ViewBag.Header = "Upload Files";
            flag = "3";

            try
            {
                if (file != null && file.ContentLength > 0)
                {
                    try
                    {
                        var fileName = Path.GetFileName(file.FileName);
                        var extensionFile = Path.GetExtension(file.FileName);
                        var fileSize = Convert.ToInt32(file.ContentLength);
                        var physicalPath = ConfigurationManager.AppSettings["PathMDUpload"];
                        var physicalPathServer = ConfigurationManager.AppSettings["PathIPT-MD"];
                        var physicalPathHist = ConfigurationManager.AppSettings["PathIPTHist-MD"];

                        string fileNameRevise = fileName.Substring(0, fileName.IndexOf('.')) + "_REVISE" + extensionFile;

                        if (physicalPath != "" && physicalPathServer != "" && fileName != "")
                        {
                            //If file exists
                            if (System.IO.File.Exists(physicalPath + fileName))
                            {
                                System.IO.File.Move(physicalPath + fileName, physicalPathHist + fileName + ".old");
                            }
                            if (System.IO.File.Exists(physicalPathServer + fileName))
                            {
                                System.IO.File.Move(physicalPathServer + fileName, physicalPathHist + fileName + ".old");
                            }

                            //save file to local
                            physicalPath = Path.Combine(@"" + physicalPath, fileNameRevise);
                            file.SaveAs(physicalPath);
                            //save file to server
                            physicalPathServer = Path.Combine(@"" + physicalPathServer, fileNameRevise);
                            file.SaveAs(physicalPathServer);

                            if (file.ContentLength > 0)
                            {
                                if (fileName.EndsWith(".xlsx") || (fileName.EndsWith(".xls")))
                                {
                                    result = bussinessLogic.SaveFile(model, fileName, extensionFile, fileSize, physicalPath, flag, Session["UserID"].ToString());
                                }
                                else
                                {
                                    @ViewBag.Message = "File type not supported, please use Excel(.xlsx).";
                                }
                            }

                            if (result.IsSucceed == true)
                            {
                                @ViewBag.Message = "File Uploaded Successfully";
                            }
                            else
                            {
                                @ViewBag.Message = "File Process Error!!";
                            }

                        }
                        else
                        {
                            @ViewBag.Message = "Unknown extension file.";
                        }
                    }
                    catch (Exception ex)
                    {
                        ViewBag.Message = "ERROR:" + ex.Message.ToString();
                    }
                }
                else
                {
                    ViewBag.Message = "Please select the file to upload.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "ERROR:" + ex.Message.ToString();
            }

            //Get Dropdownlist
            var viewModel = bussinessLogic.GetCreateEdit();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.ListVendor = bussinessLogic.GetListVendor();

            return View("IndexUpload", viewModel);
        }

        //Download process for Quotation
        public ActionResult Download(string IdParam)
        {
            flag = "1";
            string[] files = IdParam.Split(';');

            var viewModel = new ViewModels.Merchandises.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            var physicalPath = ConfigurationManager.AppSettings["PathMDDownload"];
            var physicalPathIC = ConfigurationManager.AppSettings["PathIPT-IC"];
            var physicalPathMD = ConfigurationManager.AppSettings["PathIPT-MD"];

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    var model = bussinessLogic.GetFileDet(item);
                    string fileName = model.FileName;
                    string fileNamePDF = fileName.Substring(0, fileName.IndexOf('.')) + ".pdf";
                    byte[] fileContent = null;
                    if (model.FileName.Contains("_REVISE"))
                    {
                        fileContent = Converter.GetByteFromFile(physicalPathMD + model.FileName);
                    }
                    else
                    {
                        fileContent = Converter.GetByteFromFile(physicalPathIC + model.FileName);
                    }
                    //System.IO.File.WriteAllBytes(physicalPath + model.FileName, fileContent);
                    bussinessLogic.GeneratePDF(physicalPath + fileNamePDF, item);

                    //Update status for downloaded
                    result = bussinessLogic.SaveFile(model, model.FileName, model.Extension, (int)model.Size, physicalPath + model.FileName, flag, Session["UserID"].ToString());
                    //bussinessLogic.WriteFile(model.FileName, physicalPath + model.FileName);
                }
            }

            return View("Index", viewModel);
        }

        //Download process for Analysis File
        public ActionResult DownloadAnalysis(string IdParam)
        {
            flag = "1";
            string[] files = IdParam.Split(';');

            var viewModel = new ViewModels.Merchandises.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            var physicalPath = ConfigurationManager.AppSettings["PathMDDownload"];
            var physicalPathIC = ConfigurationManager.AppSettings["PathIPT-IC"];
            var physicalPathMD = ConfigurationManager.AppSettings["PathIPT-MD"];

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    var model = bussinessLogic.GetFileDet(item);
                    string fileName = model.FileName;
                    string fileNamePDF = fileName.Substring(0, fileName.IndexOf('.')) + ".pdf";
                    byte[] fileContent = null;
                    if (model.FileName.Contains("_REVISE"))
                    {
                        fileContent = Converter.GetByteFromFile(physicalPathMD + model.FileName);
                    }
                    else
                    {
                        fileContent = Converter.GetByteFromFile(physicalPathIC + model.FileName);
                    }
                    System.IO.File.WriteAllBytes(physicalPath + model.FileName, fileContent);

                    //Update status for downloaded
                    result = bussinessLogic.SaveFile(model, model.FileName, model.Extension, (int)model.Size, physicalPath + model.FileName, flag, Session["UserID"].ToString());
                    bussinessLogic.WriteFile(model.FileName, physicalPath + model.FileName);
                }
            }

            return View("Index", viewModel);
        }

        //Save MD Revised Suggest
        [HttpPost]
        public ActionResult GetSaveItem(SuggestDetailViewModel model)
        {
            var physicalPath = ConfigurationManager.AppSettings["PathIPT-MD"];
            var physicalPathServer = ConfigurationManager.AppSettings["PathIPT-IC"];

            var viewModel = new ViewModels.Merchandises.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            result = bussinessLogic.GetRevise(model, Session["UserID"].ToString());
            if (result.IsSucceed == true)
            {
                var fileDetail = bussinessLogic.GetFileDet(model.SuggestDocNo);
                string fileName = fileDetail.FileName;
                string fname = fileName.Substring(0, fileName.LastIndexOf('_')) + fileDetail.Extension;
                byte[] fileContent = Converter.GetByteFromFile(physicalPathServer + fname);
                System.IO.File.WriteAllBytes(physicalPath + fileName, fileContent);
                bussinessLogic.WriteFile(fileName, physicalPath + fileName);
            }
            return View("Index", viewModel);
        }

        [HttpPost]
        public ActionResult GetSavePI(HttpPostedFileBase myfile, HttpPostedFileBase myfile2, CreateEditProformaInvoiceHeaderViewModel model)
        {
            var viewModel = new ViewModels.Merchandises.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            //if (!ModelState.IsValid)
            //{
            //    ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
            //    ViewBag.Header = "Input PI Number";

            //    result.ProcessFailed("ValidationError");
            //    return Json(new { result, partialView = RenderPartialViewToString("InputPINumber", viewModel) }, JsonRequestBehavior.AllowGet);
            //}

            //Automatic input PI by Upload File
            if (myfile != null && myfile.ContentLength > 0)
            {
                try
                {
                    var fileName = Path.GetFileName(myfile.FileName);
                    var extensionFile = Path.GetExtension(myfile.FileName);
                    var physicalPath = ConfigurationManager.AppSettings["PathMDPI"];
                    var physicalPathServer = ConfigurationManager.AppSettings["PathIPT-PI"];

                    if (fileName.EndsWith(".xlsx") || (fileName.EndsWith(".xls")))
                    {
                        //save file to local
                        physicalPath = Path.Combine(@"" + physicalPath, fileName);
                        myfile.SaveAs(physicalPath);
                        //save file to server
                        physicalPathServer = Path.Combine(@"" + physicalPathServer, fileName);
                        myfile.SaveAs(physicalPathServer);

                        result = bussinessLogicPI.SavePI(model, fileName, extensionFile, physicalPath, physicalPathServer, Session["UserID"].ToString());
                    }
                    else
                    {
                        @ViewBag.Message = "File type not supported, please use Excel(.xlsx).";
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.Message = "ERROR:" + ex.Message.ToString();
                }
            }

            //Save Image file from Supplier
            if (myfile2 != null && myfile2.ContentLength > 0)
            {
                try
                {
                    var imageName = Path.GetFileName(myfile2.FileName);
                    var extensionFile = Path.GetExtension(myfile2.FileName);
                    var physicalPath = ConfigurationManager.AppSettings["PathMDImages"];
                    var physicalPathServer = ConfigurationManager.AppSettings["PathIPT-Images"];

                    if (imageName.EndsWith(".jpg") || imageName.EndsWith(".jpeg") || imageName.EndsWith(".png") || imageName.EndsWith(".pdf"))
                    {
                        //save image to local
                        physicalPath = Path.Combine(@"" + physicalPath, imageName);
                        myfile2.SaveAs(physicalPath);
                        //save image to server
                        physicalPathServer = Path.Combine(@"" + physicalPathServer, imageName);
                        myfile2.SaveAs(physicalPathServer);

                        result = bussinessLogicPI.SavePIImages(model, physicalPath, Session["UserID"].ToString());
                    }
                    else
                    {
                        @ViewBag.Message = "File type not supported, please use Image(.jpg/.png) or PDF.";
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.Message = "ERROR:" + ex.Message.ToString();
                }
            }

            //result = bussinessLogic.SavePI(model, Session["UserID"].ToString());
            //return Json(new { result }, JsonRequestBehavior.AllowGet);
            return View("Index", viewModel);
        }

        [HttpPost]
        public ActionResult GetSavePO(HttpPostedFileBase myfile, CreateEditPurchaseOrderViewModel model)
        {
            var viewModel = new ViewModels.Merchandises.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            //if (!ModelState.IsValid)
            //{
            //    ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
            //    ViewBag.Header = "Input PO Number";

            //    //var viewModel = bussinessLogicPO.GetCreateEditPO();

            //    result.ProcessFailed("ValidationError");
            //    return Json(new { result, partialView = RenderPartialViewToString("InputPONumber", viewModel) }, JsonRequestBehavior.AllowGet);
            //}

            if (myfile != null && myfile.ContentLength > 0)
            {
                try
                {
                    var fileName = Path.GetFileName(myfile.FileName);
                    var extensionFile = Path.GetExtension(myfile.FileName);
                    var physicalPath = ConfigurationManager.AppSettings["PathMDPO"];
                    var physicalPathServer = ConfigurationManager.AppSettings["PathIPT-PO"];

                    //save file to local
                    physicalPath = Path.Combine(@"" + physicalPath, fileName);
                    myfile.SaveAs(physicalPath);
                    //save file to server
                    physicalPathServer = Path.Combine(@"" + physicalPathServer, fileName);
                    myfile.SaveAs(physicalPathServer);

                    result = bussinessLogicPO.SavePO(model, "", extensionFile, physicalPath, physicalPathServer, Session["UserID"].ToString());
                }
                catch (Exception ex)
                {
                    ViewBag.Message = "ERROR:" + ex.Message.ToString();
                }

            }

            //return Json(new { result }, JsonRequestBehavior.AllowGet);
            return View("Index", viewModel);
        }

        //Get Data for DropdownBox
        [HttpPost]
        public JsonResult GetItemAutocomplete(string term)
        {
            var viewModel = bussinessLogicPI.GetCreateEditPI();
            viewModel.ListItem = bussinessLogic.GetListItem(term);
            //var result = bussinessLogic.GetListItem(term);
            return Json(viewModel, JsonRequestBehavior.AllowGet);
        }
    }
}