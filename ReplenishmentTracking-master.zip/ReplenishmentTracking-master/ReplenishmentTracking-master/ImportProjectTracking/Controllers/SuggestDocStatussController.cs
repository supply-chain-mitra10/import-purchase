﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Providers.SuggestDocStatuss;
using ViewModels.SuggestDocStatuss;
using ViewModels.ProcessResult;

namespace ImportProjectTracking.Controllers
{
    public class SuggestDocStatussController : BaseController
    {
        private SuggestDocStatusBussinessLogic bussinessLogic = new SuggestDocStatusBussinessLogic();
        private ProcessResult result = new ProcessResult();

        // GET: Statuss
        public ActionResult Index(string message, IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List(model, page, IdFilter);
            viewModel.Message = message;
            return View(viewModel);
        }

        //Action Create 
        public ActionResult CreateStatus()
        {
            var viewModel = bussinessLogic.GetCreateEdit();

            ViewBag.Title = "Create Status";
            ViewBag.Header = "Create Status";
            return PartialView("CreateEdit", viewModel);
        }

        //Action Edit 
        public ActionResult EditStatus(string IdParam)
        {
            var viewModel = bussinessLogic.GetCreateEdit(IdParam);

            ViewBag.Title = "Edit Status";
            ViewBag.Header = "Edit Status";
            return PartialView("CreateEdit", viewModel);
        }

        //Action Delete 
        public ActionResult DeleteStatus(string IdParam)
        {
            result = bussinessLogic.GetDelete(IdParam);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetSave(CreateEditSuggestDocStatussViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
                ViewBag.Header = (model.SuggestDocStatus == "" || model.SuggestDocStatus == string.Empty) ? "Create Status" : "Edit Status";

                var viewModel = bussinessLogic.GetCreateEdit();

                result.ProcessFailed("ValidationError");
                return Json(new { result, partialView = RenderPartialViewToString("CreateEdit", viewModel) }, JsonRequestBehavior.AllowGet);
            }
            result = bussinessLogic.SaveStatus(model, Session["UserID"].ToString());
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }
    }
}