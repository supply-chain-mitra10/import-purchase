﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Providers.UserGroups;
using ViewModels.UserGroups;
using ViewModels.ProcessResult;

namespace ImportProjectTracking.Controllers
{
    public class UserGroupsController : BaseController
    {
        private UserGroupBussinessLogic bussinessLogic = new UserGroupBussinessLogic();
        private ProcessResult result = new ProcessResult();

        // GET: UserGroups
        public ActionResult Index(string message, IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List(model, page, IdFilter);
            viewModel.Message = message;
            return View(viewModel);
        }

        ////Action Create 
        //public ActionResult CreateUserGroup()
        //{
        //    var viewModel = bussinessLogic.GetCreateEdit();

        //    ViewBag.Title = "Create User Group";
        //    ViewBag.Header = "Create User Group";
        //    return PartialView("CreateEdit", viewModel);
        //}

        ////Action Edit 
        //public ActionResult EditUserGroup(int IdParam)
        //{
        //    var viewModel = bussinessLogic.GetCreateEdit(IdParam);

        //    ViewBag.Title = "Edit User Group";
        //    ViewBag.Header = "Edit User Group";
        //    return PartialView("CreateEdit", viewModel);
        //}

        ////Action Delete 
        //public ActionResult DeleteUserGroup(int IdParam)
        //{
        //    result = bussinessLogic.GetDelete(IdParam);
        //    return Json(result, JsonRequestBehavior.AllowGet);
        //}

        //[HttpPost]
        //public ActionResult GetSave(CreateEditUserGroupViewModel model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
        //        ViewBag.Header = model.Id == 0 ? "Create User Group" : "Edit User Group";

        //        var viewModel = bussinessLogic.GetCreateEdit();

        //        result.ProcessFailed("ValidationError");
        //        return Json(new { result, partialView = RenderPartialViewToString("CreateEdit", viewModel) }, JsonRequestBehavior.AllowGet);
        //    }
        //    result = bussinessLogic.SaveUserGroup(model, Session["UserID"].ToString());
        //    return Json(new { result }, JsonRequestBehavior.AllowGet);
        //}
    }
}