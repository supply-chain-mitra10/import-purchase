﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ViewModels.Reports;
using Providers.Merchandises;

namespace ImportProjectTracking.Controllers
{
    public class ReportsController : BaseController
    {
        private MerchandiseBussinessLogic bussinessLogic = new MerchandiseBussinessLogic();

        // GET: Reports
        public ActionResult Index()
        {
            ViewBag.Title = "Report Import Purchase";
            ViewBag.Header = "Report Import Purchase";

            var viewModel = new IndexReportViewModel();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

        public ActionResult GetFilter(string message, ViewModels.InventoryControls.IndexViewModel model, string IdFilter, int? page = null)
        {
            var viewModel = new ViewModels.InventoryControls.IndexViewModel();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.Message = message;

            return View("Index", viewModel);
        }
    }
}