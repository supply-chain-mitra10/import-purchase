﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Providers.Users;
using ViewModels.Users;
using ViewModels.ProcessResult;


namespace ImportProjectTracking.Controllers
{
    public class UsersController : BaseController
    {
        private UserBussinessLogic bussinessLogic = new UserBussinessLogic();
        private ProcessResult result = new ProcessResult();

        // GET: Users
        public ActionResult Index(string message, IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List(model, page, IdFilter);
            viewModel.Message = message;
            return View(viewModel);
        }

        ////Action Create 
        //public ActionResult CreateUser()
        //{
        //    var viewModel = bussinessLogic.GetCreateEdit();

        //    ViewBag.Title = "Create User";
        //    ViewBag.Header = "Create User";
        //    return PartialView("CreateEdit", viewModel);
        //}

        ////Action Edit 
        //public ActionResult EditUser(string IdParam)
        //{
        //    var viewModel = bussinessLogic.GetCreateEdit(IdParam);

        //    ViewBag.Title = "Edit User";
        //    ViewBag.Header = "Edit User";
        //    return PartialView("CreateEdit", viewModel);
        //}

        ////Action Delete 
        //public ActionResult DeleteUser(string IdParam)
        //{
        //    result = bussinessLogic.GetDelete(IdParam);
        //    return Json(result, JsonRequestBehavior.AllowGet);
        //}

        //[HttpPost]
        //public ActionResult GetSave(CreateEditUserViewModel model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
        //        ViewBag.Header = model.Id == 0 ? "Create User" : "Edit User";

        //        var viewModel = bussinessLogic.GetCreateEdit();

        //        result.ProcessFailed("ValidationError");
        //        return Json(new { result, partialView = RenderPartialViewToString("CreateEdit", viewModel) }, JsonRequestBehavior.AllowGet);
        //    }
        //    result = bussinessLogic.SaveUser(model, Session["UserID"].ToString());
        //    return Json(new { result }, JsonRequestBehavior.AllowGet);
        //}
    }
}