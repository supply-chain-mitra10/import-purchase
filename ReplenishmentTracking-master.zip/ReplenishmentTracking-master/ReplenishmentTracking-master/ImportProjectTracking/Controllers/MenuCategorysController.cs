﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Providers.MenuCategorys;
using ViewModels.MenuCategorys;
using ViewModels.ProcessResult;

namespace ImportProjectTracking.Controllers
{
    public class MenuCategorysController : BaseController
    {
        private MenuCategoryBussinessLogic bussinessLogic = new MenuCategoryBussinessLogic();
        private ProcessResult result = new ProcessResult();

        // GET: Menu
        public ActionResult Index(string message, IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List(model, page, IdFilter);
            viewModel.Message = message;
            return View(viewModel);
        }

        //Action Create 
        public ActionResult CreateMenu()
        {
            var viewModel = bussinessLogic.GetCreateEdit();

            ViewBag.Title = "Create Menu";
            ViewBag.Header = "Create Menu";
            return PartialView("CreateEdit", viewModel);
        }

        //Action Edit 
        public ActionResult EditMenu(string IdParam)
        {
            var viewModel = bussinessLogic.GetCreateEdit(IdParam);

            ViewBag.Title = "Edit Menu";
            ViewBag.Header = "Edit Menu";
            return PartialView("CreateEdit", viewModel);
        }

        //Action Delete 
        public ActionResult DeleteMenu(string IdParam)
        {
            result = bussinessLogic.GetDelete(IdParam);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetSave(CreateEditMenuCategoryViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
                ViewBag.Header = (model.MenuCategoryNo == "" || model.MenuCategoryNo == string.Empty) ? "Create Menu" : "Edit Menu";

                var viewModel = bussinessLogic.GetCreateEdit();

                result.ProcessFailed("ValidationError");
                return Json(new { result, partialView = RenderPartialViewToString("CreateEdit", viewModel) }, JsonRequestBehavior.AllowGet);
            }
            result = bussinessLogic.SaveMenu(model, Session["UserID"].ToString());
            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }
    }
}