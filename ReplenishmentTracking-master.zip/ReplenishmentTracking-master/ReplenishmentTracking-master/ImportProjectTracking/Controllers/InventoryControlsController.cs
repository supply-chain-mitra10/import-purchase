﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Data;
using System.Configuration;
using Providers.InventoryControls;
using Providers.Imports;
using Providers.Remarkss;
using ViewModels.InventoryControls;
using ViewModels.Imports;
using ViewModels.Dashboards;
using ViewModels.Remarkss;
using ViewModels.ProcessResult;
using ViewModels.Commons;
using ImportProjectTracking.Commons;

namespace ImportProjectTracking.Controllers
{
    public class InventoryControlsController : Controller
    {
        private InventoryControlBussinessLogic bussinessLogic = new InventoryControlBussinessLogic();
        private ImportBussinessLogic bussinessLogicImport = new ImportBussinessLogic();
        private RemarksBussinessLogic bussinessLogicRemark = new RemarksBussinessLogic();
        private ProcessResult result = new ProcessResult();
        public string flag = "0";

        // GET: InventoryControls
        [Authorize]
        [OutputCacheAttribute(VaryByParam = "*", Duration = 0, NoStore = true)]
        public ActionResult Index(string message)
        {
            var viewModel = new ViewModels.InventoryControls.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.Message = message;

            return View(viewModel);
        }

        //Index Details
        public ActionResult IndexDetail(string IdParam)
        {
            var viewModel = new IndexSuggestDetailViewModel();

            var cekRevise = bussinessLogic.GetFileDet(IdParam);
            if (cekRevise.FileName.Contains("_REVISE"))
            {
                viewModel.List = bussinessLogicImport.ListReviseItems(IdParam);
            }
            else
            {
                viewModel.List = bussinessLogicImport.ListItems(IdParam);
            }

            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            return View(viewModel);
        }

        ////Index Revised Details
        //public ActionResult IndexDetailRevise(long IdParam)
        //{
        //    var viewModel = new IndexSuggestDetailViewModel();
        //    viewModel.List = bussinessLogicImport.ListReviseItems(IdParam);
        //    viewModel.ListVendor = bussinessLogic.GetListVendor();
        //    viewModel.ListCategory = bussinessLogic.GetListCategory();
        //    return View(viewModel);
        //}

        //Details Item
        public ActionResult DetailsItem(string IdParam, string IdParam2)
        {
            SuggestDetailViewModel modelRevise = new SuggestDetailViewModel();
            modelRevise = bussinessLogicImport.GetItemDet(IdParam, IdParam2);
            ViewBag.Title = "Item Details";
            ViewBag.Header = "Item Details";

            return View("DetailsItem", modelRevise);
        }

        //Files Timeline
        public ActionResult FilesTimeline(string IdParam)
        {
            var viewModel = new IndexTimelineViewModel();
            viewModel.List = bussinessLogic.ListTimeline(IdParam);
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View(viewModel);
        }

        //Confirmation proses from IC
        public ActionResult ConfirmFile(string IdParam)
        {
            flag = "2";

            string[] files = IdParam.Split(';');

            var physicalPath = ConfigurationManager.AppSettings["PathICDownload"];
            var physicalPathServer = ConfigurationManager.AppSettings["PathIPT-IC"];

            var viewModel = new ViewModels.InventoryControls.IndexViewModel();
            InventoryControlViewModel modelConfirm = new InventoryControlViewModel();

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    modelConfirm = bussinessLogic.GetFileDet(item);
                    var result = bussinessLogic.SaveFile(modelConfirm, modelConfirm.FileName, modelConfirm.Extension, Convert.ToInt32(modelConfirm.Size), "", flag, Session["UserID"].ToString());

                    //If revised copy to server
                    if (modelConfirm.SuggestDocStatus == SuggestDocStatus.WaitingICApproval)
                    {
                        byte[] fileContent = Converter.GetByteFromFile(physicalPathServer + modelConfirm.FileName);
                        System.IO.File.WriteAllBytes(physicalPath + modelConfirm.FileName, fileContent);
                    }
                }
            }

            //Get Model for Index
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

        //Reject proses from IC
        public ActionResult RejectFile(string IdParam)
        {
            string[] files = IdParam.Split(';');

            var viewModel = new ViewModels.InventoryControls.IndexViewModel();
            InventoryControlViewModel modelConfirm = new InventoryControlViewModel();

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    modelConfirm = bussinessLogic.GetFileDet(item);
                    var result = bussinessLogic.GetDelete(item, Session["UserID"].ToString());
                }
            }

            //Get Model for Index
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        } 

        //Remarks
        public ActionResult Remarks(string IdParam)
        {
            RemarksViewModel model = new RemarksViewModel();
            model = bussinessLogic.GetRemarksDetail(IdParam);
            ViewBag.Title = "Remarks of File Status";
            ViewBag.Header = "Remarks of File Status";

            return View("Remarks", model);
        }

        //Save process for Remarks
        public ActionResult SaveRemarks(RemarksViewModel model)
        {
            //Save remarks
            result = bussinessLogicRemark.SaveRemarksData(model, Session["UserID"].ToString());

            //Get Model for Index
            var viewModel = new ViewModels.InventoryControls.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            return View("Index", viewModel);
        }

        //Index Upload
        public ActionResult IndexUpload()
        {
            var viewModel = bussinessLogic.GetCreateEdit();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            return View(viewModel);
        }     

        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase file, InventoryControlViewModel model)
        {
            ViewBag.Header = "Upload Files";

            try
            {
                if (file != null && file.ContentLength > 0)
                {
                    try
                    {
                        var fileName = Path.GetFileName(file.FileName);
                        var extensionFile = Path.GetExtension(file.FileName);
                        var fileSize = Convert.ToInt32(file.ContentLength);
                        var physicalPath = ConfigurationManager.AppSettings["PathICUpload"];
                        var physicalPathServer = ConfigurationManager.AppSettings["PathIPT-IC"];
                        var physicalPathHist = ConfigurationManager.AppSettings["PathIPTHist-IC"];

                        //Auto rename uploaded suggest files
                        string miliscnd = DateTime.Now.ToString("fffff");   //DateTimeOffset.Now.ToUnixTimeMilliseconds().ToString();
                        string fileNameCustom = DateTime.Now.ToString("yyyyMMdd") + miliscnd + "_" + fileName;

                        if (physicalPath != "" && physicalPathServer!="" && fileName != "")
                        {
                            //If file exists
                            if (System.IO.File.Exists(physicalPath + fileNameCustom))
                            {
                                System.IO.File.Move(physicalPath + fileNameCustom, physicalPathHist + fileNameCustom + ".old");
                            }
                            if (System.IO.File.Exists(physicalPathServer + fileNameCustom))
                            {
                                System.IO.File.Move(physicalPathServer + fileNameCustom, physicalPathHist + fileNameCustom + ".old");
                            }

                            //save file to local
                            physicalPath = Path.Combine(@"" + physicalPath, fileNameCustom);
                            file.SaveAs(physicalPath);
                            //save file to server
                            physicalPathServer = Path.Combine(@"" + physicalPathServer, fileNameCustom);
                            file.SaveAs(physicalPathServer);

                            if (file.ContentLength > 0)
                            {
                                if (fileName.EndsWith(".xlsx") || fileName.EndsWith(".xls"))
                                {
                                    result = bussinessLogic.SaveFile(model, fileNameCustom, extensionFile, fileSize, physicalPath, flag, Session["UserID"].ToString());
                                }
                            }

                            if (result.Message != null)
                            {
                                @ViewBag.Message = result.Message;
                            }

                        }
                        else
                        {
                            @ViewBag.Message = "Unknown extension file.";
                        }
                    }
                    catch (Exception ex)
                    {
                        ViewBag.Message = "ERROR:" + ex.Message.ToString();
                    }
                }
                else
                {
                    ViewBag.Message = "Please select the file to upload.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "ERROR:" + ex.Message.ToString();
            }

            //Get Dropdownlist
            var viewModel = bussinessLogic.GetCreateEdit();
            viewModel.ListCategory = bussinessLogic.GetListCategory();
            viewModel.ListVendor = bussinessLogic.GetListVendor();

            return View("IndexUpload", viewModel);
        }

        public ActionResult Download(string IdParam)
        {
            flag = "1"; //0= New,1= Open
            string[] files = IdParam.Split(';');

            byte[] fileContent = null;
            var physicalPath = ConfigurationManager.AppSettings["PathICDownload"];
            var physicalPathServer = ConfigurationManager.AppSettings["PathIPT-IC"];
            var physicalPathRevise = ConfigurationManager.AppSettings["PathIPT-MD"];

            //Get data model for return Index
            var viewModel = new ViewModels.InventoryControls.IndexViewModel();
            viewModel.List = bussinessLogic.List();
            viewModel.ListStatus = bussinessLogic.GetListStatus();
            viewModel.ListVendor = bussinessLogic.GetListVendor();
            viewModel.ListCategory = bussinessLogic.GetListCategory();

            foreach (var item in files)
            {
                if (item != "" && item != null && item != "true")
                {
                    var model = bussinessLogic.GetFileDet(item);
                    if (model.SuggestDocStatus == SuggestDocStatus.WaitingICApproval)
                    {
                        fileContent = Converter.GetByteFromFile(physicalPathRevise + model.FileName);
                    }
                    else
                    {
                        fileContent = Converter.GetByteFromFile(physicalPathServer + model.FileName);
                    }

                    System.IO.File.WriteAllBytes(physicalPath + model.FileName, fileContent);
                    bussinessLogic.WriteFile(model.FileName, physicalPath + model.FileName);
                }
            }

            return View("Index", viewModel);
        }
    }
}