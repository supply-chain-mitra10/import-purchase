﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Providers.Vendors;
using ViewModels.Vendors;
using ViewModels.ProcessResult;


namespace ImportProjectTracking.Controllers
{
    public class VendorsController : BaseController
    {
        private VendorBussinessLogic bussinessLogic = new VendorBussinessLogic();
        private ProcessResult result = new ProcessResult();

        // GET: Vendors
        public ActionResult Index(string message, IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            var viewModel = new IndexViewModel();
            viewModel.List = bussinessLogic.List(model, page, IdFilter);
            viewModel.Message = message;
            return View(viewModel);
        }

        ////Action Create 
        //public ActionResult CreateVendor()
        //{
        //    var viewModel = bussinessLogic.GetCreateEdit();

        //    ViewBag.Title = "Create Vendor";
        //    ViewBag.Header = "Create Vendor";
        //    return PartialView("CreateEdit", viewModel);
        //}

        ////Action Edit 
        //public ActionResult EditVendor(int IdParam)
        //{
        //    var viewModel = bussinessLogic.GetCreateEdit(IdParam);

        //    ViewBag.Title = "Edit Vendor";
        //    ViewBag.Header = "Edit Vendor";
        //    return PartialView("CreateEdit", viewModel);
        //}

        ////Action Delete 
        //public ActionResult DeleteVendor(int IdParam)
        //{
        //    result = bussinessLogic.GetDelete(IdParam);
        //    return Json(result, JsonRequestBehavior.AllowGet);
        //}

        //[HttpPost]
        //public ActionResult GetSave(CreateEditVendorViewModel model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        ViewBag.Message = "NOTE : Proses save gagal, silahkan lengkapi kembali data anda.";
        //        ViewBag.Header = model.Id == 0 ? "Create Vendor" : "Edit Vendor";

        //        var viewModel = bussinessLogic.GetCreateEdit();

        //        result.ProcessFailed("ValidationError");
        //        return Json(new { result, partialView = RenderPartialViewToString("CreateEdit", viewModel) }, JsonRequestBehavior.AllowGet);
        //    }
        //    result = bussinessLogic.SaveVendor(model, Session["UserID"].ToString());
        //    return Json(new { result }, JsonRequestBehavior.AllowGet);
        //}
    }
}