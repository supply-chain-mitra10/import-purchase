﻿namespace WebServices
{
    public class Class1
    {

    }
}