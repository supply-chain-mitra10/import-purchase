﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Data.OleDb;
using ViewModels.Imports;
using ViewModels.ProcessResult;

namespace Providers.Helper
{
    public class Excel
    {
        //Connection to Excel
        private const string EXCEL_CON = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};" +
                                         @"Extended Properties='Excel 8.0;HDR=Yes;'";
        private const string EXCELX_CON = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};" +
                                         @"Extended Properties='Excel 12.0;HDR=Yes;'";

        public const string TABLE_NAME_PROPERTY = "Template";

        private struct ExcelDataTypes
        {
            public const string NUMBER = "NUMBER";
            public const string DATETIME = "DATETIME";
            public const string STRING = "STRING";
        }

        private struct ClassDataTypes
        {
            public const string SHORT = "int16";
            public const string INT = "int32";
            public const string LONG = "int64";
            public const string STRING = "string";
            public const string DATE = "datetime";
            public const string BOOL = "boolean";
            public const string DECIMAL = "decimal";
        }

        public static ProcessResult ExcelWriter(DataTable dtImport, string fPath, string fExt)
        {
            string strCon = string.Empty;
            switch (fExt)
            {
                case ".xls":   //MS Office 2003-2007 format
                    strCon = string.Format(EXCEL_CON, fPath);
                    break;
                case ".xlsx":   //MS Office 2007-365 format
                    strCon = string.Format(EXCELX_CON, fPath);
                    break;
            }

            using (OleDbConnection conn = new OleDbConnection(strCon))
            {
                try
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = conn;

                    //cmd = new OleDbCommand(getCreateTableCommand(dtImport), conn);
                    //cmd.ExecuteNonQuery();

                    for (int rowIndex = 0; rowIndex < dtImport.Rows.Count; rowIndex++)
                    {
                        //cmd = new OleDbCommand(getInsertCommand(dtImport, rowIndex), conn);
                        cmd = new OleDbCommand(getUpdateCommand(dtImport, rowIndex), conn);
                        cmd.ExecuteNonQuery();
                    }

                    //Re-formating columns Total
                    for (int rowIndex = 1; rowIndex < dtImport.Rows.Count; rowIndex++)
                    {
                        cmd = new OleDbCommand(getUpdateFormat(dtImport, rowIndex), conn);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception error)
                {
                    throw error;
                }
                finally
                {
                    conn.Close();
                    conn.Dispose();
                }
            }

            return null;
        }

        private static string getCreateTableCommand(DataTable dataTable)
        {
            Dictionary<string, string> dataTypeList = getExcelDataTypeList();

            StringBuilder sb = new StringBuilder();
            string sbString = string.Empty;
            sb.AppendFormat("CREATE TABLE [{0}] (", getExcelSheetName(dataTable));
            foreach (DataColumn col in dataTable.Columns)
            {
                string type = ExcelDataTypes.STRING;
                if (dataTypeList.ContainsKey(col.DataType.Name.ToString().ToLower()))
                {
                    type = dataTypeList[col.DataType.Name.ToString().ToLower()];
                }
                sb.AppendFormat("[{0}] {1},", col.Caption.Replace(' ', '_'), type);
            }
            //sb = sb.Replace(',', ')', sb.ToString().LastIndexOf(','), 1);
            sbString = sb.ToString();
            sbString = sbString.Remove(sbString.LastIndexOf(','), 1);
            sbString = sbString + ')';

            //return sb.ToString();
            return sbString;
        }

        private static string getUpdateCommand(DataTable dataTable, int rowIndex)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("UPDATE [{0}$] SET ", getExcelSheetName(dataTable));
            //sb.AppendFormat("[IC_Suggest] = '{0}', ", dataTable.Rows[rowIndex][10].ToString());
            //sb.AppendFormat("[MD_Revise] = '{0}', ", dataTable.Rows[rowIndex][11].ToString());
            sb.AppendFormat("[Calculated_Suggest] = '{0}', ", dataTable.Rows[rowIndex][25].ToString());
            sb.AppendFormat("[Calculated_Stock_Days_Suggest] = '{0}', ", dataTable.Rows[rowIndex][26].ToString());
            sb.AppendFormat("[Calculated_Total_Stock_Days] = '{0}', ", dataTable.Rows[rowIndex][27].ToString());
            sb.AppendFormat("[Revise_MD_Suggest] = '{0}', ", dataTable.Rows[rowIndex][28].ToString());
            sb.AppendFormat("[Revise_MD_Stock_Days_Suggest] = '{0}', ", dataTable.Rows[rowIndex][29].ToString());
            sb.AppendFormat("[Revise_MD_Total_Stock_Days] = '{0}', ", dataTable.Rows[rowIndex][30].ToString());
            sb.AppendFormat("[IC_Suggest_Total_Qty] = '{0}', ", dataTable.Rows[rowIndex][31].ToString());
            sb.AppendFormat("[IC_Suggest_Total_CBM] = '{0}', ", dataTable.Rows[rowIndex][32].ToString());
            sb.AppendFormat("[MD_Revise_Total_Qty] = '{0}', ", dataTable.Rows[rowIndex][33].ToString());
            sb.AppendFormat("[MD_Revise_Total_CBM] = '{0}' ", dataTable.Rows[rowIndex][34].ToString());
            sb.AppendFormat("WHERE [Item_No] = '{0}'", dataTable.Rows[rowIndex][6].ToString());

            return sb.ToString();
        }

        private static string getUpdateFormat(DataTable dataTable, int rowIndex)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("UPDATE [{0}$] SET ", getExcelSheetName(dataTable));
            sb.AppendFormat("[IC_Suggest_Total_Qty] = '', ");
            sb.AppendFormat("[IC_Suggest_Total_CBM] = '', ");
            sb.AppendFormat("[MD_Revise_Total_Qty] = '', ");
            sb.AppendFormat("[MD_Revise_Total_CBM] = '' ");
            sb.AppendFormat("WHERE [Item_No] = '{0}'", dataTable.Rows[rowIndex][6].ToString());

            return sb.ToString();
        }

        private static string getInsertCommand(DataTable dataTable, int rowIndex)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("INSERT INTO [{0}$](", getExcelSheetName(dataTable));
            foreach (DataColumn col in dataTable.Columns)
            {
                sb.AppendFormat("[{0}],", col.Caption.Replace(' ', '_'));
            }
            sb = sb.Replace(',', ')', sb.ToString().LastIndexOf(','), 1);
            sb.Append("VALUES (");
            foreach (DataColumn col in dataTable.Columns)
            {
                sb.AppendFormat("'{0}',", dataTable.Rows[rowIndex][col].ToString());
            }
            sb = sb.Replace(',', ')', sb.ToString().LastIndexOf(','), 1);

            return sb.ToString();
        }

        private static string getExcelSheetName(DataTable dataTable)
        {
            string retVal = dataTable.TableName;
            if (dataTable.ExtendedProperties.ContainsKey(TABLE_NAME_PROPERTY))
            {
                retVal = dataTable.ExtendedProperties[TABLE_NAME_PROPERTY].ToString();
            }
            return retVal.Replace(' ', '_');
        }

        private static Dictionary<string, string> getExcelDataTypeList()
        {
            Dictionary<string, string> dataTypeList = new Dictionary<string, string>();

            dataTypeList.Add(ClassDataTypes.SHORT, ExcelDataTypes.NUMBER);
            dataTypeList.Add(ClassDataTypes.INT, ExcelDataTypes.NUMBER);
            dataTypeList.Add(ClassDataTypes.LONG, ExcelDataTypes.NUMBER);
            dataTypeList.Add(ClassDataTypes.STRING, ExcelDataTypes.STRING);
            dataTypeList.Add(ClassDataTypes.DATE, ExcelDataTypes.DATETIME);
            dataTypeList.Add(ClassDataTypes.BOOL, ExcelDataTypes.STRING);
            dataTypeList.Add(ClassDataTypes.DECIMAL, ExcelDataTypes.NUMBER);

            return dataTypeList;
        }

    }
}
