﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using iText.IO.Image;
using iText.Kernel.Colors;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Action;
using iText.Kernel.Pdf.Canvas.Draw;
using iText.Kernel.Pdf.Xobject;
using iText.Kernel.Geom;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Barcodes;

namespace Providers.Helper
{
    public class PDFGenerator
    {
        //Generate PDF Template

        //For MD PI Download
        public static void ProformaInvoice(string fPath, DataTable dataRaw)
        {
            //string headerText = "Performa Invoice";

            PdfWriter writer = new PdfWriter(fPath);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            //Page Orientation
            pdf.SetDefaultPageSize(PageSize.A4.Rotate());

            //// Add image
            //Image img = new Image(ImageDataFactory
            //   .Create(@"..\..\Mitra10_logo2.png"))
            //   .SetTextAlignment(TextAlignment.CENTER);          

            //Add Header
            Paragraph header = new Paragraph("Quotation")
               .SetTextAlignment(TextAlignment.CENTER)
               .SetFontSize(20);

            //Add New line
            Paragraph newline = new Paragraph(new Text("\n"));

            //Add Table
            Table table = new Table(6, false);

            //Add Table Header
            Cell cell11 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.GRAY)
               .SetTextAlignment(TextAlignment.CENTER)
               .Add(new Paragraph("No."));
            Cell cell12 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.GRAY)
               .SetTextAlignment(TextAlignment.CENTER)
               .Add(new Paragraph("Item Code"));
            Cell cell13 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.GRAY)
               .SetTextAlignment(TextAlignment.CENTER)
               .Add(new Paragraph("Item Name"));
            Cell cell14 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.GRAY)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(100)
               .Add(new Paragraph("Quantity"));
            Cell cell15 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.GRAY)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(100)
               .Add(new Paragraph("CBM"));
            Cell cell16 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.GRAY)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(100)
               .Add(new Paragraph("Price"));

            table.AddCell(cell11);
            table.AddCell(cell12);
            table.AddCell(cell13);
            table.AddCell(cell14);
            table.AddCell(cell15);
            table.AddCell(cell16);

            foreach (DataRow row in dataRaw.Rows)
            {
                table.AddCell(new Paragraph(row["No."].ToString()));
                table.AddCell(new Paragraph(row["Item Code"].ToString()));
                table.AddCell(new Paragraph(row["Item Name"].ToString()));
                table.AddCell(new Paragraph(row["Quantity"].ToString()));
                table.AddCell(new Paragraph(row["CBM"].ToString()));
                table.AddCell(new Paragraph(row["Price"].ToString()));
            }

            //Format PDF Page
            //document.Add(img);
            document.Add(header);
            document.Add(newline);
            document.Add(table);

            //Add Page numbers
            int n = pdf.GetNumberOfPages();
            for (int i = 1; i <= n; i++)
            {
                document.ShowTextAligned(new Paragraph(String
                   .Format("page" + i + " of " + n)),
                   806, 559, i, TextAlignment.RIGHT,    //x=559 y=806 Alignment Top of page
                   VerticalAlignment.TOP, 0);
            }

            //Close document
            document.Close();
        }

        //For Import PO Download
        public static void PurchaseOrder(string fPath, DataTable po, string poNumber)
        {
            PdfWriter writer = new PdfWriter(fPath);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            //Page Orientation
            pdf.SetDefaultPageSize(PageSize.A4.Rotate());

            //Add Header
            Paragraph header = new Paragraph("Purchase Order")
               .SetTextAlignment(TextAlignment.CENTER)
               .SetFontSize(20);

            //Add New line
            Paragraph newline = new Paragraph(new Text("\n"));

            Barcode128 code128 = new Barcode128(pdf);
            code128.SetCode(poNumber);
            code128.SetCodeType(Barcode128.CODE128);
            PdfFormXObject barcodeObject = code128.CreateFormXObject(null, null, pdf);

            // Add image
            Image img = new Image(barcodeObject)
               .SetFixedPosition(365, 490); //Potrait(236, 730)

            //Add Table Headers
            Table tableH = new Table(3, false);

            Cell cell11 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(250)
               .Add(new Paragraph("Company Information :"));
            Cell cell12 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(250)
               .Add(new Paragraph("To :"));
            Cell cell13 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(250)
               .Add(new Paragraph("Deliver To :"));

            //Add Table Details
            Table table = new Table(10, false);

            Cell cell21 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(50)
               .Add(new Paragraph("No."));
            Cell cell22 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(100)
               .Add(new Paragraph("Item Code"));
            Cell cell23 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(50)
               .Add(new Paragraph("LV"));
            Cell cell24 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(200)
               .Add(new Paragraph("Item Name"));
            Cell cell25 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(150)
               .Add(new Paragraph("UOM"));
            Cell cell26 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(50)
               .Add(new Paragraph("Qty Order"));
            Cell cell27 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(150)
               .Add(new Paragraph("Unit Price"));
            Cell cell28 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(50)
               .Add(new Paragraph("EXTRA"));
            Cell cell29 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(50)
               .Add(new Paragraph("Disc. (%)"));
            Cell cell30 = new Cell(1, 1)
               .SetBackgroundColor(ColorConstants.WHITE)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetWidth(150)
               .Add(new Paragraph("Total"));

            tableH.AddCell(cell11);
            tableH.AddCell(cell12);
            tableH.AddCell(cell13);
            //Header Data
            tableH.AddCell(new Paragraph("PT. CATUR MITRA SEJATI SENTOSA"));
            tableH.AddCell(new Paragraph(po.Columns["To"].ToString()));
            tableH.AddCell(new Paragraph(po.Columns["Deliver To"].ToString()));

            table.AddCell(cell21);
            table.AddCell(cell22);
            table.AddCell(cell23);
            table.AddCell(cell24);
            table.AddCell(cell25);
            table.AddCell(cell26);
            table.AddCell(cell27);
            table.AddCell(cell28);
            table.AddCell(cell29);
            table.AddCell(cell30);
            //Items Data
            //foreach (DataRow row in po.Rows)
            //{
            //    table.AddCell(new Paragraph(row["No."].ToString()));
            //    table.AddCell(new Paragraph(row["Item Code"].ToString()));
            //    table.AddCell(new Paragraph(row["Item Name"].ToString()));
            //    table.AddCell(new Paragraph(row["Quantity"].ToString()));
            //    table.AddCell(new Paragraph(row["CBM"].ToString()));
            //    table.AddCell(new Paragraph(row["Price"].ToString()));
            //}

            //Format PDF Page
            document.Add(header);
            document.Add(newline);
            document.Add(img);
            document.Add(newline);
            document.Add(tableH);
            document.Add(newline);
            document.Add(table);

            //Add Created Date
            //document.ShowTextAligned(new Paragraph(String.Format("{0:MM/dd/yyyy}", DateTime.Now)), 
            //    559, 800, TextAlignment.RIGHT, VerticalAlignment.TOP);

            //Add Page numbers
            int n = pdf.GetNumberOfPages();
            for (int i = 1; i <= n; i++)
            {
                document.ShowTextAligned(new Paragraph(String
                   .Format("page" + i + " of " + n)),
                   806, 559, i, TextAlignment.RIGHT,    //x=559 y=806 Alignment Top of page
                   VerticalAlignment.TOP, 0);
            }

            //Close document
            document.Close();
        }

    }
}