﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Data.OleDb;
using ViewModels.Imports;
using ViewModels.ProformaInvoices;
using ViewModels.PurchaseOrders;
using ViewModels.ReceivingPO;
using iText.StyledXmlParser.Jsoup.Nodes;

namespace Providers.Helper
{
    public class Converter
    {
        //Connection to Excel
        private const string EXCEL_CON = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};" +
                                         @"Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
        private const string EXCELX_CON = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};" +
                                         @"Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";

        //Get Byte value from File
        public static byte[] GetByteFromFile(string fPath)
        {
            // get all the bytes of the file into memory  
            byte[] fContents = File.ReadAllBytes(fPath);
            return fContents;
        }

        //Get Interval of DateTime in Month
        public static int GetTotalMonthsFrom(DateTime dt1, DateTime dt2)
        {
            DateTime earlyDate = (dt1 > dt2) ? dt2.Date : dt1.Date;
            DateTime lateDate = (dt1 > dt2) ? dt1.Date : dt2.Date;

            // Start with 1 month's difference and keep incrementing
            // until we overshoot the late date
            int monthsDiff = 1;
            while (earlyDate.AddMonths(monthsDiff) <= lateDate)
            {
                monthsDiff++;
            }

            return monthsDiff - 1;
        }

        //Get File type
        public static string GetFileTypeByExtension(string ext)
        {
            switch (ext.ToLower())
            {
                case ".doc":
                case ".docx":
                    return "Microsoft Word Document";
                case ".xls":
                case ".xlsx":
                    return "Microsoft Excel Document";
                case ".ppt":
                case ".pptx":
                    return "Microsoft Power Point Document";
                case ".txt":
                    return "Text Document";
                case ".csv":
                    return "Comma Separated Value Document";
                case ".pdf":
                    return "PDF";
                case ".jpg":
                case ".png":
                    return "Image";
                default:
                    return "Unknown";
            }
        }

        //Get data table from Excel to data table
        public static DataTable ExcelToDataTable(string fullFilename, string Extension, string tableName, string colName)
        {
            var table = new DataTable();
            DataSet ds = new DataSet();
            string strCon = string.Empty;

            switch (Extension)
            {
                case ".xls":   //MS Office 2003-2007 format
                    strCon = string.Format(EXCEL_CON, fullFilename);
                    break;
                case ".csv":
                case ".xlsx":   //MS Office 2007-365 format
                    strCon = string.Format(EXCELX_CON, fullFilename);
                    break;
            }

            using (var con = new System.Data.OleDb.OleDbConnection(strCon))
            {
                ConnectionState initialState = con.State;
                try
                {
                    if ((initialState & ConnectionState.Open) != ConnectionState.Open)
                    {
                        con.Open();
                    }
                    string sql = string.Format("SELECT * FROM [{0}$] WHERE {1} IS NOT NULL;", tableName, colName);
                    OleDbDataAdapter da = new OleDbDataAdapter(sql, con);
                    da.Fill(ds);
                    table = ds.Tables[0];
                }
                finally
                {
                    if ((initialState & ConnectionState.Open) != ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
            }
            return table;
        }

        //Get forecast data from data table
        public static List<SuggestDetailViewModel> ForecastData(DataTable dataImport)
        {
            List<SuggestDetailViewModel> fData = new List<SuggestDetailViewModel>();

            fData = (from DataRow excelRow in dataImport.Rows
                     select new SuggestDetailViewModel()
                     {
                         SiteNo = excelRow["Site_No"].ToString(),
                         SiteName = excelRow["Site_Name"].ToString(),
                         Category = excelRow["Item_Category"].ToString(),
                         VendorNo = excelRow["Vendor_No"].ToString(),
                         VendorName = excelRow["Vendor_Name"].ToString(),
                         MasterBrand = excelRow["Item_MasterBrand"].ToString(),
                         ItemNo = excelRow["Item_No"].ToString(),
                         ItemName = excelRow["Item_Name"].ToString(),
                         SystemSuggestQty = Convert.ToDecimal( (excelRow["System_Suggested_Quantity"] is DBNull) ? 0 : excelRow["System_Suggested_Quantity"] ),
                         AverageSales = Convert.ToDecimal( (excelRow["Average_Sales"] is DBNull) ? 0 : excelRow["Average_Sales"] ),
                         LeadTime = Convert.ToInt32( (excelRow["Lead_Time"] is DBNull) ? 0 : excelRow["Lead_Time"] ),
                         HighestAvgLeadTimeActual = Convert.ToInt32( (excelRow["Highest_Avg_Lead_Time_Actual"] is DBNull) ? 0 : excelRow["Highest_Avg_Lead_Time_Actual"] ),
                         SafetyStockDays = Convert.ToDecimal( (excelRow["Safety_Stock_Days"] is DBNull) ? 0 : excelRow["Safety_Stock_Days"] ),
                         OrderPeriod = Convert.ToDecimal( (excelRow["Order_Period"] is DBNull) ? 0 : excelRow["Order_Period"] ),
                         MinimumStock = Convert.ToDecimal( (excelRow["Minimum_Stock"] is DBNull) ? 0 : excelRow["Minimum_Stock"] ),
                         MaximumStock = Convert.ToDecimal( (excelRow["Maximum_Stock"] is DBNull) ? 0 : excelRow["Maximum_Stock"] ),
                         ReorderPoint = Convert.ToInt32( (excelRow["Reorder_Point"] is DBNull) ? 0 : excelRow["Reorder_Point"] ),
                         OptimumMax = Convert.ToInt32( (excelRow["Optimum_Max"] is DBNull) ? 0 : excelRow["Optimum_Max"] ),
                         OptimumMaxMultiple = Convert.ToInt32( (excelRow["Optimum_Max_Multiple"] is DBNull) ? 0 : excelRow["Optimum_Max_Multiple"] ),
                         StockOnHand = Convert.ToDecimal( (excelRow["Stock_On_Hand"] is DBNull) ? 0 : excelRow["Stock_On_Hand"] ),
                         OutstandingPO = Convert.ToDecimal( (excelRow["Outstanding_PO"] is DBNull) ? 0 : excelRow["Outstanding_PO"] ),
                         OutstandingTR = Convert.ToDecimal( (excelRow["Outstanding_TR"] is DBNull) ? 0 : excelRow["Outstanding_TR"] ),
                         OutstandingTO = Convert.ToDecimal( (excelRow["Outstanding_TO"] is DBNull) ? 0 : excelRow["Outstanding_TO"] ),
                         MultiplePurchaseQty = Convert.ToInt32( (excelRow["Multiple_Purchase_Qty"] is DBNull) ? 0 : excelRow["Multiple_Purchase_Qty"] ),
                         OutstandingTRfromOtherStore = Convert.ToInt32( (excelRow["Outstanding_TR_from_other_Store"] is DBNull) ? 0 : excelRow["Outstanding_TR_from_other_Store"] )
                     }).ToList();

            return fData;
        }

        //Get PI Number data from data table
        public static List<CreateEditProformaInvoiceViewModel> PIData(DataTable dataImport)
        {
            List<CreateEditProformaInvoiceViewModel> fData = new List<CreateEditProformaInvoiceViewModel>();

            fData = (from DataRow excelRow in dataImport.Rows
                     select new CreateEditProformaInvoiceViewModel()
                     {
                         ItemNo = excelRow["Item_No"].ToString(),
                         ProformaInvoiceNo = excelRow["Invoice_No"].ToString(),
                         VendorNo = excelRow["Vendor_No"].ToString(),
                         VendorItemCode = excelRow["Vendor_Item_Code"].ToString(),
                         HSCode = excelRow["HS_Code"].ToString(),
                         Description = excelRow["Description"].ToString(),
                         Quantity = Convert.ToInt32(excelRow["Qty"].ToString()),
                         TotalCBM = Convert.ToDecimal(excelRow["Total_CBM"].ToString()),
                         CurrencyCodeLocale = excelRow["Currency"].ToString(),
                         UnitPrice = Convert.ToDecimal(excelRow["Unit_Price"].ToString()),
                         ProformaInvoiceDate = Convert.ToDateTime(excelRow["Invoice_Date"].ToString())
                     }).ToList();

            return fData;
        }

        //Get PO Number data from data table
        public static List<PurchaseOrderDetailsViewModel> POData(DataTable dataImport)
        {
            List<PurchaseOrderDetailsViewModel> fData = new List<PurchaseOrderDetailsViewModel>();

            fData = (from DataRow excelRow in dataImport.Rows
                     select new PurchaseOrderDetailsViewModel()
                     {
                         PurchaseOrderNo = excelRow["NO_PO"].ToString(),
                         //PODate = Convert.ToDateTime(excelRow["PO_DATE"].ToString()), //Header
                         ItemNo = excelRow["ITEM_CODE"].ToString(),
                         LV = excelRow["LV"].ToString(),
                         //ItemName = excelRow["ITEM_NAME"].ToString(),
                         UOM = excelRow["UOM"].ToString(),
                         QuantityOrder = Convert.ToInt32(excelRow["QTY_ORD"].ToString()),
                         UnitPrice = Convert.ToDecimal(excelRow["UNIT_PRICE"].ToString()),
                         Extra = (excelRow["EXTRA"].ToString() == "No") ? false : true,
                         Discount = Convert.ToDecimal(excelRow["DISCOUNT"].ToString()),
                         Total = Convert.ToDecimal(excelRow["TOTAL"].ToString()),
                         //TermOfPayment = excelRow["TERM_OF_PAYMENT"].ToString(),                                          //Header
                         //LeadTimeDeliveryExpire = Convert.ToDateTime(excelRow["LEAD_TIME_DELIVERY_DEADLINE"].ToString()),
                         //PODateExpire = Convert.ToDateTime(excelRow["EXPIRED_PO_DATE"].ToString()),
                         //IdVendor = excelRow["VENDOR"].ToString(),
                         //DeliverTo = excelRow["DELIVER_TO"].ToString()
                     }).ToList();

            return fData;
        }

        //Get receiving PO data from data table
        public static List<CreateEditReceivingPOViewModel> ReceivingPOData(DataTable dataImport)
        {
            List<CreateEditReceivingPOViewModel> fData = new List<CreateEditReceivingPOViewModel>();

            fData = (from DataRow excelRow in dataImport.Rows
                     select new CreateEditReceivingPOViewModel()
                     {
                         ReceivingPONo = excelRow["Document_No_"].ToString(),
                         SiteNo = excelRow["Store_No_"].ToString(),
                         VendorNo = excelRow["Vendor_No_"].ToString(),
                         //VendorName = excelRow["Vendor_Name"].ToString(),
                         Comment = (excelRow["Comment"] is DBNull)? "" : excelRow["Comment"].ToString(),
                         AuditUsername = excelRow["User_ID"].ToString(),
                         PostingDate = Convert.ToDateTime(excelRow["Posting_Date"].ToString()),
                         VendorInvNo = (excelRow["Vendor_Inv__No_"] is DBNull) ? "" : excelRow["Vendor_Inv__No_"].ToString(),
                         PurchaseOrderNo = excelRow["Purchase_Order_No_"].ToString(),
                         GRNo = (excelRow["GR_No"] is DBNull)? "" : excelRow["GR_No"].ToString(),
                         ItemNo = (excelRow["Item_No_"] is DBNull) ? "" : excelRow["Item_No_"].ToString(),
                         //BarcodeNo = excelRow["Barcode_No_"].ToString(),
                         //ItemName = (excelRow["Item_Name"] is DBNull) ? "" : excelRow["Item_Name"].ToString(),
                         UOM = (excelRow["Unit_of_Measure_Code"] is DBNull) ? "" : excelRow["Unit_of_Measure_Code"].ToString(),
                         Category = excelRow["Category"].ToString(),
                         SubCategory = excelRow["Sub_Category"].ToString(),
                         MasterBrand = excelRow["Master_Brand"].ToString(),
                         Brand = excelRow["Brand"].ToString(),
                         Type = excelRow["Type"].ToString(),
                         Quantity = Convert.ToInt32((excelRow["Qty"] is DBNull) ? 0 : excelRow["Qty"]),
                     }).ToList();

            return fData;
        }

    }
}
