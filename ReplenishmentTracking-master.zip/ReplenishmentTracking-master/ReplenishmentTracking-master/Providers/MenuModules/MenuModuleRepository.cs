﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.MenuModules;
using ViewModels.ProcessResult;
using Providers.Helper;
using ViewModels.MenuCategorys;
using ViewModels.Commons;

namespace Providers.MenuModules
{
    public class MenuModuleRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all menu from DB
        public IEnumerable<mt_MenuModule> AllMenuModule()
        {
            return entities.mt_MenuModule;
        }

        //Get selected menu module
        public mt_MenuModule GetMenuModule(string MenuModuleNo)
        {
            return entities.mt_MenuModule.SingleOrDefault(m => m.MenuModuleNo == MenuModuleNo);
        }

        //Delete using Json
        public int GetDeleteMenuModule(string MenuModuleNo)
        {
            return entities.mt_MenuModule.Where(m => m.MenuModuleNo == MenuModuleNo).Count();
        }

        //Insert new menu module
        public void InsertMenuModule(CreateEditMenuModuleViewModel model, string userLogon)
        {
            //get latest ID for auto generate
            var latestID = entities.mt_MenuModule.OrderByDescending(m => m.MenuModuleNo).FirstOrDefault();

            try
            {
                var insertMenu = new mt_MenuModule()
                {
                    MenuModuleNo = model.MenuModuleNo,
                    MenuModuleName = model.MenuModuleName,
                    AuditActivity = AuditActivity.Insert,
                    AuditDateTime = DateTime.Now,
                    AuditUsername = userLogon,
                    IsActive = true
                };
                entities.mt_MenuModule.Add(insertMenu);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen menu
        public void UpdateMenuModule(CreateEditMenuModuleViewModel model, string userLogin)
        {
            try
            {
                var updateData = entities.mt_MenuModule.SingleOrDefault(m => m.MenuModuleNo == model.MenuModuleNo);
                updateData.MenuModuleNo = model.MenuModuleNo;
                updateData.MenuModuleName = model.MenuModuleNo;
                updateData.AuditActivity = AuditActivity.Update;
                updateData.AuditDateTime = DateTime.Now;
                updateData.AuditUsername = userLogin;
                updateData.IsActive = model.IsActive;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Delete choosen menu
        public void DeleteMenuModule(string MenuModuleNo)
        {
            try
            {
                var deleteMenu = entities.mt_MenuModule.SingleOrDefault(m => m.MenuModuleNo == MenuModuleNo);
                entities.mt_MenuModule.Remove(deleteMenu);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
