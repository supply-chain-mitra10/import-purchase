﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.MenuModules;
using ViewModels.ProcessResult;
using System.Configuration;

namespace Providers.MenuModules
{
    public class MenuCategoryBussinessLogic
    {
        private MenuModuleRepository repository = new MenuModuleRepository();
        private ProcessResult result = new ProcessResult();

        //Get menu list to display
        public List<MenuModuleViewModel> List(IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from menu in repository.AllMenuModule()
                        where menu.MenuModuleNo.ToString().Contains(IdFilter == null ? "" : IdFilter.Value.ToString())
                        select new MenuModuleViewModel()
                        {
                            MenuModuleNo = menu.MenuModuleNo,
                            MenuModuleName = menu.MenuModuleName,
                            AuditActivity = Convert.ToChar(menu.AuditActivity),
                            AuditDateTime = menu.AuditDateTime,
                            AuditUsername = menu.AuditUsername,
                            IsActive = menu.IsActive
                        };

            return query.ToList();
        }


        //Create method for new menu
        public CreateEditMenuModuleViewModel GetCreateEdit()
        {
            CreateEditMenuModuleViewModel viewModel = new CreateEditMenuModuleViewModel();
            return viewModel;
        }

        //Edit method for edited menu
        public CreateEditMenuModuleViewModel GetCreateEdit(string MenuModuleNo)
        {
            var menu = repository.GetMenuModule(MenuModuleNo);
            CreateEditMenuModuleViewModel viewModel = new CreateEditMenuModuleViewModel();

            viewModel.MenuModuleNo = menu.MenuModuleNo;
            viewModel.MenuModuleName = menu.MenuModuleName;
            viewModel.AuditActivity = Convert.ToChar(menu.AuditActivity);
            viewModel.AuditDateTime = menu.AuditDateTime;
            viewModel.AuditUsername = menu.AuditUsername;
            viewModel.IsActive = menu.IsActive;

            return viewModel;
        }

        //Delete method for one menu
        public ProcessResult GetDelete(string MenuModuleNo)
        {
            try
            {
                repository.GetDeleteMenuModule(MenuModuleNo);
                result.DeleteSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new menu
        public ProcessResult SaveMenu(CreateEditMenuModuleViewModel model, string userLogin)
        {
            try
            {
                if (model.MenuModuleNo == string.Empty || model.MenuModuleNo == "")
                {
                    repository.InsertMenuModule(model, userLogin);
                    result.InsertSucceed();
                }
                else
                {
                    repository.UpdateMenuModule(model, userLogin);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }
    }
}
