﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.Commons;
using ViewModels.Items;
using ViewModels.ProcessResult;

namespace Providers.Items
{
    public class ItemRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all Item from DB
        public IEnumerable<mt_Item> AllItem()
        {
            return entities.mt_Item;
        }

        //Get selected Item
        public mt_Item GetItem(string itemNo)
        {
            return entities.mt_Item.SingleOrDefault(m => m.ItemNo == itemNo);
        }
        //public mt_Item GetItemByCode(string ItemCode)
        //{
        //    return entities.mt_Item.SingleOrDefault(m => m.ItemCode == ItemCode);
        //}

        //Delete using Json
        public int GetDeleteItem(string itemNo)
        {
            return entities.mt_Item.Where(m => m.ItemNo == itemNo).Count();
        }

        //Insert new Item
        public void InsertItem(CreateEditItemViewModel model, string userLogon)
        {
            //get latest ID for auto generate
            var latestID = entities.mt_Item.OrderByDescending(m => m.ItemNo).FirstOrDefault();
            int counterID = Convert.ToInt32(latestID.ItemNo.Substring(3, 3)) + 1;

            try
            {
                var insertItem = new mt_Item()
                {
                    ItemNo = model.ItemNo,
                    ItemName = model.ItemName,
                    Barcode = model.Barcode,
                    UOM = model.UOM,
                    QtyUnit = model.QtyUnit,
                    Height = model.Height,
                    Width = model.Width,
                    Length = model.Length,
                    Cubage = model.Cubage,
                    Weight = model.Weight,
                    Description = model.Description,
                    AuditActivity = AuditActivity.Insert,
                    AuditDateTime = DateTime.Now,
                    AuditUsername = userLogon,
                    IsActive = model.IsActive
                };
                entities.mt_Item.Add(insertItem);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen Item
        public void UpdateItem(CreateEditItemViewModel model)
        {
            try
            {
                var updateData = entities.mt_Item.SingleOrDefault(m => m.ItemNo == model.ItemNo);
                updateData.ItemNo = model.ItemNo;
                updateData.ItemName = model.ItemName;
                updateData.Barcode = model.Barcode;
                updateData.UOM = model.UOM;
                updateData.QtyUnit = model.QtyUnit;
                updateData.Height = model.Height;
                updateData.Width = model.Width;
                updateData.Length = model.Length;
                updateData.Cubage = model.Cubage;
                updateData.Weight = model.Weight;
                updateData.Description = model.Description;
                updateData.IsActive = model.IsActive;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Delete choosen Item
        public void DeleteItem(string itemNo)
        {
            try
            {
                var deleteItem = entities.mt_Item.SingleOrDefault(m => m.ItemNo == itemNo);
                entities.mt_Item.Remove(deleteItem);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
