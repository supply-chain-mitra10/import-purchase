﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.Items;
using ViewModels.ProcessResult;
using System.Configuration;

namespace Providers.Items
{
    public class ItemBussinessLogic
    {
        private ItemRepository repository = new ItemRepository();
        private ProcessResult result = new ProcessResult();

        //Get Status list to display
        public List<ItemViewModel> List(IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from itm in repository.AllItem()
                        where itm.ItemNo.ToString().Contains(IdFilter == null ? "" : IdFilter.Value.ToString())
                        select new ItemViewModel()
                        {
                            ItemNo = itm.ItemNo,
                            ItemName = itm.ItemName,
                            Barcode = itm.Barcode,
                            UOM = itm.UOM,
                            QtyUnit = itm.QtyUnit,
                            Height = itm.Height,
                            Width = itm.Width,
                            Length = itm.Length,
                            Cubage = itm.Cubage,
                            Weight = itm.Weight,
                            Description = itm.Description,
                            AuditActivity = Convert.ToChar(itm.AuditActivity),
                            AuditDateTime = itm.AuditDateTime,
                            AuditUsername = itm.AuditUsername,
                            IsActive = itm.IsActive
                        };

            return query.ToList();
        }

        //Create method for new item
        public CreateEditItemViewModel GetCreateEdit()
        {
            CreateEditItemViewModel viewModel = new CreateEditItemViewModel();
            return viewModel;
        }

        //Edit method for edited item
        public CreateEditItemViewModel GetCreateEdit(string itemNo)
        {
            var status = repository.GetItem(itemNo);
            CreateEditItemViewModel viewModel = new CreateEditItemViewModel();

            viewModel.ItemNo = status.ItemNo;
            viewModel.ItemName = status.ItemName;
            viewModel.Barcode = status.Barcode;
            viewModel.UOM = status.UOM;
            viewModel.QtyUnit = status.QtyUnit;
            viewModel.Height = status.Height;
            viewModel.Width = status.Width;
            viewModel.Length = status.Length;
            viewModel.Cubage = status.Cubage;
            viewModel.Weight = status.Weight;
            viewModel.Description = status.Description;
            viewModel.IsActive = status.IsActive;

            return viewModel;
        }

        //Delete method for one item
        public ProcessResult GetDelete(string itemNo)
        {
            try
            {
                repository.DeleteItem(itemNo);
                result.DeleteSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new item
        public ProcessResult SaveItem(CreateEditItemViewModel model, string userLogin)
        {
            try
            {
                if (model.ItemNo == string.Empty || model.ItemNo == "")
                {
                    repository.InsertItem(model, userLogin);
                    result.InsertSucceed();
                }
                else
                {
                    repository.UpdateItem(model);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }
    }
}
