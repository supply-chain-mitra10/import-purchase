﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.ProformaInvoices;
using ViewModels.ProcessResult;
using ViewModels.Commons;

namespace Providers.ProformaInvoices
{
    public class ProformaInvoiceRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get selected File
        public tr_SuggestHeader GetFileByDocNo(string DocNo)
        {
            return entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo);
        }
        //public tr_SuggestHeader GetFileByCode(string fCode)
        //{
        //    return entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == fCode);
        //}

        //Get all PI from DB
        public IEnumerable<tr_ProformaInvoiceHeader> AllPI()
        {
            return entities.tr_ProformaInvoiceHeader.Where(m => m.IsActive == true);
        }

        //Get all PI Number for Dropdownlist
        public IEnumerable<string> AllPINumber()
        {
            return entities.tr_ProformaInvoiceHeader.Where(m => m.IsActive == true).Select(m => m.ProformaInvoiceNo).Distinct();
        }

        //Get selected PI
        public tr_ProformaInvoiceHeader GetPI(string NoInvoice)
        {
            return entities.tr_ProformaInvoiceHeader.SingleOrDefault(m => m.ProformaInvoiceNo == NoInvoice);
        }
        public tr_ProformaInvoiceHeader GetPIById(string DocNo)
        {
            return entities.tr_ProformaInvoiceHeader.SingleOrDefault(m => m.QuotationNo == DocNo);
        }
        public tr_ProformaInvoiceHeader GetPIByDocNo(string DocNo)
        {
            return entities.tr_ProformaInvoiceHeader.SingleOrDefault(m => m.QuotationNo == DocNo);
        }

        //Get PI check Image uploaded
        public IEnumerable<tr_ProformaInvoiceHeader> GetPIImageUploadByIdFile(string DocNo)
        {
            return entities.tr_ProformaInvoiceHeader.Where(m => m.QuotationNo == DocNo && m.VendorPIUploaded == true);
        }
        public tr_ProformaInvoiceDetails GetPIByItemCodeAndIdFile(string DocNo, string ItemNo)
        {
            var headerPI = entities.tr_ProformaInvoiceHeader.SingleOrDefault(m => m.QuotationNo == DocNo);
            return entities.tr_ProformaInvoiceDetails.SingleOrDefault(m => m.ProformaInvoiceNo == headerPI.ProformaInvoiceNo && m.ItemNo == ItemNo);
        }


        //Delete using Json
        public int GetDeletePI(string PINo)
        {
            return entities.tr_ProformaInvoiceHeader.Where(m => m.ProformaInvoiceNo == PINo && m.IsActive == true).Count();
        }

        //Insert new PI (by Upload)
        public void InsertPI(string DocNo, List<CreateEditProformaInvoiceViewModel> pi, string userLogon)
        {
            try
            {
                bool flagPI = false;
                List<CreateEditProformaInvoiceViewModel> itemPI = pi.OrderBy(m => m.ItemNo).ToList();
                var itemData = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == DocNo).OrderBy(x => x.ItemNo).ToList();

                //Validation for Suggest and PI
                for (int i = 0; i < itemPI.Count(); i++)
                {
                    if (itemPI[i].ItemNo == itemData[i].ItemNo)
                    {
                        flagPI = true;
                    }
                    else
                    {
                        flagPI = false;
                    }
                }

                //foreach (var itemPI in pi.OrderBy(m => m.ItemNo))
                //{
                //    foreach (var itemSuggest in itemData)
                //    {
                //        if (itemPI.ItemNo == itemSuggest.ItemNo)
                //        {
                //            flagPI = true;
                //        }
                //        else
                //        {
                //            flagPI = false;
                //        }
                //    }
                //}

                if (flagPI)
                {
                    //Header
                    for (int i = 0; i < pi.Count; i++)
                    {
                        var insertPIHeader = new tr_ProformaInvoiceHeader()
                        {
                            ProformaInvoiceNo = pi[i].ProformaInvoiceNo,
                            ProformaInvoiceDate = pi[i].ProformaInvoiceDate,
                            PIPath = pi[i].PIPath,
                            VendorPIPath = pi[i].VendorPIPath,
                            VendorPIUploaded = pi[i].VendorPIUploaded,
                            QuotationNo = DocNo,
                            VendorNo = pi[i].VendorNo,
                            AuditActivity = AuditActivity.Insert,
                            AuditDateTime = DateTime.Now,
                            AuditUsername = userLogon,
                            IsActive = true
                        };
                        entities.tr_ProformaInvoiceHeader.Add(insertPIHeader);
                    }
                    entities.SaveChanges();

                    //Details
                    for (int i = 0; i < pi.Count; i++)
                    {
                        var insertPIDetails = new tr_ProformaInvoiceDetails()
                        {
                            ProformaInvoiceNo = pi[i].ProformaInvoiceNo,
                            ItemNo = itemData[i].ItemNo,
                            VendorItemCode = pi[i].VendorItemCode,
                            HSCode = pi[i].HSCode,
                            Description = pi[i].Description,
                            Quantity = pi[i].Quantity,
                            TotalCBM = pi[i].TotalCBM,
                            UnitPrice = pi[i].UnitPrice,
                            CurrencyCodeLocale = pi[i].CurrencyCodeLocale,
                            CurrencyAmountLocale = pi[i].CurrencyAmountLocale,
                            CurrentRateLocale = pi[i].CurrentRateLocale,
                            CurrencyCodeOther = (pi[i].CurrencyCodeOther == "IDR") ? "USD" : "IDR",
                            CurrencyAmountOther = pi[i].CurrencyAmountOther,
                            CurrentRateOther = pi[i].CurrentRateOther,
                            AuditActivity = AuditActivity.Insert,
                            AuditDateTime = DateTime.Now,
                            AuditUsername = userLogon,
                            IsActive = true
                        };
                        entities.tr_ProformaInvoiceDetails.Add(insertPIDetails);
                    }
                    entities.SaveChanges();

                    //for (int i = 0; i < pi.Count; i++)
                    //{
                    //    long itmCode = itemData[i].ItemCode;
                    //    var updatePI = entities.tr_PerformaInvoice.SingleOrDefault(m => m.IdFile == idFile && m.ItemCode == itmCode);
                    //    var importData = entities.tr_SuggestDetails.SingleOrDefault(m => m.IdHeader == idFile && m.ItemCode == itmCode);

                    //    var insertTjImportPI = new tj_SuggestDetails_PerformaInvoice()
                    //    {
                    //        IdFile = itemData[i].IdHeader,
                    //        IdFileDetails = importData.Id,
                    //        IdPerformaInvoice = updatePI.Id,
                    //        IsActive = true
                    //    };
                    //    entities.tj_SuggestDetails_PerformaInvoice.Add(insertTjImportPI);
                    //}
                    //entities.SaveChanges();
                }
                else
                {
                    throw new Exception("Please check the Suggest and PI Items again!!");
                }
                
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Insert new PI Images (by Upload)
        public void InsertPIImages(string DocNo, string iPath, string userLogon)
        {
            try
            {
                var pi = entities.tr_ProformaInvoiceHeader.Where(m => m.QuotationNo == DocNo).ToList();

                for (int i = 0; i < pi.Count; i++)
                {
                    pi[i].VendorPIUploaded = true;
                    pi[i].VendorPIPath = iPath;
                }
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Insert new PI (manual Input)
        //public void InsertPI(long idFile, CreateEditPerformaInvoiceViewModel model, string userLogon)
        //{
        //    try
        //    {
        //        var insertPI = new tr_PerformaInvoice()
        //        {
        //            IdFile = idFile,
        //            ItemCode = Convert.ToInt64(model.ItemCode),
        //            InvoiceNo = model.InvoiceNo,
        //            VendorCode = model.VendorCode,
        //            HSCode = model.HSCode,
        //            Description = model.Description,
        //            Quantity = model.Quantity,
        //            TotalCBM = model.TotalCBM,
        //            UnitPrice = model.UnitPrice,
        //            InvoiceDate = model.InvoiceDate,
        //            InputDate = DateTime.Now,
        //            InputBy = userLogon,
        //            IsActive = true
        //        };
        //        entities.tr_PerformaInvoice.Add(insertPI);
        //        entities.SaveChanges();

        //        long itmCode = model.ItemCode;
        //        var updatePI = entities.tr_PerformaInvoice.SingleOrDefault(m => m.IdFile == idFile && m.ItemCode == itmCode);
        //        var importData = entities.tr_SuggestDetails.SingleOrDefault(m => m.IdHeader == idFile && m.ItemCode == itmCode);

        //        var insertTjImportPI = new tj_SuggestDetails_PerformaInvoice()
        //        {
        //            IdFile = idFile,
        //            IdImport = importData.Id,
        //            IdPerformaInvoice = updatePI.Id,
        //            IsActive = true
        //        };
        //        entities.tj_SuggestDetails_PerformaInvoice.Add(insertTjImportPI);
        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        //Clear choosen PI Number (by Upload)
        public void ClearPI(string DocNo)
        {
            try
            {
                var suggestDoc = entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo && m.IsActive == true);
                long suggestNo = Convert.ToInt64(suggestDoc.SuggestDocNo);

                var headerPI = entities.tr_ProformaInvoiceHeader.SingleOrDefault(m => m.QuotationNo == DocNo && m.IsActive == true);
                List<tr_ProformaInvoiceDetails> detailsPI = new List<tr_ProformaInvoiceDetails>();
                detailsPI = entities.tr_ProformaInvoiceDetails.Where(m => m.ProformaInvoiceNo == headerPI.ProformaInvoiceNo && m.IsActive == true).ToList();

                //Save previous data to History
                foreach (var item in detailsPI)
                {
                    MoveToHistPI(item);
                }
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Clear choosen PI Number (manual Input)
        //public void ClearPI(CreateEditPerformaInvoiceViewModel model)
        //{
        //    try
        //    {
        //        var fileID = entities.tr_TransferRequest.SingleOrDefault(m => m.Code == model.CodeFile && m.IsActive == true);
        //        long IDfile = Convert.ToInt64(fileID.Id);

        //        List<tr_PerformaInvoice> listPI = new List<tr_PerformaInvoice>();
        //        listPI = entities.tr_PerformaInvoice.Where(m => m.IdFile == IDfile && m.IsActive == true).ToList();

        //        //Save previous data to History
        //        MoveToHistPI(listPI);
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        //Move PI to History
        public void MoveToHistPI(tr_ProformaInvoiceDetails pi)
        {
            try
            {
                //Get latest sequence in History table
                int counterSeq = 0;
                var seq = entities.tr_ProformaInvoiceDetails_Hist.OrderByDescending(m => m.Sequence).FirstOrDefault();
                if (seq != null)
                {
                    counterSeq = seq.Sequence + 1;
                }

                //foreach (var item in listPi)
                //{
                var insertPIDetailHist = new tr_ProformaInvoiceDetails_Hist()
                {
                    ProformaInvoiceNo = pi.ProformaInvoiceNo,
                    ItemNo = pi.ItemNo,
                    VendorItemCode = pi.VendorItemCode,
                    HSCode = pi.HSCode,
                    Description = pi.Description,
                    Quantity = pi.Quantity,
                    TotalCBM = pi.TotalCBM,
                    UnitPrice = pi.UnitPrice,
                    CurrencyCodeLocale = pi.CurrencyCodeLocale,
                    CurrencyAmountLocale = pi.CurrencyAmountLocale,
                    CurrentRateLocale = pi.CurrentRateLocale,
                    CurrencyCodeOther = pi.CurrencyCodeOther,
                    CurrencyAmountOther = pi.CurrencyAmountOther,
                    CurrentRateOther = pi.CurrentRateOther,
                    AuditActivity = pi.AuditActivity,
                    AuditDateTime = pi.AuditDateTime,
                    AuditUsername = pi.AuditUsername,
                    TimeStamp = DateTime.Now,
                    Sequence = counterSeq,
                    IsActive = pi.IsActive
                };
                entities.tr_ProformaInvoiceDetails_Hist.Add(insertPIDetailHist);
                //}

                ////delete joint table key
                //var fileDetail = entities.tr_SuggestDetails.SingleOrDefault(m => m.IdHeader == pi.IdFile && m.ItemCode == pi.ItemCode && m.IsActive == true);
                //long idDetail = fileDetail.Id;
                //var tj = entities.tj_SuggestDetails_PerformaInvoice.SingleOrDefault(m => m.IdFile == pi.IdFile && m.IdFileDetails == idDetail && m.IdPerformaInvoice == pi.Id && m.IsActive == true);
                //entities.tj_SuggestDetails_PerformaInvoice.Remove(tj);

                ////delete all previous PI Number data
                ////foreach (var item in listPi)
                ////{
                //entities.tr_PerformaInvoice.Remove(pi);
                ////}

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }


    }
}
