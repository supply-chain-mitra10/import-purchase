﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Data;
using ViewModels.ProformaInvoices;
using ViewModels.ProcessResult;
using Providers.Imports;
using Providers.Helper;

namespace Providers.ProformaInvoices
{
    public class ProformaInvoiceBussinessLogic
    {
        private ProformaInvoiceRepository repository = new ProformaInvoiceRepository();
        private ImportRepository repoImport = new ImportRepository();
        private ProcessResult result = new ProcessResult();

        //Setting excel file active sheet name
        public const string TABLE_NAME_PROPERTY = "Template";
        public const string COLUMN_NAME_PROPERTY = "Item_No";

        //Create method for new PI number
        public CreateEditProformaInvoiceHeaderViewModel GetCreateEditPI()
        {
            CreateEditProformaInvoiceHeaderViewModel viewModel = new CreateEditProformaInvoiceHeaderViewModel();
            return viewModel;
        }

        public CreateEditProformaInvoiceHeaderViewModel GetCreateEditPI(string DocNo)
        {
            var pi = repository.GetFileByDocNo(DocNo);
            CreateEditProformaInvoiceHeaderViewModel viewModel = new CreateEditProformaInvoiceHeaderViewModel();
            viewModel.QuotationNo = pi.SuggestDocNo;

            return viewModel;
        }

        //Save method for saving new File (by Upload)
        public ProcessResult SavePI(CreateEditProformaInvoiceHeaderViewModel model, string fName, string fExt, string fPath, string fPathServer, string userLogin)
        {
            var fileHeader = repository.GetFileByDocNo(model.QuotationNo);
            var cekFile = repository.GetPIByDocNo(fileHeader.SuggestDocNo);

            try
            {
                //Get data from excel
                DataTable dataImport = Converter.ExcelToDataTable(fPath, fExt, TABLE_NAME_PROPERTY, COLUMN_NAME_PROPERTY);
                List<CreateEditProformaInvoiceViewModel> listData = Converter.PIData(dataImport);

                if (cekFile == null)
                {
                    //insert PI
                    repository.InsertPI(fileHeader.SuggestDocNo, listData, userLogin);
                    //update PI Number to Import detail
                    repoImport.UpdatePIPerItem(listData, fileHeader.SuggestDocNo);

                    result.InsertSucceed();
                }
                else
                {
                    //Clear previous data to Update PI
                    repository.ClearPI(fileHeader.SuggestDocNo);
                    //insert PI
                    repository.InsertPI(fileHeader.SuggestDocNo, listData, userLogin);
                    //update PI Number to Import detail
                    repoImport.UpdatePIPerItem(listData, fileHeader.SuggestDocNo);

                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new Images (by Upload)
        public ProcessResult SavePIImages(CreateEditProformaInvoiceHeaderViewModel model, string fPath, string userLogin)
        {
            var fileHeader = repository.GetFileByDocNo(model.QuotationNo);
            var cekFile = repository.GetPIImageUploadByIdFile(fileHeader.SuggestDocNo).ToList();

            try
            {
                if (cekFile.Count == 0)
                {
                    //insert PI Image
                    repository.InsertPIImages(fileHeader.SuggestDocNo, fPath, userLogin);
                    result.InsertSucceed();
                }
                else
                {
                    //Clear previous data to Update PI Image
                    repository.ClearPI(fileHeader.SuggestDocNo);
                    //insert PI Image
                    repository.InsertPIImages(fileHeader.SuggestDocNo, fPath, userLogin);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new File (manual Input)
        //public ProcessResult SavePI(CreateEditPerformaInvoiceViewModel model, string userLogin)
        //{
        //    var fileHeader = repository.GetFileByCode(model.CodeFile);
        //    //var cekFile = repository.GetPIByIdFile(fileHeader.Id).ToList(); //[20220808] Remark by Dwi on Testing manual Input
        //    var cekFile = repository.GetPIByItemCodeAndIdFile(fileHeader.Id, model.ItemCode);

        //    try
        //    {
        //        //if (cekFile.Count == 0) //[20220808] Remark by Dwi on Testing manual Input
        //        if (cekFile == null)
        //        {
        //            //insert PI
        //            repository.InsertPI(fileHeader.Id, model, userLogin);
        //            //update PI Number to Import detail
        //            repoImport.UpdatePIPerItem(model);

        //            result.InsertSucceed();
        //        }
        //        else
        //        {
        //            //Clear previous data to Update PI
        //            repository.ClearPI(model);
        //            //insert PI
        //            repository.InsertPI(fileHeader.Id, model, userLogin);
        //            //update PI Number to Import detail
        //            repoImport.UpdatePIPerItem(model);

        //            result.UpdateSucceed();
        //        }
        //    }
        //    catch (Exception error)
        //    {
        //        result.ProcessFailed(error.Message);
        //    }
        //    return result;
        //}

        //Get data for PI Number drop down list
        public IEnumerable<SelectListItem> GetListPI()
        {
            var ListPI = from pi in repository.AllPINumber()
                               select new SelectListItem()
                               {
                                   Value = pi,
                                   Text = pi
                               };
            return ListPI;
        }

    }
}
