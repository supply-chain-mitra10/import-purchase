﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.InventoryControls;
using ViewModels.ProcessResult;
using ViewModels.Commons;
using Providers.Helper;

namespace Providers.InventoryControls
{
    public class InventoryControlRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all File from DB
        public IEnumerable<tr_SuggestHeader> AllFiles()
        {
            return entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.mt_SuggestDocStatus.Department.Contains("IC"));
        }

        //Get all File Detail from DB
        //public IEnumerable<tr_SuggestHeaderDetails> AllFileDetails()
        //{
        //    return entities.tr_SuggestHeaderDetails.Where(m => m.IsActive == true);
        //}

        //Get selected File
        public tr_SuggestHeader GetFile(string fName)
        {
            return entities.tr_SuggestHeader.SingleOrDefault(m => m.FileName == fName);
        }
        public tr_SuggestHeader GetFileByDocNo(string docNo)
        {
            return entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == docNo);
        }

        //Delete using Json
        public int GetDeleteFile(string IdFile)
        {
            return entities.tr_SuggestHeader.Where(m => m.SuggestDocNo == IdFile && m.IsActive == true).Count();
        }

        //Insert new File
        public void InsertFile(InventoryControlViewModel model, string fname, string fext, int fsize, string fpath, string userLogon)
        {
            string ftype = Converter.GetFileTypeByExtension(fext);
            //byte[] fcontent = Converter.GetByteFromFile(fpath);

            //get latest ID for auto generate
            var latestID = entities.tr_SuggestHeader.OrderByDescending(m => m.SuggestDocNo).FirstOrDefault();
            int counterID = 1;
            if (latestID != null)
            {
                if (latestID.SuggestDocNo.Substring(2, 2) == DateTime.Now.ToString("yy"))
                {
                    string idcount = latestID.SuggestDocNo.Substring(4, 6); //e.q.SG22000001
                    counterID = Convert.ToInt32(idcount) + 1;
                }
            }

            //get ID for Dropdownlist selected value
            //int categoryID = Convert.ToInt32(model.Category);
            //int vendorID = Convert.ToInt32(model.Vendor);

            try
            {
                //Insert Header
                var insertFile = new tr_SuggestHeader()
                {
                    SuggestDocNo = string.Concat("SG", DateTime.Now.ToString("yy"), counterID.ToString().PadLeft(6, '0')),
                    FileName = fname,
                    FileType = ftype,
                    FilePath = fpath,
                    Extension = fext,
                    Size = fsize,
                    Category = model.Category,
                    VendorNo = model.Vendor,
                    SuggestDocStatus = SuggestDocStatus.New,
                    AuditActivity = AuditActivity.Insert,
                    AuditDateTime = DateTime.Now,
                    AuditUsername = userLogon,
                    IsActive = true
                };
                entities.tr_SuggestHeader.Add(insertFile);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen File
        public void UpdateFile(InventoryControlViewModel model, string fname, string fext, int fsize, string userLogon)
        {
            string ftype = Converter.GetFileTypeByExtension(fext);

            try
            {
                var updateData = entities.tr_SuggestHeader.SingleOrDefault(m => m.FileName == fname);
                updateData.SuggestDocNo = model.SuggestDocNo;
                updateData.FileName = fname;
                updateData.FileType = ftype;
                updateData.Extension = fext;
                updateData.Size = fsize;
                updateData.Category = model.Category;
                updateData.VendorNo = model.Vendor;
                updateData.SuggestDocStatus = SuggestDocStatus.Confirm;
                updateData.AuditActivity = AuditActivity.Update;
                updateData.AuditDateTime = DateTime.Now;
                updateData.AuditUsername = userLogon;
                updateData.IsActive = true;

                //Update detail items for revised
                if (fname.Contains("_REVISE"))
                {
                    var detail = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == updateData.SuggestDocNo).ToList();
                    foreach (var item in detail)
                    {
                        item.IsActive = true;
                    }
                }
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Delete choosen File and Details
        public void DeleteFile(string IdFile, string userLogon)
        {
            try
            {
                var delFileHeader = entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == IdFile && m.IsActive == true);
                var delFileDetail = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == delFileHeader.SuggestDocNo && m.IsActive == true);

                delFileHeader.SuggestDocStatus = SuggestDocStatus.Reject;
                delFileHeader.AuditActivity = AuditActivity.Delete;
                delFileHeader.AuditDateTime = DateTime.Now;
                delFileHeader.AuditUsername = userLogon;
                delFileHeader.IsActive = false;
                //entities.tr_SuggestHeader.Remove(deleteFile);

                foreach (var item in delFileDetail)
                {
                    item.AuditActivity = AuditActivity.Delete;
                    item.AuditDateTime = DateTime.Now;
                    item.AuditUsername = userLogon;
                    item.IsActive = false;
                }

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Move choosen File to History
        public void MoveToHist(string DocNo, string UserLogon)
        {
            try
            {
                //Get latest sequence in History table
                int counterSeq = 0;
                var seq = entities.tr_SuggestHeader_Hist.OrderByDescending(m => m.Sequence).FirstOrDefault();
                if (seq != null)
                {
                    counterSeq = seq.Sequence + 1;
                }

                var mvFileHeader = entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo);
                var mvFileDetail = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == mvFileHeader.SuggestDocNo);

                var moveFileHeader = new tr_SuggestHeader_Hist()
                {
                    SuggestDocNo = mvFileHeader.SuggestDocNo,
                    FileName = mvFileHeader.FileName,
                    FileType = mvFileHeader.FileType,
                    FilePath = mvFileHeader.FilePath,
                    Extension = mvFileHeader.Extension,
                    Size = mvFileHeader.Size,
                    Category = mvFileHeader.Category,
                    VendorNo = mvFileHeader.VendorNo,
                    SuggestDocStatus = mvFileHeader.SuggestDocStatus,
                    AuditActivity = mvFileHeader.AuditActivity,
                    AuditDateTime = mvFileHeader.AuditDateTime,
                    AuditUsername = mvFileHeader.AuditUsername,
                    TimeStamp = DateTime.Now,
                    Sequence = counterSeq,
                    IsActive = mvFileHeader.IsActive
                };

                List<tr_SuggestDetails_Hist> moveFileDetail = new List<tr_SuggestDetails_Hist>();
                foreach (var item in mvFileDetail)
                {
                    var importHist = new tr_SuggestDetails_Hist()
                    {
                        SuggestDocNo = item.SuggestDocNo,
                        SiteNo = item.SiteNo,
                        SiteName = item.SiteName,
                        VendorNo = item.VendorNo,
                        VendorName = item.VendorName,
                        MasterBrand = item.MasterBrand,
                        ItemNo = item.ItemNo,
                        ItemName = item.ItemName,
                        Category = item.Category,
                        SystemSuggestQty = item.SystemSuggestQty,
                        AverageSales = item.AverageSales,
                        LeadTime = item.LeadTime,
                        HighestAvgLeadTimeActual = item.HighestAvgLeadTimeActual,
                        SafetyStockDays = item.SafetyStockDays,
                        OrderPeriod = item.OrderPeriod,
                        MinimumStock = item.MinimumStock,
                        MaximumStock = item.MaximumStock,
                        ReorderPoint = item.ReorderPoint,
                        OptimumMax = item.OptimumMax,
                        OptimumMaxMultiple = item.OptimumMaxMultiple,
                        StockOnHand = item.StockOnHand,
                        OutstandingPO = item.OutstandingPO,
                        OutstandingTR = item.OutstandingTR,
                        OutstandingTO = item.OutstandingTO,
                        MultiplePurchaseQty = item.MultiplePurchaseQty,
                        OutstandingTRfromOtherStore = item.OutstandingTRfromOtherStore,
                        CalculatedSuggest = item.CalculatedSuggest,
                        CalculatedStockDaysSuggest = item.CalculatedStockDaysSuggest,
                        CalculatedTotalStockDays = item.CalculatedTotalStockDays,
                        ReviseMDSuggest = item.ReviseMDSuggest,
                        ReviseMDStockDaysSuggest = item.ReviseMDStockDaysSuggest,
                        ReviseMDTotalStockDays = item.ReviseMDTotalStockDays,
                        ICSuggest_TotalQty = item.ICSuggest_TotalQty,
                        ICSuggest_TotalCBM = item.ICSuggest_TotalCBM,
                        MDRevise_TotalQty = item.MDRevise_TotalQty,
                        MDRevise_TotalCBM = item.MDRevise_TotalCBM,
                        AuditActivity = item.AuditActivity,
                        AuditDateTime = item.AuditDateTime,
                        AuditUsername = item.AuditUsername,
                        TimeStamp = DateTime.Now,
                        Sequence = counterSeq,
                        IsActive = item.IsActive
                    };
                    moveFileDetail.Add(importHist);
                }

                entities.tr_SuggestHeader_Hist.Add(moveFileHeader);
                entities.tr_SuggestDetails_Hist.AddRange(moveFileDetail);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

    }
}
