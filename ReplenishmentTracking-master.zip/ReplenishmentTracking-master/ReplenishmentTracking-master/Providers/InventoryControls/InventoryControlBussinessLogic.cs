﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Providers.SuggestDocStatuss;
using Providers.Vendors;
using Providers.Categorys;
using Providers.Imports;
using Providers.Helper;
using ViewModels.InventoryControls;
using ViewModels.Imports;
using ViewModels.Dashboards;
using ViewModels.Remarkss;
using ViewModels.ProcessResult;
using System.Configuration;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace Providers.InventoryControls
{
    public class InventoryControlBussinessLogic
    {
        private InventoryControlRepository repository = new InventoryControlRepository();
        private SuggestDocStatusRepository repoStatus = new SuggestDocStatusRepository();
        private VendorRepository repoSupplier = new VendorRepository();
        private CategoryRepository repoCategory = new CategoryRepository();
        private ImportRepository repoImport = new ImportRepository();
        private ProcessResult result = new ProcessResult();

        //Setting excel file active sheet name
        public const string TABLE_NAME_PROPERTY = "Template";
        public const string COLUMN_NAME_PROPERTY = "Item_No";

        //Get File list to display
        public List<InventoryControlViewModel> List()
        {
            var query = from tr in repository.AllFiles()
                        orderby tr.AuditDateTime descending
                        select new InventoryControlViewModel()
                        {
                            SuggestDocNo = tr.SuggestDocNo,
                            FileName = tr.FileName,
                            FileType = tr.FileType,
                            FilePath = tr.FilePath,
                            Extension = tr.Extension,
                            Size = tr.Size,
                            Category = tr.Category,
                            Vendor = tr.VendorNo,
                            SuggestDocStatus = tr.SuggestDocStatus,
                            AuditActivity = Convert.ToChar(tr.AuditActivity),
                            AuditDateTime = tr.AuditDateTime,
                            AuditUsername = tr.AuditUsername,
                            IsActive = tr.IsActive,
                            ICSuggest_TotalQty = tr.tr_SuggestDetails.Where(m => m.ICSuggest_TotalQty != null).OrderByDescending(m => m.AuditDateTime).Select(m => m.ICSuggest_TotalQty).FirstOrDefault(),
                            ICSuggest_TotalCBM = tr.tr_SuggestDetails.Where(m => m.ICSuggest_TotalCBM != null).OrderByDescending(m => m.AuditDateTime).Select(m => m.ICSuggest_TotalCBM).FirstOrDefault(),
                            MDRevise_TotalQty = tr.tr_SuggestDetails.Where(m => m.MDRevise_TotalQty != null).OrderByDescending(m => m.AuditDateTime).Select(m => m.MDRevise_TotalQty).FirstOrDefault(),
                            MDRevise_TotalCBM = tr.tr_SuggestDetails.Where(m => m.MDRevise_TotalCBM != null).OrderByDescending(m => m.AuditDateTime).Select(m => m.MDRevise_TotalCBM).FirstOrDefault()
                        };

            return query.ToList();
        }

        //Get File for Details
        public InventoryControlViewModel GetFileDet(string docNo)
        {
            var fData = repository.GetFileByDocNo(docNo);
            InventoryControlViewModel viewModel = new InventoryControlViewModel();

            viewModel.SuggestDocNo = fData.SuggestDocNo;
            viewModel.FileName = fData.FileName;
            viewModel.FileType = fData.FileType;
            viewModel.FilePath = fData.FilePath;
            viewModel.Extension = fData.Extension;
            viewModel.Size = fData.Size;
            viewModel.Category = fData.Category.ToString();
            viewModel.Vendor = fData.VendorNo.ToString();
            viewModel.SuggestDocNo = fData.SuggestDocNo;
            viewModel.AuditActivity = Convert.ToChar(fData.AuditActivity);
            viewModel.AuditDateTime = fData.AuditDateTime;
            viewModel.AuditUsername = fData.AuditUsername;
            viewModel.IsActive = fData.IsActive;

            return viewModel;
        }

        #region Timeline
        //Get Historylist for Timeline
        public List<TimelineViewModel> ListTimeline(string docNo)
        {
            var tr = repository.GetFileByDocNo(docNo);
            List<TimelineViewModel> fileHist = new List<TimelineViewModel>();
            try
            {
                string cnnString = ConfigurationManager.ConnectionStrings["IMPORTPURCHASE"].ConnectionString;
                SqlConnection cnn = new SqlConnection(cnnString);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_TimelineFile";
                cmd.Parameters.Add(new SqlParameter("@FileID", tr.SuggestDocNo.ToString()));

                cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    fileHist.Add(new TimelineViewModel()
                    {
                        ID = Convert.ToInt32(reader[0]),
                        History_Tracking = reader[1].ToString(),
                        Interval = Convert.ToInt32(reader[2])
                    });
                }

                cnn.Close();
            }
            catch (Exception)
            {

                throw;
            }

            return fileHist;
        }
        #endregion

        //Get details for Remarks form
        public RemarksViewModel GetRemarksDetail(string docNo)
        {
            var tr = repository.GetFileByDocNo(docNo);
            RemarksViewModel viewModel = new RemarksViewModel();

            viewModel.SuggestDocNo = tr.SuggestDocNo;
            viewModel.FileName = tr.FileName;

            return viewModel;
        }

        //Create method for new File
        public InventoryControlViewModel GetCreateEdit()
        {
            InventoryControlViewModel viewModel = new InventoryControlViewModel();
            return viewModel;
        }

        //Edit method for edited File
        public InventoryControlViewModel GetCreateEdit(string docNo)
        {
            var tr = repository.GetFileByDocNo(docNo);
            InventoryControlViewModel viewModel = new InventoryControlViewModel();

            viewModel.SuggestDocNo = tr.SuggestDocNo;
            viewModel.FileName = tr.FileName;
            viewModel.FileType = tr.FileType;
            viewModel.FilePath = tr.FilePath;
            viewModel.Extension = tr.Extension;
            viewModel.Size = tr.Size;
            viewModel.Category = tr.Category;
            viewModel.Vendor = tr.VendorNo;
            viewModel.SuggestDocNo = tr.SuggestDocNo;
            viewModel.AuditActivity = Convert.ToChar(tr.AuditActivity);
            viewModel.AuditDateTime = tr.AuditDateTime;
            viewModel.AuditUsername = tr.AuditUsername;

            return viewModel;
        }

        //Delete method for one File
        public ProcessResult GetDelete(string DocNo, string userLogin)
        {
            try
            {
                //Copy to History table (Existing)
                repository.MoveToHist(DocNo, userLogin);
                //Set IsActive to false
                repository.DeleteFile(DocNo, userLogin);
                //Copy to History table (Delete)
                repository.MoveToHist(DocNo, userLogin);

                result.DeleteSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new File
        public ProcessResult SaveFile(InventoryControlViewModel model, string fName, string fExt, int fSize, string fPath, string fFlag, string userLogin)
        {
            var cekFile = repository.GetFile(fName);
            bool cekCatAndVendor = true;
            try
            {
                if (cekFile == null && fFlag == "0")
                {
                    DataTable dataImport = Converter.ExcelToDataTable(fPath, fExt, TABLE_NAME_PROPERTY, COLUMN_NAME_PROPERTY);
                    List<SuggestDetailViewModel> listData = Converter.ForecastData(dataImport);

                    //Check if Item Category and Vendor were same inside the file
                    foreach (var item in listData)
                    {
                        var cat = repoCategory.GetCategory(item.Category);
                        var vdr = repoSupplier.GetVendor(item.VendorNo);
                        if (cat.Category.ToString() != model.Category || vdr.VendorNo.ToString() != model.Vendor)
                        {
                            cekCatAndVendor = false;
                        }
                    }

                    if (cekCatAndVendor == true)
                    {
                        //insert file to DB binary
                        repository.InsertFile(model, fName, fExt, fSize, fPath, userLogin);
                        //insert forecast result
                        repoImport.InsertFileForecast(listData, fName, userLogin);
                        result.InsertSucceed();
                    }
                    else
                    {
                        result.ProcessFailed("Please Re-check the Analysis file Category and Supplier!!");
                    }   
                }
                else
                {
                    //save to hist per change status
                    repository.MoveToHist(model.SuggestDocNo, userLogin);
                    //update status
                    repository.UpdateFile(model, fName, fExt, fSize, userLogin);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Write forecast calculate in to File
        public ProcessResult WriteFile(string fName, string fPath)
        {
            var dataFile = repository.GetFile(fName);

            //Get all data to write          
            var dataImport = repoImport.AllImportByDocNo(dataFile.SuggestDocNo).ToList();

            DataTable dtImport = new DataTable();
            dtImport.TableName = TABLE_NAME_PROPERTY;

            dtImport.Columns.Add("Site No");
            dtImport.Columns.Add("Site Name");
            dtImport.Columns.Add("Item Category");
            dtImport.Columns.Add("Vendor No");
            dtImport.Columns.Add("Vendor Name");
            dtImport.Columns.Add("Item MasterBrand");
            dtImport.Columns.Add("Item No");
            dtImport.Columns.Add("Item Name");
            dtImport.Columns.Add("System Suggested Quantity");
            dtImport.Columns.Add("Average Sales");
            dtImport.Columns.Add("Lead Time");
            dtImport.Columns.Add("Highest Avg Lead Time Actual");
            dtImport.Columns.Add("Safety Stock Days");
            dtImport.Columns.Add("Order Period");
            dtImport.Columns.Add("Minimum Stock");
            dtImport.Columns.Add("Maximum Stock");
            dtImport.Columns.Add("Reorder Point");
            dtImport.Columns.Add("Optimum Max");
            dtImport.Columns.Add("Optimum Max Multiple");
            dtImport.Columns.Add("Stock On Hand");
            dtImport.Columns.Add("Outstanding PO");
            dtImport.Columns.Add("Outstanding TR");
            dtImport.Columns.Add("Outstanding TO");
            dtImport.Columns.Add("Multiple Purchase Qty");
            dtImport.Columns.Add("Outstanding TR from other Store");
            dtImport.Columns.Add("Calculated Suggest");
            dtImport.Columns.Add("Calculated Stock Days Suggest");
            dtImport.Columns.Add("Calculated Total Stock Days");
            dtImport.Columns.Add("Revise MD Suggest");
            dtImport.Columns.Add("Revise MD Stock Days Suggest");
            dtImport.Columns.Add("Revise MD Total Stock Days");
            dtImport.Columns.Add("IC Suggest Total Qty");
            dtImport.Columns.Add("IC Suggest Total CBM");
            dtImport.Columns.Add("MD Revise Total Qty");
            dtImport.Columns.Add("MD Revise Total CBM");

            for (int i = 0; i < dataImport.Count(); i++)
            {
                dtImport.Rows.Add(new object[] { dataImport[i].SiteNo, dataImport[i].SiteName, dataImport[i].Category,
                        dataImport[i].VendorNo, dataImport[i].VendorName, dataImport[i].MasterBrand, dataImport[i].ItemNo,
                        dataImport[i].mt_Item.ItemName, dataImport[i].SystemSuggestQty, dataImport[i].AverageSales, dataImport[i].LeadTime, 
                        dataImport[i].HighestAvgLeadTimeActual, dataImport[i].SafetyStockDays, dataImport[i].OrderPeriod, dataImport[i].MinimumStock,
                        dataImport[i].MaximumStock, dataImport[i].ReorderPoint, dataImport[i].OptimumMax, dataImport[i].OptimumMaxMultiple,
                        dataImport[i].StockOnHand, dataImport[i].OutstandingPO, dataImport[i].OutstandingTR, dataImport[i].OutstandingTO,
                        dataImport[i].MultiplePurchaseQty, dataImport[i].OutstandingTRfromOtherStore,
                        dataImport[i].CalculatedSuggest, dataImport[i].CalculatedStockDaysSuggest, dataImport[i].CalculatedTotalStockDays,
                        dataImport[i].ReviseMDSuggest, dataImport[i].ReviseMDStockDaysSuggest, dataImport[i].ReviseMDTotalStockDays,
                        dataImport[dataImport.Count()-1].ICSuggest_TotalQty, dataImport[dataImport.Count()-1].ICSuggest_TotalCBM, 
                        dataImport[dataImport.Count()-1].MDRevise_TotalQty, dataImport[dataImport.Count()-1].MDRevise_TotalCBM});
            }
            dtImport.AcceptChanges();

            result = Excel.ExcelWriter(dtImport, fPath, dataFile.Extension);

            return result;
        }

        //Get data for Status drop down list
        public IEnumerable<SelectListItem> GetListStatus()
        {
            var ListStatus = from stat in repoStatus.GetStatusForIC()
                               select new SelectListItem()
                               {
                                   Value = stat.SuggestDocStatus,
                                   Text = stat.SuggestDocStatus
                               };
            return ListStatus;
        }

        //Get data for Supplier drop down list
        public IEnumerable<SelectListItem> GetListVendor()
        {
            var ListSupplier = from vdr in repoSupplier.AllVendor()
                             select new SelectListItem()
                             {
                                 Value = vdr.VendorNo.ToString(),
                                 Text = vdr.VendorName + " - " + vdr.VendorNo
                             };
            return ListSupplier;
        }

        //Get data for Category drop down list
        public IEnumerable<SelectListItem> GetListCategory()
        {
            var ListCategory = from cat in repoCategory.AllCategory()
                             select new SelectListItem()
                             {
                                 Value = cat.Category.ToString(),
                                 Text = cat.Category
                             };
            return ListCategory;
        }

    }
    
}
