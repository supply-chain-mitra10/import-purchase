﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.Commons;
using ViewModels.MenuCategorys;
using ViewModels.ProcessResult;

namespace Providers.Menus
{
    public class MenuCategoryRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all menu from DB
        public IEnumerable<mt_MenuCategory> AllMenuCategory()
        {
            return entities.mt_MenuCategory;
        }

        //Get selected menu
        public mt_MenuCategory GetMenuCategory(string MenuCategoryNo)
        {
            return entities.mt_MenuCategory.SingleOrDefault(m => m.MenuCategoryNo == MenuCategoryNo);
        }

        //Delete using Json
        public int GetDeleteMenuCategory(string MenuCategoryNo)
        {
            return entities.mt_MenuCategory.Where(m => m.MenuCategoryNo == MenuCategoryNo).Count();
        }

        //Insert new menu
        public void InsertMenuCategory(CreateEditMenuCategoryViewModel model, string userLogon)
        {
            //get latest ID for auto generate
            var latestID = entities.mt_MenuCategory.OrderByDescending(m => m.MenuCategoryNo).FirstOrDefault();

            try
            {
                var insertMenu = new mt_MenuCategory()
                {
                    MenuCategoryNo = model.MenuCategoryNo,
                    MenuCategoryName = model.MenuCategoryName,
                    AuditActivity = AuditActivity.Insert,
                    AuditDateTime = DateTime.Now,
                    AuditUsername = userLogon,
                    IsActive = true
                };
                entities.mt_MenuCategory.Add(insertMenu);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen menu
        public void UpdateMenuCategory(CreateEditMenuCategoryViewModel model, string userLogon)
        {
            try
            {
                var updateData = entities.mt_MenuCategory.SingleOrDefault(m => m.MenuCategoryNo == model.MenuCategoryNo);
                updateData.MenuCategoryNo = model.MenuCategoryNo;
                updateData.MenuCategoryName = model.MenuCategoryName;
                updateData.AuditActivity = AuditActivity.Update;
                updateData.AuditDateTime = DateTime.Now;
                updateData.AuditUsername = userLogon;
                updateData.IsActive = model.IsActive;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Delete choosen menu
        public void DeleteMenuCategory(string MenuCategoryNo)
        {
            try
            {
                var deleteMenu = entities.mt_MenuCategory.SingleOrDefault(m => m.MenuCategoryNo == MenuCategoryNo);
                entities.mt_MenuCategory.Remove(deleteMenu);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
