﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.MenuCategorys;
using ViewModels.ProcessResult;
using System.Configuration;
using Providers.Menus;

namespace Providers.MenuCategorys
{
    public class MenuCategoryBussinessLogic
    {
        private MenuCategoryRepository repository = new MenuCategoryRepository();
        private ProcessResult result = new ProcessResult();

        //Get menu list to display
        public List<MenuCategoryViewModel> List(IndexViewModel model, int? page = null, int? idFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from menu in repository.AllMenuCategory()
                        where menu.MenuCategoryNo.ToString().Contains(idFilter == null ? "" : idFilter.Value.ToString())
                        select new MenuCategoryViewModel()
                        {
                            MenuCategoryNo = menu.MenuCategoryNo,
                            MenuCategoryName = menu.MenuCategoryName,
                            AuditActivity = Convert.ToChar(menu.AuditActivity),
                            AuditDateTime = menu.AuditDateTime,
                            AuditUsername = menu.AuditUsername,
                            IsActive = menu.IsActive
                        };

            return query.ToList();
        }


        //Create method for new menu category
        public CreateEditMenuCategoryViewModel GetCreateEdit()
        {
            CreateEditMenuCategoryViewModel viewModel = new CreateEditMenuCategoryViewModel();
            return viewModel;
        }

        //Edit method for edited menu category
        public CreateEditMenuCategoryViewModel GetCreateEdit(string menuCategoryName)
        {
            var menu = repository.GetMenuCategory(menuCategoryName);
            CreateEditMenuCategoryViewModel viewModel = new CreateEditMenuCategoryViewModel();

            viewModel.MenuCategoryNo = menu.MenuCategoryNo;
            viewModel.MenuCategoryName = menu.MenuCategoryName;
            viewModel.AuditActivity = Convert.ToChar(menu.AuditActivity);
            viewModel.AuditDateTime = menu.AuditDateTime;
            viewModel.AuditUsername = menu.AuditUsername;

            return viewModel;
        }

        //Delete method for one menu category
        public ProcessResult GetDelete(string menuCategoryName)
        {
            try
            {
                repository.DeleteMenuCategory(menuCategoryName);
                result.DeleteSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new menu category
        public ProcessResult SaveMenu(CreateEditMenuCategoryViewModel model, string userLogin)
        {
            try
            {
                if (model.MenuCategoryNo == string.Empty || model.MenuCategoryNo == "")
                {
                    repository.InsertMenuCategory(model, userLogin);
                    result.InsertSucceed();
                }
                else
                {
                    repository.UpdateMenuCategory(model, userLogin);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }
    }
}
