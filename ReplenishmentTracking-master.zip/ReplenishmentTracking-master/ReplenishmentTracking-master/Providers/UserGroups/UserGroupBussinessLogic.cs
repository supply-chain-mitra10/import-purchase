﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.UserGroups;
using ViewModels.ProcessResult;
using System.Configuration;

namespace Providers.UserGroups
{
    public class UserGroupBussinessLogic
    {
        private UserGroupRepository repository = new UserGroupRepository();
        private ProcessResult result = new ProcessResult();

        //Get user group list to display
        public List<UserGroupViewModel> List(IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from user in repository.AllUserGroup()
                        where user.GroupName.ToString().Contains(IdFilter == null ? "" : IdFilter.Value.ToString())
                        select new UserGroupViewModel()
                        {
                            UserGroupNo = user.UserGroupNo,
                            GroupName = user.GroupName,
                            Description = user.Description,
                            AuditActivity = Convert.ToChar(user.AuditActivity),
                            AuditDateTime = user.AuditDateTime,
                            AuditUsername = user.AuditUsername,
                            IsActive = user.IsActive
                        };

            return query.ToList();
        }


        ////Create method for new user group
        //public CreateEditUserGroupViewModel GetCreateEdit()
        //{
        //    CreateEditUserGroupViewModel viewModel = new CreateEditUserGroupViewModel();
        //    return viewModel;
        //}

        ////Edit method for edited user group
        //public CreateEditUserGroupViewModel GetCreateEdit(int UserGroupID)
        //{
        //    var user = repository.GetUserGroup(UserGroupID);
        //    CreateEditUserGroupViewModel viewModel = new CreateEditUserGroupViewModel();

        //    viewModel.Id = user.Id;
        //    viewModel.GroupCode = user.GroupCode;
        //    viewModel.GroupName = user.GroupName;
        //    viewModel.Description = user.Description;
        //    return viewModel;
        //}

        ////Delete method for one user group
        //public ProcessResult GetDelete(int UserGroupID)
        //{
        //    try
        //    {
        //        repository.DeleteUserGroup(UserGroupID);
        //        result.DeleteSucceed();
        //    }
        //    catch (Exception error)
        //    {
        //        result.ProcessFailed(error.Message);
        //    }
        //    return result;
        //}

        ////Save method for saving new user group
        //public ProcessResult SaveUserGroup(CreateEditUserGroupViewModel model, string userLogin)
        //{
        //    try
        //    {
        //        if (model.Id == 0)
        //        {
        //            repository.InsertUserGroup(model, userLogin);
        //            result.InsertSucceed();
        //        }
        //        else
        //        {
        //            repository.UpdateUserGroup(model);
        //            result.UpdateSucceed();
        //        }
        //    }
        //    catch (Exception error)
        //    {
        //        result.ProcessFailed(error.Message);
        //    }
        //    return result;
        //}
    }
}
