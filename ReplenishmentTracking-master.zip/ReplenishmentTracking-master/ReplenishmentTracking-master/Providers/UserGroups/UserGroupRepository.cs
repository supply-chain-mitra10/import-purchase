﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.UserGroups;
using ViewModels.ProcessResult;
using Providers.Helper;

namespace Providers.UserGroups
{
    public class UserGroupRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all user group from DB
        public IEnumerable<mt_UserGroup> AllUserGroup()
        {
            return entities.mt_UserGroup;
        }

        //Get selected user group
        public mt_UserGroup GetUserGroup(string userGroupNo)
        {
            return entities.mt_UserGroup.SingleOrDefault(m => m.UserGroupNo == userGroupNo);
        }

        //Delete using Json
        public int GetDeleteUserGroup(string userGroupNo)
        {
            return entities.mt_UserGroup.Where(m => m.UserGroupNo == userGroupNo).Count();
        }

        ////Insert new user group
        //public void InsertUserGroup(CreateEditUserGroupViewModel model, string userLogon)
        //{
        //    //get latest ID for auto generate
        //    string TypeGroup = string.Empty;
        //    var latestID = entities.mt_UserGroup.OrderByDescending(m => m.Id).FirstOrDefault();
        //    int counterID = Convert.ToInt32(latestID.GroupCode.Substring(3, 3)) + 1;

        //    switch(latestID.GroupName)
        //    {
        //        case "Developer" :
        //            TypeGroup = "DEV";break;
        //        case "Admin" :
        //            TypeGroup = "ADM";break;
        //        case "Finance" :
        //            TypeGroup = "FIN";break;
        //        case "Supply Chain" :
        //            TypeGroup = "SPC";break;
        //        case "Inventory Control":
        //            TypeGroup = "INC"; break;
        //        case "Merchandise":
        //            TypeGroup = "MDS"; break;
        //        case "Import":
        //            TypeGroup = "IMP"; break;
        //        default :
        //            TypeGroup = "USR"; break;
        //    }

        //    try
        //    {
        //        var insertUserGroup = new mt_UserGroup()
        //        {
        //            Id = model.Id,
        //            GroupCode = TypeGroup + counterID.ToString().PadLeft(3, '0'),
        //            GroupName = model.GroupName,
        //            Description = model.Description,
        //            IsActive = true
        //        };
        //        entities.mt_UserGroup.Add(insertUserGroup);
        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        ////Update choosen user group
        //public void UpdateUserGroup(CreateEditUserGroupViewModel model)
        //{
        //    try
        //    {
        //        var updateData = entities.mt_UserGroup.SingleOrDefault(m => m.Id == model.Id);
        //        updateData.GroupCode = model.GroupCode;
        //        updateData.GroupName = model.GroupName;
        //        updateData.Description = model.Description;
        //        updateData.IsActive = model.IsActive;

        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        ////Delete choosen user group
        //public void DeleteUserGroup(int IDUserGroup)
        //{
        //    try
        //    {
        //        var deleteUserGroup = entities.mt_UserGroup.SingleOrDefault(m => m.Id == IDUserGroup);
        //        entities.mt_UserGroup.Remove(deleteUserGroup);
        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}
    }
}
