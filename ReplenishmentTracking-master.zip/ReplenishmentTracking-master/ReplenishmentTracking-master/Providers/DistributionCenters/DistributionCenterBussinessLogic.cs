﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.DistributionCenters;
using ViewModels.Dashboards;
using ViewModels.Remarkss;
using ViewModels.ProcessResult;
using Providers.PurchaseOrders;
using Providers.Items;
using Providers.SuggestDocStatuss;
using Providers.Vendors;
using Providers.Categorys;
using Providers.Remarkss;
using Providers.Helper;
using System.Configuration;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using ViewModels.ReceivingPO;
using System.Xml.Linq;

namespace Providers.DistributionCenters
{
    public class DistributionCenterBussinessLogic
    {
        private DistributionCenterRepository repository = new DistributionCenterRepository();
        private PurchaseOrderRepository repoPO = new PurchaseOrderRepository();
        private ItemRepository repoItem = new ItemRepository();
        private SuggestDocStatusRepository repoStatus = new SuggestDocStatusRepository();
        private VendorRepository repoSupplier = new VendorRepository();
        private CategoryRepository repoCategory = new CategoryRepository();
        private RemarksRepository repoRemarks = new RemarksRepository();
        private ProcessResult result = new ProcessResult();

        //Setting excel file active sheet name and column
        public const string TABLE_NAME_PROPERTY = "Template";
        public const string COLUMN_NAME_PROPERTY = "Item_no_";

        //Get File list to display
        public List<DistributionCenterViewModel> List()
        {
            var query = from tr in repository.AllFiles()
                        orderby tr.SuggestDocNo descending
                        select new DistributionCenterViewModel()
                        {
                            SuggestDocNo = tr.SuggestDocNo,
                            FileName = tr.FileName,
                            FileType = tr.FileType,
                            FilePath = tr.FilePath,
                            Extension = tr.Extension,
                            Size = tr.Size,
                            Category = tr.Category,
                            Vendor = tr.VendorNo,
                            SuggestDocStatus = tr.SuggestDocStatus,
                            AuditActivity = Convert.ToChar(tr.AuditActivity),
                            AuditDateTime = tr.AuditDateTime,
                            AuditUsername = tr.AuditUsername,
                            IsActive = tr.IsActive,
                            //EstimationDate = tr.tr_PurchaseOrder.Select(m => m.EstimationDate).FirstOrDefault(),
                            //EstimationArrival = tr.tr_PurchaseOrder.Select(m => m.EstimationArrival).FirstOrDefault(),
                            ICSuggest_TotalQty = tr.tr_SuggestDetails.OrderByDescending(m => m.SuggestDocNo).Select(m => m.ICSuggest_TotalQty).FirstOrDefault(),
                            ICSuggest_TotalCBM = tr.tr_SuggestDetails.OrderByDescending(m => m.SuggestDocNo).Select(m => m.ICSuggest_TotalCBM).FirstOrDefault(),
                            MDRevise_TotalQty = tr.tr_SuggestDetails.OrderByDescending(m => m.SuggestDocNo).Select(m => m.MDRevise_TotalQty).FirstOrDefault(),
                            MDRevise_TotalCBM = tr.tr_SuggestDetails.OrderByDescending(m => m.SuggestDocNo).Select(m => m.MDRevise_TotalCBM).FirstOrDefault()
                        };

            return query.ToList();
        }

        //Get File for Details
        public DistributionCenterViewModel GetFileDet(string DocNo)
        {
            var fData = repository.GetFileByDocNo(DocNo);
            DistributionCenterViewModel viewModel = new DistributionCenterViewModel();

            viewModel.SuggestDocNo = fData.SuggestDocNo;
            viewModel.FileName = fData.FileName;
            viewModel.FileType = fData.FileType;
            viewModel.FilePath = fData.FilePath;
            viewModel.Extension = fData.Extension;
            viewModel.Size = fData.Size;
            viewModel.Category = fData.Category;
            viewModel.Vendor = fData.VendorNo;
            viewModel.SuggestDocStatus = fData.SuggestDocStatus;
            viewModel.AuditActivity = Convert.ToChar(fData.AuditActivity);
            viewModel.AuditDateTime = fData.AuditDateTime;
            viewModel.AuditUsername = fData.AuditUsername;
            viewModel.IsActive = fData.IsActive;

            return viewModel;
        }

        //Create method for new File
        public DistributionCenterViewModel GetCreateEdit()
        {
            DistributionCenterViewModel viewModel = new DistributionCenterViewModel();
            return viewModel;
        }

        //Edit method for edited File
        public DistributionCenterViewModel GetCreateEdit(string DocNo)
        {
            var tr = repository.GetFileByDocNo(DocNo);
            DistributionCenterViewModel viewModel = new DistributionCenterViewModel();

            viewModel.SuggestDocNo = tr.SuggestDocNo;
            viewModel.FileName = tr.FileName;
            viewModel.FileType = tr.FileType;
            viewModel.FilePath = tr.FilePath;
            viewModel.Extension = tr.Extension;
            viewModel.Size = tr.Size;
            viewModel.Category = tr.Category;
            viewModel.Vendor = tr.VendorNo;
            viewModel.SuggestDocStatus = tr.SuggestDocStatus;
            viewModel.AuditActivity = Convert.ToChar(tr.AuditActivity);
            viewModel.AuditDateTime = tr.AuditDateTime;
            viewModel.AuditUsername = tr.AuditUsername;
            viewModel.IsActive = tr.IsActive;

            return viewModel;
        }

        //Save method for saving new File
        public ProcessResult SaveFile(DistributionCenterViewModel model, string fName, string fExt, string fPath, string userLogin)
        {
            try
            {
                DataTable dataImport = Converter.ExcelToDataTable(fPath, fExt, TABLE_NAME_PROPERTY, COLUMN_NAME_PROPERTY);
                List<CreateEditReceivingPOViewModel> listData = Converter.ReceivingPOData(dataImport);

                //Check if PO Number and Item Code exist to update Receiving
                foreach (var item in listData)
                {
                    var poData = repoPO.GetPOByPONumberAndItemCode(item.PurchaseOrderNo, item.ItemNo);
                    var rcvData = repository.GetReceiptNoByPONumberAndItemCode(item.PurchaseOrderNo, item.ItemNo);

                    if (poData != null && rcvData == null && poData.QuantityOrder == item.Quantity)
                    {
                        repository.InsertReceivingPO(item, userLogin);
                    }
                    else if (poData != null && rcvData == null && poData.QuantityOrder != item.Quantity)
                    {
                        result.ProcessFailed("There is an un-matching Quantity for PO "+ item.PurchaseOrderNo +"!! Please check again");
                    }
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Get details for Remarks form
        public RemarksViewModel GetRemarksDetail(string DocNo)
        {
            var tr = repository.GetFileByDocNo(DocNo);
            RemarksViewModel viewModel = new RemarksViewModel();

            viewModel.SuggestDocNo = tr.SuggestDocNo;
            viewModel.FileName = tr.FileName;

            return viewModel;
        }

        #region Timeline
        //Get Historylist for Timeline
        public List<TimelineViewModel> ListTimeline(string DocNo)
        {
            var tr = repository.GetFileByDocNo(DocNo);
            List<TimelineViewModel> fileHist = new List<TimelineViewModel>();
            try
            {
                string cnnString = ConfigurationManager.ConnectionStrings["IMPORTPURCHASE"].ConnectionString;
                SqlConnection cnn = new SqlConnection(cnnString);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_TimelineFile";
                cmd.Parameters.Add(new SqlParameter("@FileID", tr.SuggestDocNo.ToString()));

                cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    fileHist.Add(new TimelineViewModel()
                    {
                        ID = Convert.ToInt32(reader[0]),
                        History_Tracking = reader[1].ToString(),
                        Interval = Convert.ToInt32(reader[2])
                    });
                }

                cnn.Close();
            }
            catch (Exception)
            {

                throw;
            }

            return fileHist;
        }
        #endregion

        #region Dropdown
        //Get data for Status drop down list
        public IEnumerable<SelectListItem> GetListStatus()
        {
            var ListStatus = from stat in repoStatus.GetStatusForDC()
                             select new SelectListItem()
                             {
                                 Value = stat.SuggestDocStatus,
                                 Text = stat.SuggestDocStatus
                             };
            return ListStatus;
        }

        //Get data for Supplier drop down list
        public IEnumerable<SelectListItem> GetListVendor()
        {
            var ListSupplier = from vdr in repoSupplier.AllVendor()
                               select new SelectListItem()
                               {
                                   Value = vdr.VendorNo,
                                   Text = vdr.VendorNo + " - " + vdr.VendorName
                               };
            return ListSupplier;
        }

        //Get data for Category drop down list
        public IEnumerable<SelectListItem> GetListCategory()
        {
            var ListCategory = from cat in repoCategory.AllCategory()
                               select new SelectListItem()
                               {
                                   Value = cat.Category,
                                   Text = cat.Category
                               };
            return ListCategory;
        }
        #endregion

    }
}
