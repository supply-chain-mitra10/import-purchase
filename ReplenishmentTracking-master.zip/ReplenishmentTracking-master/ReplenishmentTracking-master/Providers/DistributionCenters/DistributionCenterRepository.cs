﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.ProcessResult;
using ViewModels.ReceivingPO;

namespace Providers.DistributionCenters
{
    public class DistributionCenterRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all File from DB
        public IEnumerable<tr_SuggestHeader> AllFiles()
        {
            return entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.mt_SuggestDocStatus.Department.Contains("DC"));
        }

        //Get selected File
        public tr_SuggestHeader GetFileByDocNo(string DocNo)
        {
            return entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo);
        }

        //Get selected Receiving PO Number
        public tr_ReceivingPODetails GetReceiptNoByPONumberAndItemCode(string poNumber, string itemNo)
        {
            return entities.tr_ReceivingPODetails.SingleOrDefault(m => m.PurchaseOrderNo == poNumber && m.ItemNo == itemNo);
        }

        //Insert new Receiving PO
        public void InsertReceivingPO(CreateEditReceivingPOViewModel model, string userLogon)
        {
            ////Get Category ID
            //var cat = entities.mt_Category.SingleOrDefault(m => m.Type == model.CategoryName);
            //int idCat = cat.Id;
            ////Get Site ID
            //var site = entities.mt_Warehouse.SingleOrDefault(m => m.Code == model.SiteCode);
            //int idSite = site.Id;
            ////Get Vendor ID
            //var vendor = entities.mt_Vendor.SingleOrDefault(m => m.Code == model.VendorCode);
            //int idVendor = vendor.Id;
            ////Get MasterBrand ID
            //var mbrand = entities.mt_MasterBrand.SingleOrDefault(m => m.VendorID == model.VendorCode);
            //long idMbrand = mbrand.Id;
            ////Get Item ID
            //var item = entities.mt_Item.SingleOrDefault(m => m.ItemCode == model.ItemCode);
            //long idItem = item.Id;

            try
            {
                var insertRcvPODetail = new tr_ReceivingPODetails()
                {
                    PurchaseOrderNo = model.PurchaseOrderNo,
                    Comment = model.Comment,
                    PostingDate = model.PostingDate,
                    VendorInvNo = model.VendorInvNo,
                    GRNo = model.GRNo,
                    UOM = model.UOM,
                    SubCategory = model.SubCategory,
                    Brand = model.Brand,
                    Quantity = model.Quantity,
                    VendorNo = model.VendorNo,
                    MasterBrand = model.MasterBrand,
                    ItemNo = model.ItemNo,
                    AuditActivity = model.AuditActivity.ToString(),
                    AuditDateTime = model.AuditDateTime,
                    AuditUsername = model.AuditUsername,
                    IsActive = true
                };
                entities.tr_ReceivingPODetails.Add(insertRcvPODetail);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
