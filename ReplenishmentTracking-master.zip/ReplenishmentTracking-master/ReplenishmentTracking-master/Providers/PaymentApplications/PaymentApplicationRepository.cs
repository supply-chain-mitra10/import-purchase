﻿using DataAccess;
using iText.StyledXmlParser.Jsoup.Nodes;
using Providers.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using ViewModels.Commons;
using ViewModels.PaymentApplications;
using ViewModels.ProcessResult;

namespace Providers.PaymentApplications
{
    public class PaymentApplicationRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get selected Payment Application
        public tr_PaymentApplication GetPayAppByPONumber(string PONumber)
        {
            return entities.tr_PaymentApplication.SingleOrDefault(m => m.PurchaseOrderNo == PONumber);
        }
        //public tr_PaymentApplication GetPayAppByPINumber(string PINumber)
        //{
        //    return entities.tr_PaymentApplication.SingleOrDefault(m => m.PINUmber == PINumber);
        //}

        //Insert new PA
        public void InsertPA(CreateEditPaymentApplicationViewModel model, string userLogon)
        {
            try
            {
                //get latest ID for auto generate
                var latestID = entities.tr_PaymentApplication.OrderByDescending(m => m.PaymentAppNo).FirstOrDefault();
                int counterID = 1;
                if (latestID != null)
                {
                    string idcount = latestID.PaymentAppNo.Substring(5, 5);
                    counterID = Convert.ToInt32(idcount) + 1;
                }

                var insertPA = new tr_PaymentApplication()
                {
                    PaymentAppNo = string.Concat("PA", DateTime.Now.ToString("yy"), counterID.ToString().PadLeft(6, '0')),
                    PaymentDate = DateTime.Now,
                    Division = model.Division,
                    PaymentReceiver = model.PaymentReceiver,
                    Amount = model.Amount,
                    AmountText = model.AmountText,
                    CurrencyCodeLocale = model.CurrencyCodeLocale,
                    CurrencyAmountLocale = model.CurrencyAmountLocale,
                    CurrentRateLocale = model.CurrentRateLocale,
                    CurrencyCodeOther = model.CurrencyCodeLocale,
                    CurrencyAmountOther = model.CurrencyAmountLocale,
                    CurrentRateOther = model.CurrentRateLocale,
                    Notes = model.Notes,
                    PaymentTypeNo = model.PaymentTypeNo,
                    PurchaseOrderNo = model.PurchaseOrderNo,
                    Forwarder = model.Forwarder,
                    Party = model.Party,
                    CreatedDate = DateTime.Now,
                    CreatedBy = userLogon,
                    ApprovedBy = userLogon,
                    AgreedBy = userLogon,
                    AuditActivity = AuditActivity.Insert,
                    AuditDateTime = DateTime.Now,
                    AuditUsername = userLogon,
                    IsActive = true
                };
                entities.tr_PaymentApplication.Add(insertPA);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update PA
        public void UpdatePA(CreateEditPaymentApplicationViewModel model, tr_PaymentApplication dataToUpdate, string userLogon)
        {
            try
            {
                dataToUpdate.PaymentTypeNo = model.PaymentTypeNo;
                dataToUpdate.AuditActivity = AuditActivity.Update;
                dataToUpdate.AuditDateTime = DateTime.Now;
                dataToUpdate.AuditUsername = userLogon;
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
