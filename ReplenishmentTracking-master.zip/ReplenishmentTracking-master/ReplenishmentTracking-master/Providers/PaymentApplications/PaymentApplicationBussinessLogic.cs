﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.PaymentApplications;
using ViewModels.ProcessResult;
using Providers.PurchaseOrders;


namespace Providers.PaymentApplications
{
    public class PaymentApplicationBussinessLogic
    {
        private PaymentApplicationRepository repository = new PaymentApplicationRepository();
        private PurchaseOrderRepository repoPO = new PurchaseOrderRepository();
        private ProcessResult result = new ProcessResult();

        //Get data for Update Payment info
        public CreateEditPaymentApplicationViewModel GetCreateEditPaymentApp()
        {
            CreateEditPaymentApplicationViewModel viewModel = new CreateEditPaymentApplicationViewModel();
            return viewModel;
        }

        //Save method for new PA by PO Number
        public ProcessResult SavePAbyPO(CreateEditPaymentApplicationViewModel model, string userLogin)
        {
            var dataPA = repository.GetPayAppByPONumber(model.PurchaseOrderNo);

            try
            {
                if (dataPA == null)
                {
                    //insert PA
                    repository.InsertPA(model, userLogin);
                    //update PA Number to Import detail
                    repoPO.UpdatePO(model.PurchaseOrderNo);

                    result.InsertSucceed();
                }
                else
                {
                    //Update process for PA
                    //repository.UpdatePA(model, dataPA, userLogin);
                    //result.UpdateSucceed();

                    result.ProcessFailed("This PI/PO Payment Application already been created!!");
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for new PA by PI Number
        //public ProcessResult SavePAbyPI(CreateEditPaymentApplicationViewModel model, string userLogin)
        //{
        //    var dataPA = repository.GetPayAppByPINumber(model.PINUmber);

        //    try
        //    {
        //        if (dataPA == null)
        //        {
        //            //insert PA
        //            repository.InsertPA(model, userLogin);
        //            //update PA Number to Import detail
        //            repoPO.UpdatePO(model.PONUmber);

        //            result.InsertSucceed();
        //        }
        //        else
        //        {
        //            //Update process for PA
        //            //repository.UpdatePA(model, dataPA, userLogin);
        //            //result.UpdateSucceed();

        //            result.ProcessFailed("This PI/PO Payment Application already been created!!");
        //        }
        //    }
        //    catch (Exception error)
        //    {
        //        result.ProcessFailed(error.Message);
        //    }
        //    return result;
        //}
    }
}
