﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Data;
using ViewModels.PurchaseOrders;
using ViewModels.ProcessResult;
using Providers.Imports;
using Providers.Helper;


namespace Providers.PurchaseOrders
{
    public class PurchaseOrderBussinessLogic
    {
        private PurchaseOrderRepository repository = new PurchaseOrderRepository();
        private ImportRepository repoImport = new ImportRepository();
        private ProcessResult result = new ProcessResult();

        //Setting excel file active sheet name
        public const string TABLE_NAME_PROPERTY = "Template";
        public const string COLUMN_NAME_PROPERTY = "Item_Code";

        //Get List of PO
        public List<CreateEditPurchaseOrderViewModel> List(string DocNo)
        {
            var query = from tr in repository.AllPOByDocNo(DocNo)
                        //where tr.tr_ProformaInvoiceHeader.QuotationNo == ((DocNo == null) ? tr.tr_ProformaInvoiceHeader.QuotationNo : DocNo)
                        select new CreateEditPurchaseOrderViewModel()
                        {
                            PurchaseOrderNo = tr.PurchaseOrderNo,
                            PurchaseOrderDate = tr.tr_PurchaseOrderHeader.PurchaseOrderDate,
                            ItemNo = tr.ItemNo,
                            LV = tr.LV,
                            UOM = tr.UOM,
                            QuantityOrder = tr.QuantityOrder,
                            UnitPrice = tr.UnitPrice,
                            Extra = tr.Extra,
                            Discount = tr.Discount,
                            Total = tr.Total,
                            TermOfPayment = tr.tr_PurchaseOrderHeader.TermOfPayment,
                            LeadTimeDeliveryExpire = tr.tr_PurchaseOrderHeader.LeadTimeDeliveryExpire,
                            PODateExpire = tr.tr_PurchaseOrderHeader.PODateExpire,
                            POPath = tr.tr_PurchaseOrderHeader.POPath,
                            EstimationDate = tr.tr_PurchaseOrderHeader.EstimationDate,
                            EstimationArrival = tr.tr_PurchaseOrderHeader.EstimationArrival,
                            SPPBNo = tr.tr_PurchaseOrderHeader.SPPBNo,
                            VendorNo = tr.tr_PurchaseOrderHeader.VendorNo,
                            SiteNo = tr.tr_PurchaseOrderHeader.SiteNo,
                            ProformaInvoiceNo = tr.tr_PurchaseOrderHeader.ProformaInvoiceNo,
                            ReceivingPONo = tr.tr_PurchaseOrderHeader.ReceivingPONo,
                            ETDInputDate = tr.tr_PurchaseOrderHeader.ETDInputDate,
                            ETDInputBy = tr.tr_PurchaseOrderHeader.ETDInputBy,
                            ETAInputDate = tr.tr_PurchaseOrderHeader.ETAInputDate,
                            ETAInputBy = tr.tr_PurchaseOrderHeader.ETAInputBy,
                            SPPBInputDate = tr.tr_PurchaseOrderHeader.SPPBInputDate,
                            SPPBInputBy = tr.tr_PurchaseOrderHeader.SPPBInputBy,
                            AuditActivity = Convert.ToChar(tr.AuditActivity),
                            AuditDateTime = tr.AuditDateTime,
                            AuditUsername = tr.AuditUsername,
                            IsActive = tr.IsActive
                        };

            return query.ToList();
        }

        //Get PO Details
        public CreateEditPurchaseOrderViewModel GetPODetails(string PONumber, string ItemNo)
        {
            var po = repository.GetPOByPONo(PONumber, ItemNo);
            CreateEditPurchaseOrderViewModel viewModel = new CreateEditPurchaseOrderViewModel
            {
                PurchaseOrderNo = po.PurchaseOrderNo,
                PurchaseOrderDate = po.tr_PurchaseOrderHeader.PurchaseOrderDate,
                ItemNo = po.ItemNo,
                LV = po.LV,
                UOM = po.UOM,
                QuantityOrder = po.QuantityOrder,
                UnitPrice = po.UnitPrice,
                Extra = po.Extra,
                Discount = po.Discount,
                Total = po.Total,
                TermOfPayment = po.tr_PurchaseOrderHeader.TermOfPayment,
                LeadTimeDeliveryExpire = po.tr_PurchaseOrderHeader.LeadTimeDeliveryExpire,
                PODateExpire = po.tr_PurchaseOrderHeader.PODateExpire,
                POPath = po.tr_PurchaseOrderHeader.POPath,
                EstimationDate = po.tr_PurchaseOrderHeader.EstimationDate,
                EstimationArrival = po.tr_PurchaseOrderHeader.EstimationArrival,
                SPPBNo = po.tr_PurchaseOrderHeader.SPPBNo,
                VendorNo = po.tr_PurchaseOrderHeader.VendorNo,
                SiteNo = po.tr_PurchaseOrderHeader.SiteNo,
                ProformaInvoiceNo = po.tr_PurchaseOrderHeader.ProformaInvoiceNo,
                ReceivingPONo = po.tr_PurchaseOrderHeader.ReceivingPONo,
                ETDInputDate = po.tr_PurchaseOrderHeader.ETDInputDate,
                ETDInputBy = po.tr_PurchaseOrderHeader.ETDInputBy,
                ETAInputDate = po.tr_PurchaseOrderHeader.ETAInputDate,
                ETAInputBy = po.tr_PurchaseOrderHeader.ETAInputBy,
                SPPBInputDate = po.tr_PurchaseOrderHeader.SPPBInputDate,
                SPPBInputBy = po.tr_PurchaseOrderHeader.SPPBInputBy,
                AuditActivity = Convert.ToChar(po.AuditActivity),
                AuditDateTime = po.AuditDateTime,
                AuditUsername = po.AuditUsername,
                IsActive = po.IsActive
            };
            return viewModel;
        }

        //Create method for new PO number
        public CreateEditPurchaseOrderViewModel GetCreateEditPO()
        {
            CreateEditPurchaseOrderViewModel viewModel = new CreateEditPurchaseOrderViewModel();
            return viewModel;
        }

        public CreateEditPurchaseOrderViewModel GetCreateEditPO(string DocNo)
        {
            var po = repository.GetFileByDocNo(DocNo);
            CreateEditPurchaseOrderViewModel viewModel = new CreateEditPurchaseOrderViewModel();
            viewModel.SuggestDocNo = po.SuggestDocNo;

            return viewModel;
        }

        //Get data for Update Payment info
        public CreateEditPurchaseOrderViewModel GetCreateEditPayment(string[] PONumber)
        {
            string ItemCodeAll = "";
            CreateEditPurchaseOrderViewModel viewModel = new CreateEditPurchaseOrderViewModel();

            foreach (var item in PONumber)
            {
                if (item != "" && item != null && item != "true")
                {
                    var po = repository.GetPOByPONo(item);
                    //ItemCodeAll += (po.ItemCode.ToString() + ";");
  
                    //viewModel.Id = po.Id;
                    //viewModel.IdFile = po.IdFile;
                    //viewModel.CodeFile = po.tr_SuggestHeader.Code;
                    //viewModel.PONumber = po.PONumber;
                    //viewModel.PODate = DateTime.Parse(po.PODate.ToLongDateString());
                    //viewModel.PODateExpire = po.PODateExpire;
                    //viewModel.ItemCode = ItemCodeAll;
                    //viewModel.VendorName = po.mt_Vendor.Name;
                    //viewModel.EstimationDate = po.EstimationDate ?? null;
                    //viewModel.EstimationArrival = po.EstimationArrival ?? null;
                    //viewModel.SPPBNo = po.SPPBNo ?? "";
                }
            }

            return viewModel;
        }

        //Save method for saving new File
        public ProcessResult SavePO(CreateEditPurchaseOrderViewModel model, string flag, string fExt, string fPath, string fPathServer, string userLogin)
        {
            //var fileHeader = repository.GetFileByCode(model.CodeFile);
            //var cekFile = repository.GetPOByHeader(fileHeader.Id);

            try
            {
                //if (cekFile == null)
                //{
                //    //Get data from excel
                //    DataTable dataImport = Converter.ExcelToDataTable(fPath, fExt, TABLE_NAME_PROPERTY, COLUMN_NAME_PROPERTY);
                //    List<CreateEditPurchaseOrderViewModel> listData = Converter.POData(dataImport);

                //    //insert PO
                //    repository.InsertPO(model, listData, fPathServer, userLogin);
                //    //update PO Number to Import detail
                //    repoImport.UpdatePOPerItem(listData, fileHeader.Id);

                //    result.InsertSucceed();
                //}
                //else if (cekFile != null && flag == "6")
                //{
                //    //Update Payment info from Finance detail
                //    repository.UpdatePOPayment(model, userLogin);
                //    result.UpdateSucceed();
                //}
                //else
                //{
                //    //Get data from excel
                //    DataTable dataImport = Converter.ExcelToDataTable(fPath, fExt, TABLE_NAME_PROPERTY, COLUMN_NAME_PROPERTY);
                //    List<CreateEditPurchaseOrderViewModel> listData = Converter.POData(dataImport);

                //    //Clear previous data to Update PO
                //    repository.ClearPO(model.CodeFile);
                //    //insert PO
                //    repository.InsertPO(model, listData, fPathServer, userLogin);
                //    //update PO Number to Import detail
                //    repoImport.UpdatePOPerItem(listData, fileHeader.Id);

                //    result.UpdateSucceed();
                //}
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Get data for PI Number drop down list
        public IEnumerable<SelectListItem> GetListPO()
        {
            var ListPO = from po in repository.AllPONumber()
                         select new SelectListItem()
                         {
                             Value = po,
                             Text = po
                         };
            return ListPO;
        }

    }
}
