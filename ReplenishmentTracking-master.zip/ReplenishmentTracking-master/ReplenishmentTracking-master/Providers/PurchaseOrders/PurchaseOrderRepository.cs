﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.PurchaseOrders;
using ViewModels.ProcessResult;
using Providers.Helper;
using ViewModels.Commons;

namespace Providers.PurchaseOrders
{
    public class PurchaseOrderRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get selected File
        public tr_SuggestHeader GetFileByDocNo(string docNo)
        {
            return entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == docNo);
        }
        public tr_SuggestHeader GetPObyDocNo(string docNo)
        {
            return entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == docNo);
        }

        //Get all PO
        public IEnumerable<tr_PurchaseOrderHeader> AllPO()
        {
            return entities.tr_PurchaseOrderHeader.Where(m => m.IsActive == true);
        }
        public IEnumerable<tr_PurchaseOrderDetails> AllPOByDocNo(string docNo)
        {
            var piHeader = entities.tr_ProformaInvoiceHeader.SingleOrDefault(m => m.QuotationNo == docNo);
            return entities.tr_PurchaseOrderDetails.Where(m => m.tr_PurchaseOrderHeader.ProformaInvoiceNo == piHeader.ProformaInvoiceNo);
        }
        //Get all PO Number for Dropdownlist
        public IEnumerable<string> AllPONumber()
        {
            return entities.tr_PurchaseOrderHeader.Where(m => m.IsActive == true).Select(m => m.PurchaseOrderNo).Distinct();
        }

        //Get selected PO
        public tr_PurchaseOrderHeader GetPOByPINo(string piNo)
        {
            return entities.tr_PurchaseOrderHeader.FirstOrDefault(m => m.ProformaInvoiceNo == piNo && m.IsActive == true);
        }
        public IEnumerable<tr_PurchaseOrderDetails> GetPOByPONo(string poNo)
        {
            return entities.tr_PurchaseOrderDetails.Where(m => m.PurchaseOrderNo == poNo);
        }
        public tr_PurchaseOrderDetails GetPOByPONo(string poNo, string itemNo)
        {
            return entities.tr_PurchaseOrderDetails.SingleOrDefault(m => m.PurchaseOrderNo == poNo && m.ItemNo == itemNo && m.IsActive == true);
        }
        public IEnumerable<tr_PurchaseOrderHeader> GetPOHeaderByDocNo(string docNo)
        {
            var pi = entities.tr_ProformaInvoiceHeader.SingleOrDefault(m => m.QuotationNo == docNo && m.IsActive == true);
            return entities.tr_PurchaseOrderHeader.Where(m => m.ProformaInvoiceNo.Contains(pi.ProformaInvoiceNo));
        }
        public IEnumerable<tr_PurchaseOrderDetails> GetPODetailsByDocNo(string docNo)
        {
            var pi = entities.tr_ProformaInvoiceHeader.SingleOrDefault(m => m.QuotationNo == docNo && m.IsActive == true);
            var poHeader = entities.tr_PurchaseOrderHeader.SingleOrDefault(m => m.ProformaInvoiceNo == pi.ProformaInvoiceNo);
            return entities.tr_PurchaseOrderDetails.Where(m => m.PurchaseOrderNo.Contains(poHeader.PurchaseOrderNo));
        }
        public tr_PurchaseOrderDetails GetPOByPONumberAndItemCode(string poNumber, string itemCode)
        {
            return entities.tr_PurchaseOrderDetails.SingleOrDefault(m => m.PurchaseOrderNo == poNumber && m.ItemNo == itemCode);
        }
        public tr_PODetailType GetPOFeeById(string poNo)
        {
            return entities.tr_PODetailType.SingleOrDefault(m => m.PurchaseOrderNo == poNo);
        }

        //Insert new PO
        public void InsertPO(CreateEditPurchaseOrderViewModel model, List<CreateEditPurchaseOrderViewModel> po, string poPath, string userLogon)
        {
            try
            {
                var piData = entities.tr_ProformaInvoiceDetails.Where(m => m.ProformaInvoiceNo == model.ProformaInvoiceNo).ToList();

                for (int i = 0; i < po.Count; i++)
                {
                    var itmID = piData[i].ItemNo;
                    var itmPI = entities.mt_Item.SingleOrDefault(m => m.ItemNo == itmID);
                    string itmCode = itmPI.ItemNo.ToString();

                    ////Get Vendor ID
                    //string vendorName = po[i].IdVendor;
                    //var poVendor = entities.mt_Vendor.SingleOrDefault(m => m.Name == vendorName);
                    //int vendorID = Convert.ToInt32(poVendor.Id);
                    ////Get Warehous ID
                    //string whName = po[i].DeliverTo;
                    //var poDeliverTo = entities.mt_Warehouse.SingleOrDefault(m => m.Name == whName);
                    //int whID = Convert.ToInt32(poDeliverTo.Id);
                    //Get Payment type ID
                    //string payName = po[i].TermOfPayment;
                    //var poPay = entities.mt_PaymentType.SingleOrDefault(m => m.Name == payName);
                    //int payID = Convert.ToInt32(poPay.Id);

                    int intervalDt = Converter.GetTotalMonthsFrom(piData[i].tr_ProformaInvoiceHeader.ProformaInvoiceDate, DateTime.Now);

                    //Validation for PO and PI Invoice Date Expired
                    if (intervalDt <= 4)
                    {
                        //Validation for PO and PI items and Qty matching
                        if (itmCode == po[i].ItemNo && piData[i].Quantity == po[i].QuantityOrder)
                        {
                            var insertPODetails = new tr_PurchaseOrderDetails()
                            {
                                PurchaseOrderNo = po[i].PurchaseOrderNo,
                                ItemNo = po[i].ItemNo,
                                LV = po[i].LV,
                                UOM = po[i].UOM,
                                QuantityOrder = po[i].QuantityOrder,
                                UnitPrice = po[i].UnitPrice,
                                Extra = po[i].Extra,
                                Discount = po[i].Discount,
                                Total = Convert.ToDecimal(po[i].Total),
                                AuditActivity = AuditActivity.Insert,
                                AuditDateTime = DateTime.Now,
                                AuditUsername = userLogon,
                                IsActive = true
                            };
                            entities.tr_PurchaseOrderDetails.Add(insertPODetails);
                        }
                        else
                        {
                            throw new ArgumentException("The Item " + po[i].ItemNo + "in Purchase Order did not match in Performa Invoice!!");
                        }
                    }
                    else
                    {
                        throw new ArgumentException("The PI " + piData[i].ProformaInvoiceNo + "has been Expired!!");
                    }

                }
                entities.SaveChanges();

            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //[Import] Update PO term of payment
        //public void UpdatePOTermofPayment(long fileID, int payID)
        //{
        //    try
        //    {
        //        var updateData = entities.tr_PurchaseOrder.Where(m => m.IdFile == fileID).ToList();
        //        foreach (var item in updateData)
        //        {
        //            item.TermOfPayment = payID;
        //        }

        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        //[Import] Update PO Payment Application form number
        public void UpdatePO(string poNumber)
        {
            try
            {
                //Get current data ID Payment Application
                var dataPA = entities.tr_PaymentApplication.SingleOrDefault(m => m.PurchaseOrderNo == poNumber);

                var updateData = entities.tr_PurchaseOrderHeader.Where(m => m.PurchaseOrderNo == poNumber).ToList();
                foreach (var item in updateData)
                {
                    //item.IdPaymentApp = dataPA.Id;
                }

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //[Import] Update PO detail for Payment info from Finance
        public void UpdatePOPayment(CreateEditPurchaseOrderViewModel po, string userLogin)
        {
            try
            {
                var poDetails = entities.tr_PurchaseOrderDetails.Where(m => m.PurchaseOrderNo == po.PurchaseOrderNo && po.ItemNo.Contains(m.ItemNo)).ToList();
                var updateData = entities.tr_PurchaseOrderHeader.SingleOrDefault(m => m.PurchaseOrderNo == po.PurchaseOrderNo && m.IsActive == true);

                if (po.EstimationDate != null)
                {
                    updateData.EstimationDate = po.EstimationDate;
                    updateData.ETDInputDate = DateTime.Now;
                    updateData.ETDInputBy = userLogin;
                }
                if (po.EstimationArrival != null)
                {
                    updateData.EstimationArrival = po.EstimationArrival;
                    updateData.ETAInputDate = DateTime.Now;
                    updateData.ETAInputBy = userLogin;
                }
                if (po.SPPBNo != null)
                {
                    updateData.SPPBNo = po.SPPBNo;
                    updateData.SPPBInputDate = DateTime.Now;
                    updateData.SPPBInputBy = userLogin;
                }

                entities.SaveChanges();

                ////Update Header status
                //if (po.EstimationDate != null || po.EstimationArrival != null || po.SPPBNo != null)
                //{
                //    updateHeader.Status = 11; //11 = Return from Finance
                //}
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Clear choosen PO Number
        public void ClearPO(string docNo)
        {
            try
            {
                var poHeader = entities.tr_PurchaseOrderHeader.SingleOrDefault(m => m.tr_ProformaInvoiceHeader.QuotationNo == docNo && m.IsActive == true);

                List<tr_PurchaseOrderDetails> listPO = new List<tr_PurchaseOrderDetails>();
                listPO = entities.tr_PurchaseOrderDetails.Where(m => m.PurchaseOrderNo == poHeader.PurchaseOrderNo && m.IsActive == true).ToList();

                //Save previous data to History
                foreach (var item in listPO)
                {
                    MoveToHistPO(item);
                }
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Move PO to History
        public void MoveToHistPO(tr_PurchaseOrderDetails po)
        {
            try
            {
                //Get latest sequence in History table
                int counterSeq = 0;
                var seq = entities.tr_PurchaseOrderDetails_Hist.OrderByDescending(m => m.Sequence).FirstOrDefault();
                if (seq != null)
                {
                    counterSeq = seq.Sequence + 1;
                }

                //foreach (var item in listPo)
                //{
                var insertPODetailHist = new tr_PurchaseOrderDetails_Hist()
                {
                    PurchaseOrderNo = po.PurchaseOrderNo,
                    ItemNo = po.ItemNo,
                    LV = po.LV,
                    UOM = po.UOM,
                    QuantityOrder = po.QuantityOrder,
                    UnitPrice = po.UnitPrice,
                    Extra = po.Extra,
                    Discount = po.Discount,
                    Total = po.Total,
                    AuditActivity = po.AuditActivity,
                    AuditDateTime = po.AuditDateTime,
                    AuditUsername = po.AuditUsername,
                    TimeStamp = DateTime.Now,
                    Sequence = counterSeq,
                    IsActive = po.IsActive
                };
                entities.tr_PurchaseOrderDetails_Hist.Add(insertPODetailHist);
                //}

                //delete all previous PO Number data
                //foreach (var item in listPo)
                //{
                entities.tr_PurchaseOrderDetails.Remove(po);
                //}

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
