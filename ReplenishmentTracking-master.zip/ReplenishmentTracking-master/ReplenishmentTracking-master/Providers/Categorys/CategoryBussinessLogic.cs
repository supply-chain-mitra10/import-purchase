﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.Categorys;
using ViewModels.ProcessResult;
using System.Configuration;

namespace Providers.Categorys
{
    public class CategoryBussinessLogic
    {
        private CategoryRepository repository = new CategoryRepository();
        private ProcessResult result = new ProcessResult();

        //Get Category list to display
        public List<CategoryViewModel> List(IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from cat in repository.AllCategory()
                        where cat.Category.ToString().Contains(IdFilter == null ? "" : IdFilter.Value.ToString())
                        select new CategoryViewModel()
                        {
                            Category = cat.Category,
                            Description = cat.Description,
                            AuditActivity = Convert.ToChar(cat.AuditActivity),
                            AuditDateTime = cat.AuditDateTime,
                            AuditUsername = cat.AuditUsername,
                            IsActive = cat.IsActive
                        };

            return query.ToList();
        }

        //Create method for new Category
        public CreateEditCategoryViewModel GetCreateEdit()
        {
            CreateEditCategoryViewModel viewModel = new CreateEditCategoryViewModel();
            return viewModel;
        }

        //Edit method for edited Category
        public CreateEditCategoryViewModel GetCreateEdit(string categoryNo)
        {
            var category = repository.GetCategory(categoryNo);
            CreateEditCategoryViewModel viewModel = new CreateEditCategoryViewModel();

            viewModel.Category = category.Category;
            viewModel.Description = category.Description;
            viewModel.AuditActivity = Convert.ToChar(category.AuditActivity);
            viewModel.AuditDateTime = category.AuditDateTime;
            viewModel.AuditUsername = category.AuditUsername;
            //viewModel.IsActive = category.IsActive;

            return viewModel;
        }

        //Delete method for one Category
        public ProcessResult GetDelete(string categoryNo)
        {
            try
            {
                repository.DeleteCategory(categoryNo);
                result.DeleteSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new Category
        public ProcessResult SaveCategory(CreateEditCategoryViewModel model, string userLogin)
        {
            try
            {
                if (model.Category == null || model.Category == "")
                {
                    repository.InsertCategory(model, userLogin);
                    result.InsertSucceed();
                }
                else
                {
                    repository.UpdateCategory(model, userLogin);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }
    }
}
