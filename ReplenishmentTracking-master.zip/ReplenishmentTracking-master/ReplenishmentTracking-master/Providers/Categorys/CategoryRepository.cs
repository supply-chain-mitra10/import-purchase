﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.Categorys;
using ViewModels.Commons;
using ViewModels.ProcessResult;

namespace Providers.Categorys
{
    public class CategoryRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all Category from DB
        public IEnumerable<mt_Category> AllCategory()
        {
            return entities.mt_Category;
        }

        //Get selected Category
        public mt_Category GetCategory(string categoryNo)
        {
            return entities.mt_Category.SingleOrDefault(m => m.Category.ToLower() == categoryNo.ToLower());
        }
        //public mt_Category GetCategoryByCode(string CodeCategory)
        //{
        //    return entities.mt_Category.SingleOrDefault(m => m.Type == CodeCategory);
        //}

        //Delete using Json
        public int GetDeleteCategory(string categoryNo)
        {
            return entities.mt_Category.Where(m => m.Category.ToLower() == categoryNo.ToLower()).Count();
        }

        //Insert new Category
        public void InsertCategory(CreateEditCategoryViewModel model, string userLogon)
        {
            //get latest ID for auto generate
            var latestID = entities.mt_Category.OrderByDescending(m => m.Category).FirstOrDefault();
            int counterID = Convert.ToInt32(latestID.Category.Substring(3, 3)) + 1;

            try
            {
                var insertCategory = new mt_Category()
                {
                    Category = model.Category,
                    Description = model.Description,
                    AuditActivity = AuditActivity.Insert,
                    AuditDateTime = DateTime.Now,
                    AuditUsername = userLogon,
                    IsActive = model.IsActive
                };
                entities.mt_Category.Add(insertCategory);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen Category
        public void UpdateCategory(CreateEditCategoryViewModel model, string userLogin)
        {
            try
            {
                var updateData = entities.mt_Category.SingleOrDefault(m => m.Category == model.Category);
                updateData.Category = model.Category;
                updateData.Description = model.Description;
                updateData.AuditActivity = AuditActivity.Update;
                updateData.AuditDateTime = DateTime.Now;
                updateData.AuditUsername = userLogin;
                updateData.IsActive = model.IsActive;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Delete choosen Category
        public void DeleteCategory(string categoryNo)
        {
            try
            {
                var deleteCategory = entities.mt_Category.SingleOrDefault(m => m.Category == categoryNo);
                entities.mt_Category.Remove(deleteCategory);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
