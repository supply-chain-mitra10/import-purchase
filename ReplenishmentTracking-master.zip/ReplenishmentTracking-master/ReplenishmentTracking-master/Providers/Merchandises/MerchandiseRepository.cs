﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.Merchandises;
using ViewModels.ProcessResult;
using ViewModels.Remarkss;
using Providers.Helper;
using ViewModels.Commons;

namespace Providers.Merchandises
{
    public class MerchandiseRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all File from DB
        public IEnumerable<tr_SuggestHeader> AllFiles()
        {
            return entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.mt_SuggestDocStatus.Department.Contains("MD"));
        }

        //Get selected File
        public tr_SuggestHeader GetFile(string FName)
        {
            return entities.tr_SuggestHeader.SingleOrDefault(m => m.FileName == FName);
        }
        public tr_SuggestHeader GetFileByDocNo(string DocNo)
        {
            return entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo);
        }

        //Get Selected Detail
        public IEnumerable<tr_SuggestDetails> AllDetailbyDocNo(string DocNo)
        {
            return entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == DocNo);
        }

        //Delete using Json
        public int GetDeleteFile(string DocNo)
        {
            return entities.tr_SuggestHeader.Where(m => m.SuggestDocNo == DocNo && m.IsActive == true).Count();
        }

        //Insert new File
        public void InsertFile(MerchandiseViewModel model, string fname, string fext, int fsize, string fpath, string userLogon)
        {
            string ftype = Converter.GetFileTypeByExtension(fext);
            //byte[] fcontent = Converter.GetByteFromFile(fpath);

            //get latest ID for auto generate
            var latestID = entities.tr_SuggestHeader.OrderByDescending(m => m.SuggestDocNo).FirstOrDefault();
            int counterID = 1;
            if (latestID != null)
            {
                if (latestID.SuggestDocNo.Substring(2, 2) == DateTime.Now.ToString("yy"))
                {
                    string idcount = latestID.SuggestDocNo.Substring(4, 6); //e.q.SG22000001
                    counterID = Convert.ToInt32(idcount) + 1;
                }
            }

            //get ID for Dropdownlist selected value
            int categoryID = Convert.ToInt32(model.Category);
            int vendorID = Convert.ToInt32(model.Vendor);

            try
            {
                var insertFile = new tr_SuggestHeader()
                {
                    SuggestDocNo = string.Concat("RV", DateTime.Now.ToString("yy"), counterID.ToString().PadLeft(6, '0')),
                    FileName = fname,
                    FileType = ftype,
                    FilePath = fpath,
                    Extension = fext,
                    Size = fsize,
                    Category = model.Category,
                    VendorNo = model.Vendor,
                    SuggestDocStatus = SuggestDocStatus.New,
                    AuditActivity = AuditActivity.Insert,
                    AuditDateTime = DateTime.Now,
                    AuditUsername = userLogon,
                    IsActive = true
                };
                entities.tr_SuggestHeader.Add(insertFile);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen File to Revise (Revise by File Upload)
        public void UpdateReviseHeader(MerchandiseViewModel model, string fname, string fext, int fsize, string userLogon)
        {
            string ftype = Converter.GetFileTypeByExtension(fext);
            //int catID = Convert.ToInt32(model.Category);
            //int venID = Convert.ToInt32(model.Vendor);

            //get ID for Dropdownlist selected value
            //var categoryID = entities.mt_Category.SingleOrDefault(m => m.Id == catID);
            //var vendorID = entities.mt_Vendor.SingleOrDefault(m => m.Id == venID);

            try
            {
                var updateData = entities.tr_SuggestHeader.SingleOrDefault(m => m.FileName == fname);
                updateData.FileName = fname.Substring(0, fname.IndexOf('.')) + "_REVISE" + fext;     //name auto add _REVISE
                updateData.FileType = ftype;
                updateData.Extension = fext;
                updateData.Size = fsize;
                updateData.Category = model.Category;
                updateData.VendorNo = model.Vendor;
                updateData.SuggestDocStatus = SuggestDocStatus.WaitingICApproval;
                updateData.AuditActivity = AuditActivity.Update;
                updateData.AuditDateTime = DateTime.Now;
                updateData.AuditUsername = userLogon;
                updateData.IsActive = true;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen File to Revise (Revise by Form)
        public void UpdateReviseForm(string DocNo, string userLogon)
        {
            try
            {
                var updateData = entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo);
                string fname = updateData.FileName;
                string fext = updateData.Extension;
                if (!updateData.FileName.Contains("_REVISE"))    //name auto add _REVISE
                {
                    updateData.FileName = fname.Substring(0, fname.IndexOf('.')) + "_REVISE" + fext;    
                }       
                updateData.SuggestDocStatus = SuggestDocStatus.WaitingICApproval;
                //updateData.ReviseDate = DateTime.Now;
                //updateData.ReviseBy = userLogon;
                updateData.IsActive = true;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen File
        public void UpdateFile(MerchandiseViewModel model, string fname, string fext, int fsize, string flag, string userLogon)
        {
            string ftype = Converter.GetFileTypeByExtension(fext);
            int catID = Convert.ToInt32(model.Category);
            int venID = Convert.ToInt32(model.Vendor);

            //get ID for Dropdownlist selected value
            //var categoryID = entities.mt_Category.SingleOrDefault(m => m.Id == catID);
            //var vendorID = entities.mt_Vendor.SingleOrDefault(m => m.Id == venID);

            try
            {
                var updateData = entities.tr_SuggestHeader.SingleOrDefault(m => m.FileName == fname);
                updateData.SuggestDocNo = model.SuggestDocNo;
                updateData.FileName = fname;
                updateData.FileType = ftype;
                updateData.Extension = fext;
                updateData.Size = fsize;
                updateData.Category = model.Category;
                updateData.VendorNo = model.Vendor;
                updateData.SuggestDocStatus = (flag == "1" && updateData.SuggestDocStatus == SuggestDocStatus.Confirm) ? SuggestDocStatus.Open
                    : ((flag == "2") ? SuggestDocStatus.ApprovedbyMD : updateData.SuggestDocStatus);
                updateData.AuditActivity = AuditActivity.Update;
                updateData.AuditDateTime = DateTime.Now;
                updateData.AuditUsername = userLogon;
                updateData.IsActive = true;

                //updateData.ApproveByMD = (flag == "2") ? true : false;
                //if (flag == "2")
                //{
                //    updateData.ApprovedMDDate = DateTime.Now;
                //    updateData.ApprovedMDBy = userLogon;
                //}
                //else
                //{
                //    updateData.UpdatedDate = DateTime.Now;
                //    updateData.UpdatedBy = userLogon;
                //}   


                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Set choosen File and Details to revise
        public void SetRevise(string DocNo, string userLogon)
        {
            try
            {
                var revFileHeader = entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo && m.IsActive == true);
                var revFileDetail = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == DocNo && m.IsActive == true).ToList();

                revFileHeader.SuggestDocStatus = SuggestDocStatus.Revise;
                //revFileHeader.RejectByMD = true;
                //revFileHeader.ReviseDate = DateTime.Now;
                //revFileHeader.ReviseBy = userLogon;
                
                //reset approval from IC
                //revFileHeader.ApproveByIC = false;
                //revFileHeader.ApprovedICDate = null;
                //revFileHeader.ApprovedICBy = "";

                //delFileHeader.IsActive = false;
                //entities.tr_SuggestHeader.Remove(deleteFile);

                foreach (var item in revFileDetail)
                {
                    item.IsActive = false;
                }

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Close choosen File and Details to close
        public void CloseFile(string DocNo, string userLogon)
        {
            try
            {
                var delFileHeader = entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo && m.IsActive == true);
                var delFileDetail = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == DocNo && m.IsActive == true);

                delFileHeader.SuggestDocStatus = SuggestDocStatus.Close;
                //delFileHeader.CloseByMD = true;
                //delFileHeader.CloseDate = DateTime.Now;
                //delFileHeader.CloseBy = userLogon;
                //delFileHeader.IsActive = false;
                //entities.tr_SuggestHeader.Remove(deleteFile);

                foreach (var item in delFileDetail)
                {
                    item.IsActive = false;
                }

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Move choosen File to History
        public void MoveToHist(string DocNo)
        {
            try
            {
                //Get latest sequence in History table
                int counterSeq = 0;
                var seq = entities.tr_SuggestHeader_Hist.OrderByDescending(m => m.Sequence).FirstOrDefault();
                if (seq != null)
                {
                    counterSeq = seq.Sequence + 1;
                }

                var mvFileHeader = entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo && m.IsActive == true);
                var mvFileDetail = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == DocNo && m.IsActive == true);

                var moveFileHeader = new tr_SuggestHeader_Hist()
                {
                    SuggestDocNo = mvFileHeader.SuggestDocNo,
                    FileName = mvFileHeader.FileName,
                    FileType = mvFileHeader.FileType,
                    FilePath = mvFileHeader.FilePath,
                    Extension = mvFileHeader.Extension,
                    Size = mvFileHeader.Size,
                    Category = mvFileHeader.Category,
                    VendorNo = mvFileHeader.VendorNo,
                    SuggestDocStatus = mvFileHeader.SuggestDocStatus,
                    AuditActivity = mvFileHeader.AuditActivity,
                    AuditDateTime = mvFileHeader.AuditDateTime,
                    AuditUsername = mvFileHeader.AuditUsername,
                    TimeStamp = DateTime.Now,
                    Sequence = counterSeq,
                    IsActive = mvFileHeader.IsActive
                };

                List<tr_SuggestDetails_Hist> moveFileDetail = new List<tr_SuggestDetails_Hist>();
                foreach (var item in mvFileDetail)
                {
                    var importHist = new tr_SuggestDetails_Hist()
                    {
                        SuggestDocNo = item.SuggestDocNo,
                        SiteNo = item.SiteNo,
                        SiteName = item.SiteName,
                        VendorNo = item.VendorNo,
                        VendorName = item.VendorName,
                        MasterBrand = item.MasterBrand,
                        ItemNo = item.ItemNo,
                        ItemName = item.ItemName,
                        Category = item.Category,
                        SystemSuggestQty = item.SystemSuggestQty,
                        AverageSales = item.AverageSales,
                        LeadTime = item.LeadTime,
                        HighestAvgLeadTimeActual = item.HighestAvgLeadTimeActual,
                        SafetyStockDays = item.SafetyStockDays,
                        OrderPeriod = item.OrderPeriod,
                        MinimumStock = item.MinimumStock,
                        MaximumStock = item.MaximumStock,
                        ReorderPoint = item.ReorderPoint,
                        OptimumMax = item.OptimumMax,
                        OptimumMaxMultiple = item.OptimumMaxMultiple,
                        StockOnHand = item.StockOnHand,
                        OutstandingPO = item.OutstandingPO,
                        OutstandingTR = item.OutstandingTR,
                        OutstandingTO = item.OutstandingTO,
                        MultiplePurchaseQty = item.MultiplePurchaseQty,
                        OutstandingTRfromOtherStore = item.OutstandingTRfromOtherStore,
                        CalculatedSuggest = item.CalculatedSuggest,
                        CalculatedStockDaysSuggest = item.CalculatedStockDaysSuggest,
                        CalculatedTotalStockDays = item.CalculatedTotalStockDays,
                        ReviseMDSuggest = item.ReviseMDSuggest,
                        ReviseMDStockDaysSuggest = item.ReviseMDStockDaysSuggest,
                        ReviseMDTotalStockDays = item.ReviseMDTotalStockDays,
                        ICSuggest_TotalQty = item.ICSuggest_TotalQty,
                        ICSuggest_TotalCBM = item.ICSuggest_TotalCBM,
                        MDRevise_TotalQty = item.MDRevise_TotalQty,
                        MDRevise_TotalCBM = item.MDRevise_TotalCBM,
                        AuditActivity = item.AuditActivity,
                        AuditDateTime = item.AuditDateTime,
                        AuditUsername = item.AuditUsername,
                        TimeStamp = DateTime.Now,
                        Sequence = counterSeq,
                        IsActive = item.IsActive
                    };
                    moveFileDetail.Add(importHist);
                }

                entities.tr_SuggestHeader_Hist.Add(moveFileHeader);
                entities.tr_SuggestDetails_Hist.AddRange(moveFileDetail);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

    }
}
