﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.Remarkss;
using ViewModels.ProcessResult;
using ViewModels.Commons;

namespace Providers.Remarkss
{
    public class RemarksRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all Remarks from DB
        public IEnumerable<tr_Remarks> AllFiles()
        {
            return entities.tr_Remarks.Where(m => m.IsActive == true);
        }

        //Get Remarks for MD
        public tr_Remarks GetRemarks(string DocNo, string userId)
        {
            return entities.tr_Remarks.OrderByDescending(m => m.SuggestDocNo).ThenBy(m => m.RemarksNo).FirstOrDefault(m => m.SuggestDocNo == DocNo && m.AuditUsername == userId /*&& m.mt_UserGroup.GroupName == "Merchandise"*/);
        }

        //Insert Remarks
        public void InsertRemarks(RemarksViewModel model, string userLogin)
        {
            try
            {
                //Get Group ID
                var userData = entities.mt_User.SingleOrDefault(m => m.UserId == userLogin);
                string dept = userData.mt_UserGroup.GroupName.ToString();
                var group = entities.mt_UserGroup.SingleOrDefault(m => m.GroupName == dept);

                var insertRemarks = new tr_Remarks()
                {
                    SuggestDocNo = model.SuggestDocNo,
                    RemarksNo = model.RemarksNo,
                    Remarks = model.Remarks,
                    AuditActivity = AuditActivity.Insert,
                    AuditDateTime = DateTime.Now,
                    AuditUsername = userLogin,
                    IsActive = true
                };
                entities.tr_Remarks.Add(insertRemarks);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update Remarks
        public void UpdateRemarks(RemarksViewModel model, string userLogin)
        {
            try
            {
                //Get Group ID
                var userData = entities.mt_User.SingleOrDefault(m => m.UserId == userLogin);
                string dept = userData.mt_UserGroup.GroupName.ToString();
                var group = entities.mt_UserGroup.SingleOrDefault(m => m.GroupName == dept);

                var updateRemarks = GetRemarks(model.SuggestDocNo, userLogin);
                updateRemarks.SuggestDocNo = model.SuggestDocNo;
                updateRemarks.RemarksNo = model.RemarksNo;
                updateRemarks.Remarks = model.Remarks;
                updateRemarks.AuditActivity = AuditActivity.Update;
                updateRemarks.AuditDateTime = DateTime.Now;
                updateRemarks.AuditUsername = userLogin;
                updateRemarks.IsActive = true;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
