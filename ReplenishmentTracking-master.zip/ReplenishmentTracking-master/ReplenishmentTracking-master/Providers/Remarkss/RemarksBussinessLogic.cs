﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.Remarkss;
using ViewModels.ProcessResult;

namespace Providers.Remarkss
{
    public class RemarksBussinessLogic
    {
        private RemarksRepository repository = new RemarksRepository();
        private ProcessResult result = new ProcessResult();

        //Save method for Remarks
        public ProcessResult SaveRemarksData(RemarksViewModel model, string login)
        {
            var cekFile = repository.GetRemarks(model.SuggestDocNo, login);

            try
            {
                if (cekFile == null)
                {
                    //Insert Remarks
                    repository.InsertRemarks(model, login);
                    result.InsertSucceed();
                }
                else
                {
                    //Update Remarks
                    repository.UpdateRemarks(model, login);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }
    }
}
