﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.PODetailTypes;
using ViewModels.ProcessResult;
using Providers.Helper;
using ViewModels.Commons;

namespace Providers.PODetailTypes
{
    public class PODetailTypeRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all PO Detail type from DB
        public IEnumerable<tr_PODetailType> AllPODetailType()
        {
            return entities.tr_PODetailType;
        }

        //Get selected PO Detail type
        public tr_PODetailType GetPODetailType(string PODtlTypeNo)
        {
            return entities.tr_PODetailType.SingleOrDefault(m => m.PODetailTypeNo == PODtlTypeNo);
        }
        public tr_PODetailType GetPODetailTypeByPO(string PONo)
        {
            return entities.tr_PODetailType.SingleOrDefault(m => m.PurchaseOrderNo == PONo);
        }

        //Delete PO Detail type using Json
        public int GetDeletePODetailType(string PODtlTypeNo)
        {
            return entities.tr_PODetailType.Where(m => m.PODetailTypeNo == PODtlTypeNo).Count();
        }

        //Insert new PO Detail type
        public void InsertPODetailType(CreateEditPODetailTypeViewModel model, string userLogon)
        {
            try
            {
                var insertPDT = new tr_PODetailType()
                {
                    PurchaseOrderNo = model.PurchaseOrderNo,
                    PODetailTypeNo = model.PODetailTypeNo,
                    PODetailDescription = model.PODetailDescription,
                    PODetailValue = model.PODetailValue,
                    AuditActivity = AuditActivity.Insert,
                    AuditDateTime = model.AuditDateTime,
                    AuditUsername = model.AuditUsername,
                    IsActive = true
                };
                entities.tr_PODetailType.Add(insertPDT);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen PO Detail type
        public void UpdatePODetailType(CreateEditPODetailTypeViewModel model)
        {
            try
            {
                var updateData = entities.tr_PODetailType.SingleOrDefault(m => m.PODetailTypeNo == model.PODetailTypeNo);
                updateData.PurchaseOrderNo = model.PurchaseOrderNo;
                //updateData.PODetailTypeNo = model.PODetailTypeNo;
                updateData.PODetailDescription = model.PODetailDescription;
                updateData.PODetailValue = model.PODetailValue;
                updateData.AuditActivity = model.AuditActivity;
                updateData.AuditDateTime = model.AuditDateTime;
                updateData.AuditUsername = model.AuditUsername;
                updateData.IsActive = model.IsActive;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Delete choosen PO Detail type
        public void DeletePODetailType(string PODtlTypeNo, string PONumber)
        {
            try
            {
                var deletePDT = entities.tr_PODetailType.SingleOrDefault(m => m.PODetailTypeNo == PODtlTypeNo && m.PurchaseOrderNo == PONumber);
                entities.tr_PODetailType.Remove(deletePDT);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
