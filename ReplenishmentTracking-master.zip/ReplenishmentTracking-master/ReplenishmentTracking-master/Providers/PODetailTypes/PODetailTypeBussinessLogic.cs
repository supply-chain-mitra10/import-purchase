﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.PODetailTypes;
using ViewModels.ProcessResult;
using System.Configuration;
using System.Web.Mvc;

namespace Providers.PODetailTypes
{
    public class PODetailTypeBussinessLogic
    {
        private PODetailTypeRepository repository = new PODetailTypeRepository();
        private ProcessResult result = new ProcessResult();

        //Get payment list to display
        public List<PODetailTypeViewModel> List(IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from pdt in repository.AllPODetailType()
                        where pdt.PODetailTypeNo.ToString().Contains(IdFilter == null ? "" : IdFilter.Value.ToString())
                        select new PODetailTypeViewModel()
                        {
                            PurchaseOrderNo = pdt.PurchaseOrderNo,
                            PODetailTypeNo = pdt.PODetailTypeNo,
                            PODetailDescription = pdt.PODetailDescription,
                            PODetailValue = pdt.PODetailValue,
                            AuditActivity = pdt.AuditActivity,
                            AuditDateTime = pdt.AuditDateTime,
                            AuditUsername = pdt.AuditUsername,
                            IsActive = pdt.IsActive
                        };

            return query.ToList();
        }


        //Create method for new PO Detail Type
        public CreateEditPODetailTypeViewModel GetCreateEdit()
        {
            CreateEditPODetailTypeViewModel viewModel = new CreateEditPODetailTypeViewModel();
            return viewModel;
        }

        //Edit method for edited PO Detail Type
        public CreateEditPODetailTypeViewModel GetCreateEdit(string PONumber)
        {
            var pdtData = repository.GetPODetailTypeByPO(PONumber);
            CreateEditPODetailTypeViewModel viewModel = new CreateEditPODetailTypeViewModel();

            viewModel.PurchaseOrderNo = pdtData.PurchaseOrderNo;
            viewModel.PODetailTypeNo = pdtData.PODetailTypeNo;
            viewModel.PODetailDescription = pdtData.PODetailDescription;
            viewModel.PODetailValue = pdtData.PODetailValue;
            viewModel.IsActive = pdtData.IsActive;

            return viewModel;
        }

        //Delete method for one PO Detail Type
        public ProcessResult GetDelete(string PDTNo, string PONumber)
        {
            try
            {
                repository.DeletePODetailType(PDTNo, PONumber);
                result.DeleteSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new PO Detail Type
        public ProcessResult SavePODetailType(CreateEditPODetailTypeViewModel model, string userLogin)
        {
            try
            {
                if (model.PODetailTypeNo == string.Empty || model.PODetailTypeNo == "")
                {
                    repository.InsertPODetailType(model, userLogin);
                    result.InsertSucceed();
                }
                else
                {
                    repository.UpdatePODetailType(model);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }
    }
}
