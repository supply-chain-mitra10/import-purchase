﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.Imports;
using ViewModels.Dashboards;
using ViewModels.ProcessResult;
using ViewModels.Remarkss;
using Providers.SuggestDocStatuss;
using Providers.Vendors;
using Providers.Categorys;
using Providers.Items;
using Providers.PaymentTypes;
using Providers.ProformaInvoices;
using Providers.PurchaseOrders;
using Providers.Users;
using Providers.Helper;
using System.Configuration;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using ViewModels.Commons;

namespace Providers.Imports
{
    public class ImportBussinessLogic
    {
        private ImportRepository repository = new ImportRepository();       
        private SuggestDocStatusRepository repoStatus = new SuggestDocStatusRepository();
        private VendorRepository repoVendor = new VendorRepository();
        private CategoryRepository repoCategory = new CategoryRepository();
        private ItemRepository repoItem = new ItemRepository();
        private PaymentTypeRepository repoPayment = new PaymentTypeRepository();
        private ProformaInvoiceRepository repoPI = new ProformaInvoiceRepository();
        private PurchaseOrderRepository repoPO = new PurchaseOrderRepository();
        private UserRepository repoUser = new UserRepository();
        private ProcessResult result = new ProcessResult();

        //Setting excel file active sheet name
        public const string TABLE_NAME_PROPERTY = "Template";

        //Get File list to display
        public List<ImportViewModel> List()
        {
            var query = from tr in repository.AllFiles()
                        orderby tr.AuditDateTime descending
                        select new ImportViewModel()
                        {
                            SuggestDocNo = tr.SuggestDocNo,
                            FileName = tr.FileName,
                            FileType = tr.FileType,
                            FilePath = tr.FilePath,
                            Extension = tr.Extension,
                            Size = tr.Size,
                            Category = tr.Category,
                            Vendor = tr.VendorNo,
                            SuggestDocStatus = tr.SuggestDocStatus,
                            AuditActivity = Convert.ToChar(tr.AuditActivity),
                            AuditDateTime = tr.AuditDateTime,
                            AuditUsername = tr.AuditUsername,
                            IsActive = tr.IsActive
                        };

            return query.ToList();
        }

        //Get Items list to display
        public List<SuggestDetailViewModel> ListItems(string DocNo)
        {
            var query = from tr in repository.AllItems()
                        where tr.SuggestDocNo == ((DocNo == null || DocNo == "") ? tr.SuggestDocNo : DocNo)
                        orderby tr.CalculatedSuggest descending
                        select new SuggestDetailViewModel()
                        {
                            SuggestDocNo = tr.SuggestDocNo,
                            SiteNo = tr.SiteNo,
                            SiteName = tr.SiteName,
                            VendorNo = tr.VendorNo,
                            VendorName = tr.VendorName,
                            MasterBrand = tr.MasterBrand,
                            ItemNo = tr.mt_Item.ItemNo,
                            ItemName = tr.ItemName,
                            Category = tr.Category,
                            SystemSuggestQty = tr.SystemSuggestQty,
                            AverageSales = tr.AverageSales,
                            LeadTime = tr.LeadTime,
                            HighestAvgLeadTimeActual = tr.HighestAvgLeadTimeActual,
                            SafetyStockDays = tr.SafetyStockDays,
                            OrderPeriod = tr.OrderPeriod,
                            MinimumStock = tr.MinimumStock,
                            MaximumStock = tr.MaximumStock,
                            ReorderPoint = tr.ReorderPoint,
                            OptimumMax = tr.OptimumMax,
                            OptimumMaxMultiple = tr.OptimumMaxMultiple,
                            StockOnHand = tr.StockOnHand,
                            OutstandingPO = tr.OutstandingPO,
                            OutstandingTR = tr.OutstandingTR,
                            OutstandingTO = tr.OutstandingTO,
                            MultiplePurchaseQty = tr.MultiplePurchaseQty,
                            OutstandingTRfromOtherStore = tr.OutstandingTRfromOtherStore,
                            CalculatedSuggest = tr.CalculatedSuggest,
                            CalculatedStockDaysSuggest = tr.CalculatedStockDaysSuggest,
                            CalculatedTotalStockDays = tr.CalculatedTotalStockDays,
                            ReviseMDSuggest = tr.ReviseMDSuggest,
                            ReviseMDStockDaysSuggest = tr.ReviseMDStockDaysSuggest,
                            ReviseMDTotalStockDays = tr.ReviseMDTotalStockDays,
                            ICSuggest_TotalQty = tr.ICSuggest_TotalQty,
                            ICSuggest_TotalCBM = tr.ICSuggest_TotalCBM,
                            MDRevise_TotalQty = tr.MDRevise_TotalQty,
                            MDRevise_TotalCBM = tr.MDRevise_TotalCBM,
                            AuditActivity = Convert.ToChar(tr.AuditActivity),
                            AuditDateTime = tr.AuditDateTime,
                            AuditUsername = tr.AuditUsername,
                            IsActive = tr.IsActive
                        };

            return query.ToList();
        }

        //Get revised items list to display
        public List<SuggestDetailViewModel> ListReviseItems(string DocNo)
        {
            var query = from tr in repository.AllItemsNoFilter()
                        where tr.SuggestDocNo == ((DocNo == null || DocNo == "") ? tr.SuggestDocNo : DocNo)
                            && tr.IsActive == false     //revised item IsActive = false
                        orderby tr.CalculatedSuggest descending
                        select new SuggestDetailViewModel()
                        {
                            SuggestDocNo = tr.SuggestDocNo,
                            SiteNo = tr.SiteNo,
                            SiteName = tr.SiteName,
                            VendorNo = tr.VendorNo,
                            VendorName = tr.VendorName,
                            MasterBrand = tr.MasterBrand,
                            ItemNo = tr.mt_Item.ItemNo,
                            ItemName = tr.ItemName,
                            Category = tr.Category,
                            SystemSuggestQty = tr.SystemSuggestQty,
                            AverageSales = tr.AverageSales,
                            LeadTime = tr.LeadTime,
                            HighestAvgLeadTimeActual = tr.HighestAvgLeadTimeActual,
                            SafetyStockDays = tr.SafetyStockDays,
                            OrderPeriod = tr.OrderPeriod,
                            MinimumStock = tr.MinimumStock,
                            MaximumStock = tr.MaximumStock,
                            ReorderPoint = tr.ReorderPoint,
                            OptimumMax = tr.OptimumMax,
                            OptimumMaxMultiple = tr.OptimumMaxMultiple,
                            StockOnHand = tr.StockOnHand,
                            OutstandingPO = tr.OutstandingPO,
                            OutstandingTR = tr.OutstandingTR,
                            OutstandingTO = tr.OutstandingTO,
                            MultiplePurchaseQty = tr.MultiplePurchaseQty,
                            OutstandingTRfromOtherStore = tr.OutstandingTRfromOtherStore,
                            CalculatedSuggest = tr.CalculatedSuggest,
                            CalculatedStockDaysSuggest = tr.CalculatedStockDaysSuggest,
                            CalculatedTotalStockDays = tr.CalculatedTotalStockDays,
                            ReviseMDSuggest = tr.ReviseMDSuggest,
                            ReviseMDStockDaysSuggest = tr.ReviseMDStockDaysSuggest,
                            ReviseMDTotalStockDays = tr.ReviseMDTotalStockDays,
                            ICSuggest_TotalQty = tr.ICSuggest_TotalQty,
                            ICSuggest_TotalCBM = tr.ICSuggest_TotalCBM,
                            MDRevise_TotalQty = tr.MDRevise_TotalQty,
                            MDRevise_TotalCBM = tr.MDRevise_TotalCBM,
                            AuditActivity = Convert.ToChar(tr.AuditActivity),
                            AuditDateTime = tr.AuditDateTime,
                            AuditUsername = tr.AuditUsername,
                            IsActive = tr.IsActive
                        };

            return query.ToList();
        }

        //Get File for Details
        public ImportViewModel GetFileDet(string DocNo)
        {
            var fData = repository.GetFileByDocNo(DocNo);
            ImportViewModel viewModel = new ImportViewModel();

            viewModel.SuggestDocNo = fData.SuggestDocNo;
            viewModel.FileName = fData.FileName;
            viewModel.FileType = fData.FileType;
            viewModel.FilePath = fData.FilePath;
            viewModel.Extension = fData.Extension;
            viewModel.Size = fData.Size;
            viewModel.Category = fData.Category.ToString();
            viewModel.Vendor = fData.VendorNo;
            viewModel.SuggestDocStatus = fData.SuggestDocStatus;
            viewModel.AuditActivity = Convert.ToChar(fData.AuditActivity);
            viewModel.AuditDateTime = fData.AuditDateTime;
            viewModel.AuditUsername = fData.AuditUsername;
            viewModel.IsActive = fData.IsActive;

            return viewModel;
        }

        //Get Item for Details
        public SuggestDetailViewModel GetItemDet(string SuggestDocNo, string ItemNo)
        {
            var iData = repository.GetItemByIdItem(SuggestDocNo, ItemNo);
            SuggestDetailViewModel viewModel = new SuggestDetailViewModel();

            viewModel.SuggestDocNo = iData.SuggestDocNo;
            viewModel.SiteNo = iData.SiteNo;
            viewModel.SiteName = iData.SiteName;
            viewModel.VendorNo = iData.VendorNo;
            viewModel.VendorName = iData.VendorName;
            viewModel.MasterBrand = iData.MasterBrand;
            viewModel.ItemNo = iData.mt_Item.ItemNo;
            viewModel.ItemName = iData.ItemName;
            viewModel.Category = iData.Category;
            viewModel.SystemSuggestQty = iData.SystemSuggestQty;
            viewModel.AverageSales = iData.AverageSales;
            viewModel.LeadTime = iData.LeadTime;
            viewModel.HighestAvgLeadTimeActual = iData.HighestAvgLeadTimeActual;
            viewModel.SafetyStockDays = iData.SafetyStockDays;
            viewModel.OrderPeriod = iData.OrderPeriod;
            viewModel.MinimumStock = iData.MinimumStock;
            viewModel.MaximumStock = iData.MaximumStock;
            viewModel.ReorderPoint = iData.ReorderPoint;
            viewModel.OptimumMax = iData.OptimumMax;
            viewModel.OptimumMaxMultiple = iData.OptimumMaxMultiple;
            viewModel.StockOnHand = iData.StockOnHand;
            viewModel.OutstandingPO = iData.OutstandingPO;
            viewModel.OutstandingTR = iData.OutstandingTR;
            viewModel.OutstandingTO = iData.OutstandingTO;
            viewModel.MultiplePurchaseQty = iData.MultiplePurchaseQty;
            viewModel.OutstandingTRfromOtherStore = iData.OutstandingTRfromOtherStore;
            viewModel.CalculatedSuggest = iData.CalculatedSuggest;
            viewModel.CalculatedStockDaysSuggest = iData.CalculatedStockDaysSuggest;
            viewModel.CalculatedTotalStockDays = iData.CalculatedTotalStockDays;
            viewModel.ReviseMDSuggest = iData.ReviseMDSuggest;
            viewModel.ReviseMDStockDaysSuggest = iData.ReviseMDStockDaysSuggest;
            viewModel.ReviseMDTotalStockDays = iData.ReviseMDTotalStockDays;
            viewModel.ICSuggest_TotalQty = iData.ICSuggest_TotalQty;
            viewModel.ICSuggest_TotalCBM = iData.ICSuggest_TotalCBM;
            viewModel.MDRevise_TotalQty = iData.MDRevise_TotalQty;
            viewModel.MDRevise_TotalCBM = iData.MDRevise_TotalCBM;
            viewModel.AuditActivity = Convert.ToChar(iData.AuditActivity);
            viewModel.AuditDateTime = iData.AuditDateTime;
            viewModel.AuditUsername = iData.AuditUsername;
            viewModel.IsActive = iData.IsActive;

            return viewModel;
        }

        #region Timeline
        //Get Historylist for Timeline
        public List<TimelineViewModel> ListTimeline(string DocNo)
        {
            var tr = repository.GetFileByDocNo(DocNo);
            List<TimelineViewModel> fileHist = new List<TimelineViewModel>();
            try
            {
                string cnnString = ConfigurationManager.ConnectionStrings["IMPORTPURCHASE"].ConnectionString;
                SqlConnection cnn = new SqlConnection(cnnString);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnn;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "sp_TimelineFile";
                cmd.Parameters.Add(new SqlParameter("@FileID", tr.SuggestDocNo.ToString()));

                cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    fileHist.Add(new TimelineViewModel()
                    {
                        ID = Convert.ToInt32(reader[0]),
                        History_Tracking = reader[1].ToString(),
                        Interval = Convert.ToInt32(reader[2])
                    });
                }

                cnn.Close();
            }
            catch (Exception)
            {

                throw;
            }

            return fileHist;
        }
        #endregion

        //Get details for Remarks form
        public RemarksViewModel GetRemarksDetail(string DocNo)
        {
            var tr = repository.GetFileByDocNo(DocNo);
            RemarksViewModel viewModel = new RemarksViewModel();

            viewModel.SuggestDocNo = tr.SuggestDocNo;
            viewModel.FileName = tr.FileName;

            return viewModel;
        }

        //Get PI for Download
        public string GetPIDetail(string DocNo)
        {
            //string piPath = "";
            var piData = repoPI.GetPIByDocNo(DocNo);
            //foreach (var item in piData)
            //{
            //    piPath = item.PIPath;
            //}

            return piData.PIPath;

            //List<PerformaInvoiceViewModel> fData = new List<PerformaInvoiceViewModel>();
            //fData = (from pi in piData
            //        select new PerformaInvoiceViewModel()
            //        {
            //            Id = pi.Id,
            //            IdFile = pi.IdFile,
            //            ItemCode = pi.ItemCode.ToString(), //must convert to ItemCode
            //            InvoiceNo = pi.InvoiceNo,
            //            VendorCode = pi.VendorCode,
            //            HSCode = pi.HSCode,
            //            Description = pi.Description,
            //            Quantity = pi.Quantity,
            //            TotalCBM = pi.TotalCBM,
            //            UnitPrice = pi.UnitPrice,
            //            InvoiceDate = pi.InvoiceDate,
            //            UploadedPIImage = pi.UploadedPIImage,
            //            ImagePIPath = pi.ImagePIPath,
            //            PIPath = pi.PIPath,
            //            InputDate = pi.InputDate,
            //            InputBy = pi.InputBy,
            //            IsActive = pi.IsActive
            //        }).ToList();
            //return fData;
        }

        //Get PO for Download
        public string GetPODetail(string DocNo)
        {
            string poPath = "";
            var poData = repoPO.GetPOHeaderByDocNo(DocNo);
            foreach (var item in poData)
            {
                poPath = item.POPath;
            }

            return poPath;
        }        

        //Create method for new File
        public ImportViewModel GetCreateEdit()
        {
            ImportViewModel viewModel = new ImportViewModel();
            return viewModel;
        }

        //Edit method for edited File
        public ImportViewModel GetCreateEdit(string DocNo)
        {
            var tr = repository.GetFileByDocNo(DocNo);
            ImportViewModel viewModel = new ImportViewModel();

            viewModel.SuggestDocNo = tr.SuggestDocNo;
            viewModel.FileName = tr.FileName;
            viewModel.FileType = tr.FileType;
            viewModel.FilePath = tr.FilePath;
            viewModel.Extension = tr.Extension;
            viewModel.Size = tr.Size;
            viewModel.Category = tr.Category;
            viewModel.Vendor = tr.VendorNo;
            viewModel.SuggestDocStatus = tr.SuggestDocStatus;
            viewModel.AuditActivity = Convert.ToChar(tr.AuditActivity);
            viewModel.AuditDateTime = tr.AuditDateTime;
            viewModel.AuditUsername = tr.AuditUsername;
            viewModel.IsActive = tr.IsActive;

            return viewModel;
        }

        //Get files name method for submit to Finance
        public List<string> GetFilesName(string[] listFile)
        {
            List<string> filesName = new List<string>();
            try
            {
                //Get file name by ID
                foreach (string item in listFile)
                {
                    var fileData = repository.GetFileByDocNo(item);
                    filesName.Add(fileData.FileName);
                }
                
            }
            catch (Exception error)
            {
                throw error;
            }
            return filesName;
        }

        //Submit to Finance process
        public ProcessResult SubmitToFinance(string[] listFile, string flag, string userLogon)
        {
            try
            {
                //Get file data by ID
                foreach (string item in listFile)
                {
                    UpdateFile(item, flag, userLogon);
                }

                result.UpdateSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Receive from Finance process
        public ProcessResult ReceiveFromFinance(string[] listFile, string flag, string userLogon)
        {
            try
            {
                //Get file data by ID
                foreach (string item in listFile)
                {
                    UpdateFile(item, flag, userLogon);
                }

                result.UpdateSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Payment later process
        public ProcessResult PayLater(string[] listFile, string flag, string userLogon)
        {
            try
            {
                //Separate the selected Payment and update to PO details
                //string Pay = listFile[listFile.Length - 1];
                //int idPay = Convert.ToInt32( Pay.Substring(Pay.IndexOf('-') + 1) );

                //Get file data by ID
                foreach (var item in listFile)
                {
                    var dataFile = repository.GetFileByDocNo(item);
                    if (dataFile.SuggestDocStatus == SuggestDocStatus.ApprovedbyMD)
                    {
                        //repoPO.UpdatePOTermofPayment(Convert.ToInt64(listFile[i]), idPay);
                        UpdateFile(item, flag, userLogon);
                        result.UpdateSucceed();
                    }
                    else
                    {
                        result.ProcessFailed("Cannot Set the status to Payment Later, only Approved File accepted");
                        break;
                    }
                }
                
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Update method for File
        public ProcessResult UpdateFile(string DocNo, string flag, string userLogon)
        {
            try
            {
                var dataFile = repository.GetFileByDocNo(DocNo);

                //Save to Hist per change status
                repository.MoveToHist(DocNo);

                //Update file status
                if (dataFile != null && (flag == "4" || flag == "5" || flag == "7"))
                {
                    repository.UpdateFile(dataFile, flag, userLogon);
                }

            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new File
        public ProcessResult SaveFile(ImportViewModel model, string fFlag, string userLogin)
        {
            var cekFile = repository.GetFileByDocNo(model.SuggestDocNo);
            var po = repoPO.GetPOHeaderByDocNo(model.SuggestDocNo).ToList();

            try
            {
                if (cekFile == null && fFlag == "0")
                {
                    //DataTable dataImport = Converter.ExcelToDataTable(fPath, fExt, TABLE_NAME_PROPERTY);
                    //List<SuggestDetailViewModel> listData = Converter.ForecastData(dataImport);

                    ////insert file to DB binary
                    //repository.InsertFile(model, fName, fExt, fSize, fPath, userLogin);
                    ////insert forecast result
                    ////repoImport.InsertFileForecast(listData, model.Category, model.Vendor, fName);
                    //result.InsertSucceed();
                }
                else if (cekFile != null && fFlag == "2")
                {
                    //bool flagPayment = false;
                    //foreach (var item in po)
                    //{
                    //    if (item.EstimationDate != null && item.EstimationArrival != null && item.SPPBNo != null && item.SPPBNo != "")
                    //    {
                    //        flagPayment = true;
                    //    }
                    //    else
                    //    {
                    //        flagPayment = false;
                    //    }
                    //}

                    //if (flagPayment == true)
                    //{
                        //save to hist per change status
                        repository.MoveToHist(model.SuggestDocNo);
                        //update status
                        repository.UpdateFile(cekFile, fFlag, userLogin);
                        result.UpdateSucceed();
                    //}
                    //else
                    //{
                    //    result.ProcessFailed("Please re-check the Payment Info (ETD, ETA, SPPB)!!");
                    //}
                    
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Revise PI and PO
        public ProcessResult GetRevise(string DocNo, string flag, string userLogin)
        {
            try
            {
                var tr = repository.GetFileByDocNo(DocNo);

                //save to Hist per change status
                repository.MoveToHist(DocNo);

                //update file PI data
                repoPI.ClearPI(tr.SuggestDocNo);
                //update file PO data
                repoPO.ClearPO(tr.SuggestDocNo);

                //reset status
                repository.UpdateFile(tr, flag, userLogin);

                result.UpdateSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Write forecast calculate in to File
        public ProcessResult WriteFile(string fName, string fPath)
        {
            var dataFile = repository.GetFile(fName);

            //Get all data to write          
            var dataImport = repository.AllImportByDocNo(dataFile.SuggestDocNo).ToList();

            DataTable dtImport = new DataTable();
            dtImport.TableName = TABLE_NAME_PROPERTY;

            dtImport.Columns.Add("Site Code");
            dtImport.Columns.Add("Site Name");
            dtImport.Columns.Add("Item Category");
            dtImport.Columns.Add("Vendor No");
            dtImport.Columns.Add("Vendor Name");
            dtImport.Columns.Add("Item MasterBrand");
            dtImport.Columns.Add("Item No");
            dtImport.Columns.Add("Item Name");
            dtImport.Columns.Add("System Suggested Quantity");
            dtImport.Columns.Add("Average Sales");
            dtImport.Columns.Add("Lead Time");
            dtImport.Columns.Add("Highest Avg Lead Time Actual");
            dtImport.Columns.Add("Safety Stock Days");
            dtImport.Columns.Add("Order Period");
            dtImport.Columns.Add("Minimum Stock");
            dtImport.Columns.Add("Maximum Stock");
            dtImport.Columns.Add("Reorder Point");
            dtImport.Columns.Add("Optimum Max");
            dtImport.Columns.Add("Optimum Max Multiple");
            dtImport.Columns.Add("Stock On Hand");
            dtImport.Columns.Add("Outstanding PO");
            dtImport.Columns.Add("Outstanding TR");
            dtImport.Columns.Add("Outstanding TO");
            dtImport.Columns.Add("Multiple Purchase Qty");
            dtImport.Columns.Add("Outstanding TR from other Store");

            for (int i = 0; i < dataImport.Count(); i++)
            {
                dtImport.Rows.Add(new object[] { dataImport[i].SiteNo, dataImport[i].SiteName, dataImport[i].Category,
                        dataImport[i].VendorNo, dataImport[i].VendorName, dataImport[i].MasterBrand, dataImport[i].ItemNo,
                        dataImport[i].mt_Item.ItemName, dataImport[i].SystemSuggestQty, dataImport[i].AverageSales, dataImport[i].LeadTime,
                        dataImport[i].HighestAvgLeadTimeActual, dataImport[i].SafetyStockDays, dataImport[i].OrderPeriod, dataImport[i].MinimumStock,
                        dataImport[i].MaximumStock, dataImport[i].ReorderPoint, dataImport[i].OptimumMax, dataImport[i].OptimumMaxMultiple,
                        dataImport[i].StockOnHand, dataImport[i].OutstandingPO, dataImport[i].OutstandingTR, dataImport[i].OutstandingTO,
                        dataImport[i].MultiplePurchaseQty, dataImport[i].OutstandingTRfromOtherStore});
            }
            dtImport.AcceptChanges();

            result = Excel.ExcelWriter(dtImport, fPath, dataFile.Extension);

            return result;
        }

        //Generate PDF for Import PO download
        public ProcessResult GeneratePDF(string fPath, string docNo, string userLogin)
        {
            try
            {
                //Get all data to write
                var dataPO = repoPO.GetPODetailsByDocNo(docNo).ToList();
                var feePO = repoPO.GetPOFeeById(dataPO[0].PurchaseOrderNo);

                //Get Notes from Remarks data
                //var remarks = repository.GetRemarksForIM(idFile, userLogin);

                //Mapping Data PO to DataTable
                DataTable dtPO = new DataTable();
                dtPO.TableName = TABLE_NAME_PROPERTY;

                //Header
                dtPO.Columns.Add("To");
                dtPO.Columns.Add("Deliver To");
                dtPO.Columns.Add("PO Date");
                dtPO.Columns.Add("No.PO");

                //Items
                dtPO.Columns.Add("No.");
                dtPO.Columns.Add("Item Code");
                dtPO.Columns.Add("LV");
                dtPO.Columns.Add("Item Name");
                dtPO.Columns.Add("UOM");
                dtPO.Columns.Add("Qty Order");
                dtPO.Columns.Add("Unit Price");
                dtPO.Columns.Add("EXTRA");
                dtPO.Columns.Add("Disc. (%)");
                dtPO.Columns.Add("Total");

                //Fee
                dtPO.Columns.Add("Import Duty");
                dtPO.Columns.Add("Custom Clearance Fee");
                dtPO.Columns.Add("THC");
                dtPO.Columns.Add("Trucking Fee");
                dtPO.Columns.Add("Open LC Fee");
                dtPO.Columns.Add("Telex Open LC Fee");
                dtPO.Columns.Add("Biaya Akseptasi");
                dtPO.Columns.Add("Biaya TT Bank");
                dtPO.Columns.Add("Insurance Cost");
                dtPO.Columns.Add("Adm Insurance");
                dtPO.Columns.Add("LSS COST");
                dtPO.Columns.Add("Correction for Item NON PPN 10%");

                //Footer
                dtPO.Columns.Add("Term of Payment");
                dtPO.Columns.Add("Lead Time Delivery Deadline");
                dtPO.Columns.Add("Expired PO Date");
                dtPO.Columns.Add("Created By");
                dtPO.Columns.Add("Approved By");

                for (int i = 0; i < dataPO.Count(); i++)
                {
                    //Get User login and approval
                    var user = repoUser.GetUserByUserID(userLogin);

                    dtPO.Rows.Add(new object[] {dataPO[i].tr_PurchaseOrderHeader.VendorNo, dataPO[i].tr_PurchaseOrderHeader.SiteNo, 
                                                dataPO[i].tr_PurchaseOrderHeader.PurchaseOrderDate, dataPO[i].tr_PurchaseOrderHeader.PurchaseOrderNo,
                                                (i+1), dataPO[i].ItemNo, dataPO[i].LV, dataPO[i].mt_Item.ItemName, dataPO[i].UOM,
                                                dataPO[i].QuantityOrder, dataPO[i].UnitPrice, dataPO[i].Extra, dataPO[i].Discount, dataPO[i].Total,
                                                //feePO.ImportDuty, feePO.CustomClearanceFee, feePO.THC, feePO.TruckingFee, 
                                                //feePO.OpenLCFee, feePO.TelexOpenLCFee, feePO.BiayaAkseptasi, feePO.BiayaTTBank, feePO.InsuranceCost,
                                                //feePO.AdmInsurance, feePO.LSSCOST, feePO.CORRNONP,
                                                dataPO[i].tr_PurchaseOrderHeader.TermOfPayment, dataPO[i].tr_PurchaseOrderHeader.LeadTimeDeliveryExpire, 
                                                dataPO[i].tr_PurchaseOrderHeader.PODateExpire, user.Username, "" });
                }
                dtPO.AcceptChanges();

                //Create PDF Format
                PDFGenerator.PurchaseOrder(fPath, dtPO, dataPO[0].PurchaseOrderNo);
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        #region DropDown
        //-- Helper Method -----------------------------------------------------------------
        //Get data for Status drop down list
        public IEnumerable<SelectListItem> GetListStatus()
        {
            var ListStatus = from stat in repoStatus.GetStatusForImport()
                             select new SelectListItem()
                             {
                                 Value = stat.SuggestDocStatus,
                                 Text = stat.SuggestDocStatus
                             };
            return ListStatus;
        }

        //Get data for Supplier drop down list
        public IEnumerable<SelectListItem> GetListVendor()
        {
            var ListSupplier = from vdr in repoVendor.AllVendor()
                               select new SelectListItem()
                               {
                                   Value = vdr.VendorNo,
                                   Text = vdr.VendorNo + " - " + vdr.VendorName
                               };
            return ListSupplier;
        }

        //Get data for Category drop down list
        public IEnumerable<SelectListItem> GetListCategory()
        {
            var ListCategory = from cat in repoCategory.AllCategory()
                               select new SelectListItem()
                               {
                                   Value = cat.Category,
                                   Text = cat.Category
                               };
            return ListCategory;
        }

        //Get data for Item Autocomplete drop down list
        public IEnumerable<SelectListItem> GetListItem(string term)
        {
            var ListItem = from item in repoItem.AllItem()
                           where item.ItemNo.ToLower().Contains(term.ToLower()) || item.ItemName.ToLower().Contains(term.ToLower())
                           select new SelectListItem()
                           {
                               Value = item.ItemNo,
                               Text = item.ItemNo + " - " + item.ItemName
                           };
            return ListItem;
        }

        //Get data for Suggest File drop down list
        public IEnumerable<SelectListItem> GetListSuggest()
        {
            var ListCategory = from file in repository.AllFiles()
                               select new SelectListItem()
                               {
                                   Value = file.SuggestDocNo,
                                   Text = file.SuggestDocNo + " - " + file.FileName
                               };
            return ListCategory;
        }

        //Get data for Payment drop down list
        public IEnumerable<SelectListItem> GetListPayment()
        {
            var ListPayment = from pay in repoPayment.AllPaymentType()
                               select new SelectListItem()
                               {
                                   Value = pay.PaymentTypeNo,
                                   Text = pay.PaymentTypeNo
                               };
            return ListPayment;
        }
        #endregion
    }
}
