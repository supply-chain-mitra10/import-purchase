﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.Imports;
using ViewModels.ProformaInvoices;
using ViewModels.PurchaseOrders;
using ViewModels.ProcessResult;
using ViewModels.Remarkss;
using Providers.Helper;
using ViewModels.Commons;
using System.Xml.Linq;

namespace Providers.Imports
{
    public class ImportRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all File from DB
        public IEnumerable<tr_SuggestHeader> AllFiles()
        {
            return entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.mt_SuggestDocStatus.Department.Contains("IM"));
        }
        //Get all File Items detail from DB
        public IEnumerable<tr_SuggestDetails> AllItems()
        {
            return entities.tr_SuggestDetails.Where(m => m.IsActive == true);
        }
        public IEnumerable<tr_SuggestDetails> AllItemsNoFilter()
        {
            return entities.tr_SuggestDetails;
        }
        public IEnumerable<tr_SuggestDetails> AllItemsByHeader(string docNo)
        {
            return entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == docNo);
        }
        public IEnumerable<tr_SuggestDetails> AllItemsByIdFile(string docNo)
        {
            return entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == docNo && m.IsActive == true);

        }
        //Get selected File Item from DB
        public tr_SuggestDetails GetItemByIdItem(string docNo, string itemNo)
        {
            return entities.tr_SuggestDetails.SingleOrDefault(m => m.SuggestDocNo == docNo && m.ItemNo == itemNo);
        }

        //Get selected File
        public tr_SuggestHeader GetFile(string docNo)
        {
            return entities.tr_SuggestHeader.SingleOrDefault(m => m.FileName == docNo);
        }
        public tr_SuggestHeader GetFileByDocNo(string docNo)
        {
            return entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == docNo);
        }

        //Delete using Json
        public int GetDeleteFile(string docNo)
        {
            return entities.tr_SuggestHeader.Where(m => m.SuggestDocNo == docNo && m.IsActive == true).Count();
        }

        //Insert new File
        //public void InsertFile(ImportViewModel model, string fname, string fext, long fsize, string fpath, string userLogon)
        //{
        //    string ftype = Converter.GetFileTypeByExtension(fext);
        //    //byte[] fcontent = Converter.GetByteFromFile(fpath);

        //    //get latest ID for auto generate
        //    var latestID = entities.tr_SuggestHeader.OrderByDescending(m => m.SuggestDocNo).FirstOrDefault();
        //    int counterID = Convert.ToInt32(latestID.SuggestDocNo.Substring(4, 6)) + 1; //e.q.SG22000001

        //    //get ID for Dropdownlist selected value
        //    //var categoryID = entities.mt_Category.SingleOrDefault(m => m.Type == model.Category);
        //    //var vendorID = entities.mt_Vendor.SingleOrDefault(m => m.Name == model.Vendor);

        //    try
        //    {
        //        var insertFile = new tr_SuggestHeader()
        //        {
        //            SuggestDocNo = string.Concat("RV-IC", counterID.ToString().PadLeft(5, '0')), //random dulu
        //            FileName = fname,
        //            FileType = ftype,
        //            FilePath = fpath,
        //            Extension = fext,
        //            Size = fsize,
        //            Category = categoryID.Id,
        //            Vendor = vendorID.Id,
        //            Status = 6, //6 = Revise
        //            CreatedDate = DateTime.Now,
        //            CreatedBy = userLogon,
        //            UploadDate = DateTime.Now,
        //            UploadBy = userLogon,
        //            UpdatedDate = null,
        //            UpdatedBy = "",
        //            ConfirmByIC = false,
        //            CloseByMD = false,
        //            ApproveByIC = false,
        //            ApproveByMD = false,
        //            RejectByIC = false,
        //            RejectByMD = false,
        //            Release = false,
        //            SubmitToFin = false,
        //            ReturnFromFin = false,
        //            GoodsReceived = false,
        //            ConfirmDate = null,
        //            ConfirmBy = "",
        //            CloseDate = null,
        //            CloseBy = "",
        //            ApprovedICDate = null,
        //            ApprovedICBy = "",
        //            ApprovedMDDate = null,
        //            ApprovedMDBy = "",
        //            RejectDate = null,
        //            RejectBy = "",
        //            ReviseDate = null,
        //            ReviseBy = "",
        //            ReleaseDate = null,
        //            ReleaseBy = "",
        //            SubmitDate = null,
        //            SubmitBy = "",
        //            ReturnDate = null,
        //            ReturnBy = "",
        //            ReceivedDate = null,
        //            ReceivedBy = "",
        //            IsActive = true
        //        };
        //        entities.tr_SuggestHeader.Add(insertFile);
        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}


        //-----------------------------------------------------------------
        //Get all Import from DB
        //public IEnumerable<tr_Import> AllImport()
        //{
        //    return entities.tr_Import.Where(m => m.IsActive == true);
        //}
        public IEnumerable<tr_SuggestDetails> AllImportByDocNo(string docNo)
        {
            return entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == docNo).ToList();
        }
        public IEnumerable<tr_SuggestDetails> AllImportByIDFileQuotation(string docNo)
        {
            return entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == docNo && m.CalculatedSuggest != 0).ToList();
        }
        public tr_SuggestDetails GetImportByIDFile(string docNo)
        {
            return entities.tr_SuggestDetails.SingleOrDefault(m => m.SuggestDocNo == docNo && m.IsActive == true);
        }

        //Insert new File for Forecast Result
        public void InsertFileForecast(List<SuggestDetailViewModel> model, string fname, string userLogon)
        {
            try
            {
                //Suggest Document
                var suggestDoc = entities.tr_SuggestHeader.SingleOrDefault(m => m.FileName == fname);
                string suggestDocNo = suggestDoc.SuggestDocNo;
                int IC_TotalQty = 0;
                decimal IC_QtyCBM = 0;
                decimal IC_TotalCBM = 0;
                decimal cmToMeter = 1000000;

                for (int i = 0; i < model.Count(); i++)
                {
                    //Item ID
                    string itmNo = model[i].ItemNo.Trim();
                    var itm = entities.mt_Item.SingleOrDefault(m => m.ItemNo == itmNo);

                    //Calculate first
                    var SuggestRaw = ((((model[i].MaximumStock == null) ? 0 : model[i].MaximumStock) -
                                        ((model[i].StockOnHand == null) ? 0 : model[i].StockOnHand) -
                                        ((model[i].OutstandingPO == null) ? 0 : model[i].OutstandingPO) -
                                        ((model[i].OutstandingTR == null) ? 0 : model[i].OutstandingTR) -
                                        ((model[i].OutstandingTO == null) ? 0 : model[i].OutstandingTO) +
                                        ((model[i].OutstandingTRfromOtherStore == null) ? 0 : model[i].OutstandingTRfromOtherStore)) <= 0) ? 0:
                                        (((model[i].MaximumStock == null) ? 0 : model[i].MaximumStock) -
                                        ((model[i].StockOnHand == null) ? 0 : model[i].StockOnHand) -
                                        ((model[i].OutstandingPO == null) ? 0 : model[i].OutstandingPO) -
                                        ((model[i].OutstandingTR == null) ? 0 : model[i].OutstandingTR) -
                                        ((model[i].OutstandingTO == null) ? 0 : model[i].OutstandingTO) +
                                        ((model[i].OutstandingTRfromOtherStore == null) ? 0 : model[i].OutstandingTRfromOtherStore)) ;
                    var StockDays = (SuggestRaw == 0) ? 0 : ((model[i].AverageSales == 0) ? 0 : (SuggestRaw / model[i].AverageSales));
                    var StockDaysSuggestOTSSOH = (model[i].AverageSales == 0)? 0 : ( (((model[i].StockOnHand == null) ? 0 : model[i].StockOnHand) +
                                        ((model[i].OutstandingPO == null) ? 0 : model[i].OutstandingPO) -
                                        ((model[i].OutstandingTR == null) ? 0 : model[i].OutstandingTR) -
                                        ((model[i].OutstandingTO == null) ? 0 : model[i].OutstandingTO) -
                                        ((model[i].OutstandingTRfromOtherStore == null) ? 0 : model[i].OutstandingTRfromOtherStore) +
                                        //StockDays;
                                        SuggestRaw)/ model[i].AverageSales );

                    //masih perlu perhitungannya dl :
                    //IC_TotalQty = Convert.ToInt32(IC_TotalQty + SuggestRaw);
                    //IC_TotalCBM = (IC_TotalQty == 0) ? 0 : Convert.ToDecimal((Convert.ToDecimal(itm.Height * itm.Width * itm.Length) * IC_TotalQty) / Convert.ToDecimal(1000000));
                    IC_TotalQty = Convert.ToInt32(IC_TotalQty + SuggestRaw);
                    IC_QtyCBM = (SuggestRaw == 0) ? 0 : Convert.ToDecimal((Convert.ToDecimal(itm.Height * itm.Width * itm.Length) * SuggestRaw) / cmToMeter);
                    IC_TotalCBM = IC_TotalCBM + IC_QtyCBM;


                    var insertFile = new tr_SuggestDetails()
                    {
                        SuggestDocNo = suggestDocNo,
                        SiteNo = model[i].SiteNo,
                        SiteName = model[i].SiteName,
                        Category = model[i].Category,
                        VendorNo = model[i].VendorNo,
                        VendorName = model[i].VendorName,
                        MasterBrand = model[i].MasterBrand,
                        ItemNo = model[i].ItemNo,
                        ItemName = model[i].ItemName,
                        SystemSuggestQty = (model[i].SystemSuggestQty == null) ? 0 : model[i].SystemSuggestQty,
                        AverageSales = (model[i].AverageSales == null) ? 0 : model[i].AverageSales,
                        LeadTime = (model[i].LeadTime == null) ? 0 : model[i].LeadTime,
                        HighestAvgLeadTimeActual = (model[i].HighestAvgLeadTimeActual == null) ? 0 : model[i].HighestAvgLeadTimeActual,
                        SafetyStockDays = (model[i].SafetyStockDays == null) ? 0 : model[i].SafetyStockDays,
                        OrderPeriod = (model[i].OrderPeriod == null) ? 0 : model[i].OrderPeriod,
                        MinimumStock = ((model[i].MinimumStock == null) ? 0 : model[i].MinimumStock),
                        MaximumStock = (model[i].MaximumStock == null) ? 0 : model[i].MaximumStock,
                        ReorderPoint = (model[i].ReorderPoint == null) ? 0 : model[i].ReorderPoint,
                        OptimumMax = (model[i].OptimumMax == null) ? 0 : model[i].OptimumMax,
                        OptimumMaxMultiple = (model[i].OptimumMaxMultiple == null) ? 0 : model[i].OptimumMaxMultiple,
                        StockOnHand = (model[i].StockOnHand == null) ? 0 : model[i].StockOnHand,
                        OutstandingPO = (model[i].OutstandingPO == null) ? 0 : model[i].OutstandingPO,
                        OutstandingTR = (model[i].OutstandingTR == null) ? 0 : model[i].OutstandingTR,
                        OutstandingTO = (model[i].OutstandingTO == null) ? 0 : model[i].OutstandingTO,
                        MultiplePurchaseQty = (model[i].MultiplePurchaseQty == null) ? 0 : model[i].MultiplePurchaseQty,
                        OutstandingTRfromOtherStore = (model[i].OutstandingTRfromOtherStore == null) ? 0 : model[i].OutstandingTRfromOtherStore,

                        CalculatedSuggest = SuggestRaw,
                        CalculatedStockDaysSuggest = StockDays,
                        CalculatedTotalStockDays = StockDaysSuggestOTSSOH,
                        ReviseMDSuggest = 0,
                        ReviseMDStockDaysSuggest = 0,
                        ReviseMDTotalStockDays = 0,

                        ICSuggest_TotalQty = IC_TotalQty,
                        ICSuggest_QtyCBM = IC_QtyCBM,
                        ICSuggest_TotalCBM = IC_TotalCBM,

                        AuditActivity = AuditActivity.Insert,
                        AuditDateTime = DateTime.Now,
                        AuditUsername = userLogon,
                        IsActive = true
                    };
                    entities.tr_SuggestDetails.Add(insertFile);
                }
                entities.SaveChanges();

            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen File
        public void UpdateFile(tr_SuggestHeader model, string flag, string userLogon)
        {
            try
            {
                string fname = model.FileName;
                string fext = model.Extension;
                var updateData = entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == model.SuggestDocNo);
                var updateDetail = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == model.SuggestDocNo).ToList();

                if (flag == "2")
                {
                    updateData.SuggestDocStatus = SuggestDocStatus.Release;
                    //updateData.Release = true;
                    //updateData.ReleaseDate = DateTime.Now;
                    //updateData.ReleaseBy = userLogon;
                }
                else if (flag == "3")
                {
                    //Update Header File
                    if (!fname.Contains("_REVISE"))
                    {
                        updateData.FileName = fname.Substring(0, fname.IndexOf('.')) + "_REVISE" + fext;
                    }
                    updateData.SuggestDocStatus = SuggestDocStatus.Revise;
                    //updateData.ApproveByMD = false;
                    //updateData.ApprovedMDDate = null;
                    //updateData.ApprovedMDBy = null;
                    //updateData.ReviseDate = DateTime.Now;
                    //updateData.ReviseBy = userLogon;

                    //Update Detail File
                    //foreach (var item in updateDetail)
                    //{
                    //    item.PINumber = "";
                    //    item.PONumber = "";
                    //}
                }
                else if (flag == "4")
                {
                    updateData.SuggestDocStatus = SuggestDocStatus.SubmittoFinance;                         //10=Submit to Finance
                    //updateData.SubmitToFin = true;
                    //updateData.SubmitDate = DateTime.Now;
                    //updateData.SubmitBy = userLogon;
                }
                else if (flag == "5")
                {
                    updateData.SuggestDocStatus = SuggestDocStatus.ReceivefromFinance;                         //11=Receive from Finance
                    //updateData.ReturnFromFin = true;
                    //updateData.ReturnDate = DateTime.Now;
                    //updateData.ReturnBy = userLogon;
                }
                else if (flag == "7")
                {
                    updateData.SuggestDocStatus = SuggestDocStatus.PaymentLC;                         //14=Payment LC
                    //updateData.UpdatedDate = DateTime.Now;
                    //updateData.UpdatedBy = userLogon;
                }

                updateData.IsActive = true;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen Import
        public void UpdateImport(SuggestDetailViewModel model)
        {
            try
            {
                var updateData = entities.tr_SuggestDetails.SingleOrDefault(m => m.SuggestDocNo == model.SuggestDocNo);
                updateData.SiteNo = model.SiteNo;
                updateData.SiteName = model.SiteName;
                updateData.Category = model.Category; 
                updateData.VendorNo = model.VendorNo; 
                updateData.VendorName = model.VendorName;
                updateData.MasterBrand = model.MasterBrand;
                updateData.ItemNo = model.ItemNo;
                updateData.ItemName = model.ItemName;
                updateData.SystemSuggestQty = model.SystemSuggestQty;
                updateData.AverageSales = model.AverageSales;
                updateData.LeadTime = model.LeadTime;
                updateData.HighestAvgLeadTimeActual = model.HighestAvgLeadTimeActual;
                updateData.SafetyStockDays = model.SafetyStockDays;
                updateData.OrderPeriod = model.OrderPeriod;
                updateData.MinimumStock = model.MinimumStock;
                updateData.MaximumStock = model.MaximumStock;
                updateData.ReorderPoint = model.ReorderPoint;
                updateData.OptimumMax = model.OptimumMax;
                updateData.OptimumMaxMultiple = model.OptimumMaxMultiple;
                updateData.StockOnHand = model.StockOnHand;
                updateData.OutstandingPO = model.MinimumStock;
                updateData.OutstandingTR = model.MaximumStock;
                updateData.OutstandingTO = model.ReorderPoint;
                updateData.MultiplePurchaseQty = model.OptimumMax;
                updateData.OutstandingTRfromOtherStore = model.OptimumMaxMultiple;
                //updateData.PINumber = model.PINumber;
                //updateData.PONumber = model.PONumber;
                updateData.IsActive = model.IsActive;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen item PI NUmber (by Upload)
        public void UpdatePIPerItem(List<CreateEditProformaInvoiceViewModel> pi, string DocNo)
        {
            try
            {
                for (int i = 0; i < pi.Count; i++)
                {
                    //string itm = pi[i].ItemCode.ToString();
                    var itemData = entities.mt_Item.SingleOrDefault(m => m.ItemNo == pi[i].ItemNo);
                    //long idItem = itemData.Id;
                    var updateData = entities.tr_SuggestDetails.SingleOrDefault(m => m.ItemNo == pi[i].ItemNo);
                    //updateData.PINumber = pi[i].InvoiceNo;
                }
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen item PI NUmber (manual Input)
        //public void UpdatePIPerItem(CreateEditPerformaInvoiceViewModel pi)
        //{
        //    try
        //    {
        //        long itm = pi.ItemCode;
        //        //var itemData = entities.mt_Item.SingleOrDefault(m => m.ItemCode == itm);
        //        //long idItem = itemData.Id;
        //        var updateData = entities.tr_SuggestDetails.SingleOrDefault(m => m.ItemCode == itm);
        //        updateData.PINumber = pi.InvoiceNo;

        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        //Update choosen item PO NUmber
        public void UpdatePOPerItem(List<CreateEditPurchaseOrderViewModel> po, long idFile)
        {
            try
            {
                for (int i = 0; i < po.Count; i++)
                {
                    //string itm = po[i].ItemCode.ToString();
                    var itemData = entities.mt_Item.SingleOrDefault(m => m.ItemNo == po[i].ItemNo);
                    //long idItem = itemData.Id;
                    var updateData = entities.tr_SuggestDetails.SingleOrDefault(m => m.ItemNo == po[i].ItemNo);
                    //updateData.PONumber = po[i].PONumber;
                }
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }        

        //Update Item Revised (File Upload)
        public void UpdateReviseItem(List<SuggestDetailViewModel> model, string category, string vendor, string fname, string fext)
        {
            try
            {
                int catID = Convert.ToInt32(category);
                string fNameRev = fname.Substring(0, fname.IndexOf('.')) + "_REVISE" + fext;

                int MD_TotalQty = 0;
                decimal MD_TotalCBM = 0;
                //decimal TruckWeight = 12000;

                //Calculate total Qty and CBM Revise
                //MD_TotalQty = model.Sum(m => m.QtyRevise).Value;
                //MD_TotalCBM = Convert.ToDecimal(TruckWeight / model.Sum(m => m.QtyRevise).Value);

                for (int i = 1; i <= model.Count; i++)
                {
                    //int vdrID = Convert.ToInt32(vendor);
                    //string itmCode = model[i].ItemNo.Trim();
                    //var itm = entities.mt_Item.SingleOrDefault(m => m.ItemCode == itmCode);
                    //var vdr = entities.mt_Vendor.SingleOrDefault(m => m.Id == vdrID);
                    //string vdrCode = vdr.Code;
                    //var mb = entities.mt_MasterBrand.SingleOrDefault(m => m.VendorID == vdrCode);
                    //var file = entities.tr_SuggestHeader.SingleOrDefault(m => m.FileName == fNameRev);
                    //long fileID = file.Id;

                    //long idImport = i + 1;
                    var updateData = entities.tr_SuggestDetails.SingleOrDefault(m => m.SuggestDocNo == model[i].SuggestDocNo);
                    //updateData.ItemCode = itm.Id;
                    //updateData.ItemName = model[i].ItemName;
                    //updateData.AverageUsed = model[i].AverageUsed;
                    //updateData.StockActualDC = model[i].StockActualDC;
                    //updateData.StockActualStore = model[i].StockActualStore;
                    //updateData.OutstandingPI = model[i].OutstandingPI;
                    //updateData.SuggestStoreNeeds = model[i].SuggestStoreNeeds;
                    //updateData.SuggestDCNeeds = model[i].SuggestDCNeeds;
                    ////updateData.SuggestTotal = model[i].SuggestTotal;
                    //updateData.QtyRevise = model[i].QtyRevise; //Kolom yg diupdate revise cth
                    //updateData.SDFirst = model[i].SDFirst;
                    //updateData.SDPOR = model[i].SDPOR;
                    //updateData.SDFinal = model[i].SDFinal;
                    //updateData.Category = catID;
                    //updateData.MasterBrand = mb.Id;
                    updateData.ReviseMDSuggest = model[i].ReviseMDSuggest;
                    updateData.ReviseMDStockDaysSuggest = model[i].ReviseMDStockDaysSuggest;
                    updateData.ReviseMDTotalStockDays = model[i].ReviseMDTotalStockDays;
                    updateData.MDRevise_TotalQty = MD_TotalQty;
                    updateData.MDRevise_TotalCBM = MD_TotalCBM;
                    updateData.IsActive = model[i].IsActive;
                }
                entities.SaveChanges();

            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update Item Revised (Form)
        public void UpdateReviseItemForm(SuggestDetailViewModel model)
        {
            try
            {
                //Save Update Revise
                var updateData = entities.tr_SuggestDetails.SingleOrDefault(m => m.SuggestDocNo == model.SuggestDocNo && m.ItemNo == model.ItemNo);
                updateData.TotalSuggest = model.ReviseMDSuggest;
                updateData.ReviseMDSuggest = model.ReviseMDSuggest;
                updateData.ReviseMDStockDaysSuggest = model.ReviseMDStockDaysSuggest;
                updateData.ReviseMDTotalStockDays = model.ReviseMDTotalStockDays;
                updateData.IsActive = model.IsActive;
                entities.SaveChanges();    
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //combine Suggest from IC and MD Revised
        public void FillTotalSuggest(SuggestDetailViewModel model)
        {
            var data = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == model.SuggestDocNo).ToList();

            foreach (var suggest in data)
            {
                if (suggest.TotalSuggest == null)
                {
                    suggest.TotalSuggest = suggest.CalculatedSuggest;
                }
            }
            entities.SaveChanges();
        }

        //Re-Calculate for Total Qty and CBM Revised
        public void CalculateTotalCBM(SuggestDetailViewModel model)
        {
            int MD_TotalQty = 0;
            decimal MD_QtyCBM = 0;
            decimal MD_TotalCBM = 0;
            decimal cmToMeter = 1000000;

            //Calculate total Qty and CBM Revise
            List<tr_SuggestDetails> listItems = new List<tr_SuggestDetails>();
            listItems = AllItemsByHeader(model.SuggestDocNo).ToList();

            MD_TotalQty = Convert.ToInt32(listItems.Sum(m => m.TotalSuggest).Value);
            foreach (var item in listItems)
            {
                //Item detail
                var itm = entities.mt_Item.SingleOrDefault(m => m.ItemNo == item.ItemNo);
                item.MDRevise_TotalQty = MD_TotalQty;
                MD_QtyCBM = (item.TotalSuggest == 0) ? 0 : Convert.ToDecimal((Convert.ToDecimal(itm.Height * itm.Width * itm.Length) * item.TotalSuggest) / cmToMeter);
                item.MDRevise_QtyCBM = MD_QtyCBM;
                MD_TotalCBM = MD_TotalCBM + MD_QtyCBM;
                item.MDRevise_TotalCBM = MD_TotalCBM;
            }

            //var updateTotal = entities.tr_SuggestDetails.SingleOrDefault(m => m.Id == model.Id);
            //var updateTotal = entities.tr_SuggestDetails.Where(m => m.IdHeader == model.IdHeader);
            //foreach (var data in updateTotal)
            //{
            //    data.MDRevise_TotalQty = MD_TotalQty;
            //    data.MDRevise_QtyCBM = MD_QtyCBM;
            //    data.MDRevise_TotalCBM = MD_TotalCBM;
            //}

            entities.SaveChanges();
        }

        //Delete choosen File
        public void DeleteFile(string DocNo)
        {
            try
            {
                var deleteFile = entities.tr_SuggestDetails.SingleOrDefault(m => m.SuggestDocNo == DocNo && m.IsActive == true);
                //entities.tr_SuggestDetails.Remove(deleteFile);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Close choosen File and Details to close
        public void CloseFile(string DocNo, string userLogon)
        {
            try
            {
                var delFileHeader = entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo && m.IsActive == true);
                var delFileDetail = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == DocNo && m.IsActive == true);

                delFileHeader.SuggestDocNo = SuggestDocStatus.Close;
                //delFileHeader.CloseByMD = true;
                //delFileHeader.CloseDate = DateTime.Now;
                //delFileHeader.CloseBy = userLogon;
                //delFileHeader.IsActive = false;
                //entities.tr_SuggestHeader.Remove(deleteFile);

                foreach (var item in delFileDetail)
                {
                    item.IsActive = false;
                }

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Move choosen File to History
        public void MoveToHist(string DocNo)
        {
            try
            {
                //Get latest sequence in History table
                int counterSeq = 0;
                var seq = entities.tr_SuggestHeader_Hist.OrderByDescending(m => m.Sequence).FirstOrDefault();
                if (seq != null)
                {
                    counterSeq = seq.Sequence + 1;
                }

                var mvFileHeader = entities.tr_SuggestHeader.SingleOrDefault(m => m.SuggestDocNo == DocNo && m.IsActive == true);
                var mvFileDetail = entities.tr_SuggestDetails.Where(m => m.SuggestDocNo == DocNo && m.IsActive == true);

                var moveFileHeader = new tr_SuggestHeader_Hist()
                {
                    SuggestDocNo = mvFileHeader.SuggestDocNo,
                    FileName = mvFileHeader.FileName,
                    FileType = mvFileHeader.FileType,
                    FilePath = mvFileHeader.FilePath,
                    Extension = mvFileHeader.Extension,
                    Size = mvFileHeader.Size,
                    Category = mvFileHeader.Category,
                    VendorNo = mvFileHeader.VendorNo,
                    SuggestDocStatus = mvFileHeader.SuggestDocStatus,
                    AuditActivity = mvFileHeader.AuditActivity,
                    AuditDateTime = mvFileHeader.AuditDateTime,
                    AuditUsername = mvFileHeader.AuditUsername,
                    TimeStamp = DateTime.Now,
                    Sequence = counterSeq,
                    IsActive = mvFileHeader.IsActive
                };

                List<tr_SuggestDetails_Hist> moveFileDetail = new List<tr_SuggestDetails_Hist>();
                foreach (var item in mvFileDetail)
                {
                    var importHist = new tr_SuggestDetails_Hist()
                    {
                        SuggestDocNo = item.SuggestDocNo,
                        SiteNo = item.SiteNo,
                        SiteName = item.SiteName,
                        VendorNo = item.VendorNo,
                        VendorName = item.VendorName,
                        MasterBrand = item.MasterBrand,
                        ItemNo = item.ItemNo,
                        ItemName = item.ItemName,
                        Category = item.Category,
                        SystemSuggestQty = item.SystemSuggestQty,
                        AverageSales = item.AverageSales,
                        LeadTime = item.LeadTime,
                        HighestAvgLeadTimeActual = item.HighestAvgLeadTimeActual,
                        SafetyStockDays = item.SafetyStockDays,
                        OrderPeriod = item.OrderPeriod,
                        MinimumStock = item.MinimumStock,
                        MaximumStock = item.MaximumStock,
                        ReorderPoint = item.ReorderPoint,
                        OptimumMax = item.OptimumMax,
                        OptimumMaxMultiple = item.OptimumMaxMultiple,
                        StockOnHand = item.StockOnHand,
                        OutstandingPO = item.OutstandingPO,
                        OutstandingTR = item.OutstandingTR,
                        OutstandingTO = item.OutstandingTO,
                        MultiplePurchaseQty = item.MultiplePurchaseQty,
                        OutstandingTRfromOtherStore = item.OutstandingTRfromOtherStore,
                        CalculatedSuggest = item.CalculatedSuggest,
                        CalculatedStockDaysSuggest = item.CalculatedStockDaysSuggest,
                        CalculatedTotalStockDays = item.CalculatedTotalStockDays,
                        ReviseMDSuggest = item.ReviseMDSuggest,
                        ReviseMDStockDaysSuggest = item.ReviseMDStockDaysSuggest,
                        ReviseMDTotalStockDays = item.ReviseMDTotalStockDays,
                        ICSuggest_TotalQty = item.ICSuggest_TotalQty,
                        ICSuggest_TotalCBM = item.ICSuggest_TotalCBM,
                        MDRevise_TotalQty = item.MDRevise_TotalQty,
                        MDRevise_TotalCBM = item.MDRevise_TotalCBM,
                        AuditActivity = item.AuditActivity,
                        AuditDateTime = item.AuditDateTime,
                        AuditUsername = item.AuditUsername,
                        TimeStamp = DateTime.Now,
                        Sequence = counterSeq,
                        IsActive = item.IsActive
                    };
                    moveFileDetail.Add(importHist);
                }

                entities.tr_SuggestHeader_Hist.Add(moveFileHeader);
                entities.tr_SuggestDetails_Hist.AddRange(moveFileDetail);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

    }
}
