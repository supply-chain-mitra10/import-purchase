﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.ProcessResult;

namespace Providers.Branchs
{
    public class BranchRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all Category from DB
        public IEnumerable<mt_Branch> AllBranch()
        {
            return entities.mt_Branch;
        }
    }
}
