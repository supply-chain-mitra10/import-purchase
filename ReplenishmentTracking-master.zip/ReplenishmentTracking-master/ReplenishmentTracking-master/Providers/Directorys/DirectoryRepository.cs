﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.Commons;
using ViewModels.Directorys;
using ViewModels.ProcessResult;

namespace Providers.Directorys
{
    public class DirectoryRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all Directory from DB
        public IEnumerable<mt_Directory> AllDirectory()
        {
            return entities.mt_Directory;
        }

        //Get selected Directory
        public mt_Directory GetDirectory(string DirectoryName)
        {
            return entities.mt_Directory.SingleOrDefault(m => m.DirectoryName == DirectoryName);
        }

        //Delete using Json
        public int GetDeleteDirectory(string DirectoryName)
        {
            return entities.mt_Directory.Where(m => m.DirectoryName == DirectoryName).Count();
        }

        //Insert new Directory
        public void InsertDirectory(CreateEditDirectoryViewModel model, string userLogon)
        {
            //get latest ID for auto generate
            var latestID = entities.mt_Directory.OrderByDescending(m => m.DirectoryName).FirstOrDefault();

            try
            {
                var insertDirectory = new mt_Directory()
                {
                    DirectoryName = model.DirectoryName,
                    DirectoryPath = model.DirectoryPath,
                    AuditActivity = AuditActivity.Insert,
                    AuditDateTime = DateTime.Now,
                    AuditUsername = userLogon,
                    IsActive = true
                };
                entities.mt_Directory.Add(insertDirectory);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen Directory
        public void UpdateDirectory(CreateEditDirectoryViewModel model, string userLogin)
        {
            try
            {
                var updateData = entities.mt_Directory.SingleOrDefault(m => m.DirectoryName == model.DirectoryName);
                updateData.DirectoryName = model.DirectoryName;
                updateData.DirectoryPath = model.DirectoryPath;
                updateData.AuditActivity = AuditActivity.Update;
                updateData.AuditDateTime = DateTime.Now;
                updateData.AuditUsername = userLogin;
                updateData.IsActive = model.IsActive;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Delete choosen Directory
        public void DeleteDirectory(string DirectoryName)
        {
            try
            {
                var deleteDirectory = entities.mt_Directory.SingleOrDefault(m => m.DirectoryName == DirectoryName);
                entities.mt_Directory.Remove(deleteDirectory);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
