﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.Directorys;
using ViewModels.ProcessResult;
using System.Configuration;

namespace Providers.Directorys
{
    public class DirectoryBussinessLogic
    {
        private DirectoryRepository repository = new DirectoryRepository();
        private ProcessResult result = new ProcessResult();

        //Get directory list to display
        public List<DirectoryViewModel> List(IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from dir in repository.AllDirectory()
                        where dir.DirectoryName.ToString().Contains(IdFilter == null ? "" : IdFilter.Value.ToString())
                        select new DirectoryViewModel()
                        {
                            DirectoryName = dir.DirectoryName,
                            DirectoryPath = dir.DirectoryPath,
                            AuditActivity = Convert.ToChar(dir.AuditActivity),
                            AuditDateTime = dir.AuditDateTime,
                            AuditUsername = dir.AuditUsername,
                            IsActive = dir.IsActive
                        };

            return query.ToList();
        }


        //Create method for new directory
        public CreateEditDirectoryViewModel GetCreateEdit()
        {
            CreateEditDirectoryViewModel viewModel = new CreateEditDirectoryViewModel();
            return viewModel;
        }

        //Edit method for edited directory
        public CreateEditDirectoryViewModel GetCreateEdit(string directoryNo)
        {
            var dir = repository.GetDirectory(directoryNo);
            CreateEditDirectoryViewModel viewModel = new CreateEditDirectoryViewModel();

            viewModel.DirectoryName = dir.DirectoryName;
            viewModel.DirectoryPath = dir.DirectoryPath;
            viewModel.AuditActivity = Convert.ToChar(dir.AuditActivity);
            viewModel.AuditDateTime = dir.AuditDateTime;
            viewModel.AuditUsername = dir.AuditUsername;
            viewModel.IsActive = dir.IsActive;

            return viewModel;
        }

        //Delete method for one directory
        public ProcessResult GetDelete(string directoryNo)
        {
            try
            {
                repository.DeleteDirectory(directoryNo);
                result.DeleteSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new directory
        public ProcessResult SaveDirectory(CreateEditDirectoryViewModel model, string userLogin)
        {
            try
            {
                if (model.DirectoryName == string.Empty || model.DirectoryName == "")
                {
                    repository.InsertDirectory(model, userLogin);
                    result.InsertSucceed();
                }
                else
                {
                    repository.UpdateDirectory(model, userLogin);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }
    }
}
