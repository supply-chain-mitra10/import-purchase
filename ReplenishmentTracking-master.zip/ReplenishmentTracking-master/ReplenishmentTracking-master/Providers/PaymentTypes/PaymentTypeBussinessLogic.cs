﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.PaymentTypes;
using ViewModels.ProcessResult;
using System.Configuration;

namespace Providers.PaymentTypes
{
    public class PaymentTypeBussinessLogic
    {
        private PaymentTypeRepository repository = new PaymentTypeRepository();
        private ProcessResult result = new ProcessResult();

        //Get payment list to display
        public List<PaymentTypeViewModel> List(IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from pt in repository.AllPaymentType()
                        where pt.PaymentTypeNo.ToString().Contains(IdFilter == null ? "" : IdFilter.Value.ToString())
                        select new PaymentTypeViewModel()
                        {
                            PaymentTypeNo = pt.PaymentTypeNo,
                            Description = pt.Description,
                            //DueDate = pt.DueDate,
                            //PaymentPart = pt.PaymentPart,
                            AuditActivity = pt.AuditActivity,
                            AuditDateTime = pt.AuditDateTime,
                            AuditUsername = pt.AuditUsername,
                            //IsActive = user.IsActive
                        };

            return query.ToList();
        }


        //Create method for new payment
        public CreateEditPaymentTypeViewModel GetCreateEdit()
        {
            CreateEditPaymentTypeViewModel viewModel = new CreateEditPaymentTypeViewModel();
            return viewModel;
        }

        //Edit method for edited payment
        public CreateEditPaymentTypeViewModel GetCreateEdit(string payTypeNo)
        {
            var user = repository.GetPaymentTypeByNo(payTypeNo);
            CreateEditPaymentTypeViewModel viewModel = new CreateEditPaymentTypeViewModel();

            viewModel.PaymentTypeNo = user.PaymentTypeNo;
            viewModel.Description = user.Description;
            viewModel.IsActive = user.IsActive;

            return viewModel;
        }

        //Delete method for one payment
        public ProcessResult GetDelete(string PayID)
        {
            try
            {
                repository.DeletePayment(PayID);
                result.DeleteSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new payment
        public ProcessResult SavePayment(CreateEditPaymentTypeViewModel model, string userLogin)
        {
            try
            {
                if (model.PaymentTypeNo == string.Empty || model.PaymentTypeNo == "")
                {
                    repository.InsertPaymentType(model, userLogin);
                    result.InsertSucceed();
                }
                else
                {
                    repository.UpdatePayment(model);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }
    }
}
