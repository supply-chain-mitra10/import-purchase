﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.PaymentTypes;
using ViewModels.ProcessResult;
using Providers.Helper;
using ViewModels.Commons;

namespace Providers.PaymentTypes
{
    public class PaymentTypeRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all Payment type
        public IEnumerable<mt_PaymentType> AllPaymentType()
        {
            return entities.mt_PaymentType;
        }

        //Get selected Payment type
        public mt_PaymentType GetPaymentTypeByNo(string PayTypeNo)
        {
            return entities.mt_PaymentType.SingleOrDefault(m => m.PaymentTypeNo == PayTypeNo);
        }

        //Delete Payment type using Json
        public int GetDeletePaymentTypeByNo(string PayTypeNo)
        {
            return entities.mt_PaymentType.Where(m => m.PaymentTypeNo == PayTypeNo).Count();
        }

        //Insert new Payment type
        public void InsertPaymentType(CreateEditPaymentTypeViewModel model, string userLogon)
        {
            try
            {
                var insertPay = new mt_PaymentType()
                {
                    PaymentTypeNo = model.PaymentTypeNo,
                    Description = model.Description,
                    DueDate = model.DueDate,
                    PaymentPart = model.PaymentPart,
                    AuditActivity = model.AuditActivity,
                    AuditDateTime = model.AuditDateTime,
                    AuditUsername = model.AuditUsername,
                    IsActive = true
                };
                entities.mt_PaymentType.Add(insertPay);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen Payment type
        public void UpdatePayment(CreateEditPaymentTypeViewModel model)
        {
            try
            {
                var updateData = entities.mt_PaymentType.SingleOrDefault(m => m.PaymentTypeNo == model.PaymentTypeNo);
                updateData.PaymentTypeNo = model.PaymentTypeNo;
                updateData.Description = model.Description;
                updateData.DueDate = model.DueDate;
                updateData.PaymentPart = model.PaymentPart;
                updateData.AuditActivity = AuditActivity.Update;
                updateData.AuditDateTime = DateTime.Now;
                updateData.AuditUsername = model.AuditUsername;
                updateData.IsActive = model.IsActive;

                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Delete choosen Payment
        public void DeletePayment(string PayTypeNo)
        {
            try
            {
                var deletePay = entities.mt_PaymentType.SingleOrDefault(m => m.PaymentTypeNo == PayTypeNo);
                entities.mt_PaymentType.Remove(deletePay);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
