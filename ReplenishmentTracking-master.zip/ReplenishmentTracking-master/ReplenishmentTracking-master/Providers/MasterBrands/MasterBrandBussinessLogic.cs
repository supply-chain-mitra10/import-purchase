﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.MasterBrands;
using ViewModels.ProcessResult;
using System.Configuration;

namespace Providers.MasterBrands
{
    public class MasterBrandBussinessLogic
    {
        private MasterBrandRepository repository = new MasterBrandRepository();
        private ProcessResult result = new ProcessResult();

        //Get MasterBrand list to display
        public List<MasterBrandViewModel> List(IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from mb in repository.AllMasterBrand()
                        where mb.MasterBrand.ToString().Contains(IdFilter == null ? "" : IdFilter.Value.ToString())
                        select new MasterBrandViewModel()
                        {
                            VendorNo = mb.VendorNo,
                            MasterBrand = mb.MasterBrand,
                            AuditActivity = Convert.ToChar(mb.AuditActivity),
                            AuditDateTime = mb.AuditDateTime,
                            AuditUsername = mb.AuditUsername,
                            IsActive = mb.IsActive
                        };

            return query.ToList();
        }

        ////Create method for new MasterBrand
        //public CreateEditMasterBrandViewModel GetCreateEdit()
        //{
        //    CreateEditMasterBrandViewModel viewModel = new CreateEditMasterBrandViewModel();
        //    return viewModel;
        //}

        ////Edit method for edited MasterBrand
        //public CreateEditMasterBrandViewModel GetCreateEdit(string masterBrandNo)
        //{
        //    var mb = repository.GetMasterBrand(masterBrandNo);
        //    CreateEditMasterBrandViewModel viewModel = new CreateEditMasterBrandViewModel();

        //    viewModel.Id = mb.Id;
        //    viewModel.VendorID = mb.VendorID;
        //    viewModel.ItemMasterBrand = mb.ItemMasterBrand;
        //    viewModel.IsActive = mb.IsActive;

        //    return viewModel;
        //}

        ////Delete method for one MasterBrand
        //public ProcessResult GetDelete(int IDMasterBrand)
        //{
        //    try
        //    {
        //        repository.DeleteMasterBrand(IDMasterBrand);
        //        result.DeleteSucceed();
        //    }
        //    catch (Exception error)
        //    {
        //        result.ProcessFailed(error.Message);
        //    }
        //    return result;
        //}

        ////Save method for saving new MasterBrand
        //public ProcessResult SaveMasterBrand(CreateEditMasterBrandViewModel model, string userLogin)
        //{
        //    try
        //    {
        //        if (model.Id == 0)
        //        {
        //            repository.InsertMasterBrand(model, userLogin);
        //            result.InsertSucceed();
        //        }
        //        else
        //        {
        //            repository.UpdateMasterBrand(model);
        //            result.UpdateSucceed();
        //        }
        //    }
        //    catch (Exception error)
        //    {
        //        result.ProcessFailed(error.Message);
        //    }
        //    return result;
        //}
    }
}
