﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.MasterBrands;
using ViewModels.ProcessResult;

namespace Providers.MasterBrands
{
    public class MasterBrandRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all MasterBrand from DB
        public IEnumerable<mt_MasterBrand> AllMasterBrand()
        {
            return entities.mt_MasterBrand;
        }

        //Get selected MasterBrand
        public mt_MasterBrand GetMasterBrand(string vendorNo, string masterBrand)
        {
            return entities.mt_MasterBrand.SingleOrDefault(m => m.VendorNo == vendorNo && m.MasterBrand == masterBrand);
        }

        //Delete using Json
        public int GetDeleteMasterBrand(string vendorNo, string masterBrand)
        {
            return entities.mt_MasterBrand.Where(m => m.VendorNo == vendorNo && m.MasterBrand == masterBrand).Count();
        }

        ////Insert new MasterBrand
        //public void InsertMasterBrand(CreateEditMasterBrandViewModel model, string userLogon)
        //{
        //    //get latest ID for auto generate
        //    //var latestID = entities.mt_MasterBrand.OrderByDescending(m => m.VendorID).FirstOrDefault();
        //    //int counterID = Convert.ToInt32(latestID.Code.Substring(3, 3)) + 1;

        //    try
        //    {
        //        var insertMB = new mt_MasterBrand()
        //        {
        //            Id = model.Id,
        //            VendorID = model.VendorID,
        //            ItemMasterBrand = model.ItemMasterBrand,
        //            IsActive = model.IsActive
        //        };
        //        entities.mt_MasterBrand.Add(insertMB);
        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        ////Update choosen MasterBrand
        //public void UpdateMasterBrand(CreateEditMasterBrandViewModel model)
        //{
        //    try
        //    {
        //        var updateData = entities.mt_MasterBrand.SingleOrDefault(m => m.Id == model.Id);
        //        updateData.VendorID = model.VendorID;
        //        updateData.ItemMasterBrand = model.ItemMasterBrand;
        //        updateData.IsActive = model.IsActive;

        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        ////Delete choosen MasterBrand
        //public void DeleteMasterBrand(int IDMasterBrand)
        //{
        //    try
        //    {
        //        var deleteMB = entities.mt_MasterBrand.SingleOrDefault(m => m.Id == IDMasterBrand);
        //        entities.mt_MasterBrand.Remove(deleteMB);
        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}
    }
}
