﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.SuggestDocStatuss;
using ViewModels.ProcessResult;

namespace Providers.SuggestDocStatuss
{
    public class SuggestDocStatusRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all Status from DB
        public IEnumerable<mt_SuggestDocStatus> AllStatus()
        {
            return entities.mt_SuggestDocStatus;
        }

        //Get selected Status
        public mt_SuggestDocStatus GetStatus(string DocStatus)
        {
            return entities.mt_SuggestDocStatus.SingleOrDefault(m => m.SuggestDocStatus == DocStatus);
        }

        //Get Status for IC
        public IEnumerable<mt_SuggestDocStatus> GetStatusForIC()
        {
            return entities.mt_SuggestDocStatus.Where(m => m.Department == "IC" && m.IsActive == true);
        }

        //Get Status for MD
        public IEnumerable<mt_SuggestDocStatus> GetStatusForMD()
        {
            return entities.mt_SuggestDocStatus.Where(m => m.Department == "MD" && m.IsActive == true);
        }

        //Get Status for MD
        public IEnumerable<mt_SuggestDocStatus> GetStatusForImport()
        {
            return entities.mt_SuggestDocStatus.Where(m => m.Department == "IM" && m.IsActive == true);
        }

        //Get Status for MD
        public IEnumerable<mt_SuggestDocStatus> GetStatusForDC()
        {
            return entities.mt_SuggestDocStatus.Where(m => m.Department.Contains("DC") && m.IsActive == true);
        }

        //Delete using Json
        public int GetDeleteStatus(string DocStatus)
        {
            return entities.mt_SuggestDocStatus.Where(m => m.SuggestDocStatus == DocStatus).Count();
        }

        //Insert new Status
        public void InsertStatus(CreateEditSuggestDocStatussViewModel model, string userLogon)
        {
            //get latest ID for auto generate
            var latestID = entities.mt_SuggestDocStatus.OrderByDescending(m => m.SuggestDocStatus).FirstOrDefault();
            int counterID = Convert.ToInt32(latestID.SuggestDocStatus.Substring(3, 3)) + 1;

            try
            {
                var insertStatus = new mt_SuggestDocStatus()
                {
                    SuggestDocStatus = model.SuggestDocStatus,
                    Description = model.Description,
                    IsActive = model.IsActive
                };
                entities.mt_SuggestDocStatus.Add(insertStatus);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Update choosen Status
        public void UpdateStatus(CreateEditSuggestDocStatussViewModel model)
        {
            try
            {
                var updateData = entities.mt_SuggestDocStatus.SingleOrDefault(m => m.SuggestDocStatus == model.SuggestDocStatus);
                updateData.Description = model.Description;
                updateData.IsActive = model.IsActive;
                
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        //Delete choosen Status
        public void DeleteStatus(string DocStatus)
        {
            try
            {
                var deleteStatus = entities.mt_SuggestDocStatus.SingleOrDefault(m => m.SuggestDocStatus == DocStatus);
                entities.mt_SuggestDocStatus.Remove(deleteStatus);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
