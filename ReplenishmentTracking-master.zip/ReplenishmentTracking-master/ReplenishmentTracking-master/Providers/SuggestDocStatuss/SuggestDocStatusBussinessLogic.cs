﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.SuggestDocStatuss;
using ViewModels.ProcessResult;
using System.Configuration;

namespace Providers.SuggestDocStatuss
{
    public class SuggestDocStatusBussinessLogic
    {
        private SuggestDocStatusRepository repository = new SuggestDocStatusRepository();
        private ProcessResult result = new ProcessResult();

        //Get Status list to display
        public List<SuggestDocStatussViewModel> List(IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from stat in repository.AllStatus()
                        where stat.SuggestDocStatus.ToString().Contains(IdFilter == null ? "" : IdFilter.Value.ToString())
                        select new SuggestDocStatussViewModel()
                        {
                            SuggestDocStatus = stat.SuggestDocStatus,
                            Description = stat.Description,
                            Department = stat.Department,
                            AuditActivity = Convert.ToChar(stat.AuditActivity),
                            AuditDateTime = stat.AuditDateTime,
                            AuditUsername = stat.AuditUsername,
                            IsActive = stat.IsActive
                        };
            return query.ToList();
        }

        //Create method for new status
        public CreateEditSuggestDocStatussViewModel GetCreateEdit()
        {
            CreateEditSuggestDocStatussViewModel viewModel = new CreateEditSuggestDocStatussViewModel();
            return viewModel;
        }

        //Edit method for edited status
        public CreateEditSuggestDocStatussViewModel GetCreateEdit(string SuggestDocStatus)
        {
            var status = repository.GetStatus(SuggestDocStatus);
            CreateEditSuggestDocStatussViewModel viewModel = new CreateEditSuggestDocStatussViewModel();

            viewModel.SuggestDocStatus = status.SuggestDocStatus;
            viewModel.Description = status.Description;
            viewModel.Department = status.Department;
            viewModel.IsActive = status.IsActive;

            return viewModel;
        }

        //Delete method for one status
        public ProcessResult GetDelete(string SuggestDocStatus)
        {
            try
            {
                repository.DeleteStatus(SuggestDocStatus);
                result.DeleteSucceed();
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

        //Save method for saving new status
        public ProcessResult SaveStatus(CreateEditSuggestDocStatussViewModel model, string userLogin)
        {
            try
            {
                if (model.SuggestDocStatus == "" || model.SuggestDocStatus == string.Empty)
                {
                    repository.InsertStatus(model, userLogin);
                    result.InsertSucceed();
                }
                else
                {
                    repository.UpdateStatus(model);
                    result.UpdateSucceed();
                }
            }
            catch (Exception error)
            {
                result.ProcessFailed(error.Message);
            }
            return result;
        }

    }
}
