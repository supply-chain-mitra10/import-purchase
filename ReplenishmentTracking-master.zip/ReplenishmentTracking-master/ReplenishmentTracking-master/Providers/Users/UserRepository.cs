﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.ProcessResult;


namespace Providers.Users
{
    public class UserRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        //Get all user from DB
        public IEnumerable<mt_User> AllUser()
        {
            return entities.mt_User;
        }

        //Get selected User
        public mt_User GetUserByUserID(string userID)
        {
            return entities.mt_User.SingleOrDefault(m => m.UserId == userID);
        }
        public mt_User GetUserByUsernameAndPass(string userName, string pass)
        {
            return entities.mt_User.FirstOrDefault(a => a.Username.Equals(userName) && a.Password.Equals(pass));
        }

        //Delete using Json
        public int GetDeleteUser(string userID)
        {
            return entities.mt_User.Where(m => m.UserId == userID).Count();
        }

        ////Insert new User
        //public void InsertUser(CreateEditUserViewModel model, string userLogon)
        //{
        //    //get latest ID for auto generate
        //    var latestID = entities.mt_User.OrderByDescending(m => m.User_ID).FirstOrDefault();
        //    int counterID = Convert.ToInt32(latestID.User_ID.Substring(3, 3)) + 1;

        //    try
        //    {
        //        var insertUser = new mt_User()
        //        {
        //            Id = model.Id,
        //            User_ID = "IPT"+counterID.ToString().PadLeft(3,'0'),
        //            Username = model.Username,
        //            Email = model.Email,
        //            Phone = model.Phone,
        //            Password = Crypto.GenerateSHA512String(model.Password),
        //            Role = Convert.ToInt32(model.Role),
        //            Device_ID = model.DeviceID,
        //            RefereshToken = model.RefreshToken,
        //            InvalidLogin = model.InvalidLogin,
        //            Status = model.Status,
        //            JoinAt = model.JoinAt,
        //            ExpiredAt = Convert.ToDateTime(model.JoinAt).AddYears(5),
        //            CreatedDate = DateTime.Now,
        //            UpdatedDate = DateTime.Now,
        //            LastUpdatedDate = DateTime.Now,
        //            CreatedBy = userLogon,
        //            IsActive = true
        //        };
        //        entities.mt_User.Add(insertUser);
        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        ////Update choosen user
        //public void UpdateUser(CreateEditUserViewModel model)
        //{
        //    try
        //    {
        //        var updateData = entities.mt_User.SingleOrDefault(m => m.User_ID == model.UserID);
        //        updateData.Username = model.Username;
        //        updateData.Email = model.Email;
        //        updateData.Phone = model.Phone;
        //        updateData.Password = Crypto.GenerateSHA512String(model.Password);
        //        updateData.Role = Convert.ToInt32(model.Role);
        //        updateData.Device_ID = model.DeviceID;
        //        updateData.RefereshToken = model.RefreshToken;
        //        updateData.InvalidLogin = model.InvalidLogin;
        //        updateData.Status = model.Status;
        //        updateData.JoinAt = model.JoinAt;
        //        updateData.ExpiredAt = Convert.ToDateTime(model.JoinAt).AddYears(5);
        //        updateData.UpdatedDate = DateTime.Now;
        //        updateData.LastUpdatedDate = DateTime.Now;
        //        updateData.CreatedBy = (model.CreatedBy == ""||model.CreatedBy == null)? "UNKOWN": model.CreatedBy;
        //        updateData.IsActive = model.IsActive;

        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        ////Delete choosen user
        //public void DeleteUser(string IDUser)
        //{
        //    try
        //    {
        //        var deleteUser = entities.mt_User.SingleOrDefault(m => m.User_ID == IDUser);
        //        entities.mt_User.Remove(deleteUser);
        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

    }
}
