﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Web.Mvc;
using Providers.Branchs;
using Providers.Companys;
using ViewModels.Users;
using ViewModels.ProcessResult;

namespace Providers.Users
{
    public class UserBussinessLogic
    {
        private UserRepository repository = new UserRepository();
        private BranchRepository repoBranch = new BranchRepository();
        private CompanyRepository repoCompany = new CompanyRepository();
        private ProcessResult result = new ProcessResult();

        //Get user list to display
        public List<UserViewModel> List(ViewModels.Users.IndexViewModel model, int? page = null, int? IdFilter = null)
        {
            int pageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            int pageNumber = page == null ? 1 : page.Value;

            var query = from user in repository.AllUser()
                        where user.UserId.ToString().Contains(IdFilter == null ? "" : IdFilter.Value.ToString())
                        select new UserViewModel()
                        {
                            UserId = user.UserId,
                            FirstName = user.FirstName,
                            LastName = user.LastName,
                            Username = user.Username,
                            NIK = user.NIK,
                            Email = user.Email,
                            Phone = user.Phone,
                            Password = user.Password,
                            InvalidLogin = user.InvalidLogin,
                            Status = user.Status,
                            JoinAt = user.JoinAt,
                            ExpiredAt = user.ExpiredAt,
                            UserGroupNo = user.UserGroupNo,
                            CompanyNo = user.CompanyNo,
                            BranchNo = user.BranchNo,
                            AuditActivity = Convert.ToChar(user.AuditActivity),
                            AuditDateTime = user.AuditDateTime,
                            AuditUsername = user.AuditUsername,
                            IsActive = user.IsActive
                        };

            return query.ToList();
        }

        public UserViewModel GetUserDetail(string userID)
        {
            var fData = repository.GetUserByUserID(userID);
            UserViewModel viewModel = new UserViewModel()
            {
                UserId = fData.UserId,
                FirstName = fData.FirstName,
                LastName = fData.LastName,
                Username = fData.Username,
                NIK= fData.NIK,
                UserGroupNo= fData.UserGroupNo,
                CompanyNo= fData.CompanyNo,
                BranchNo= fData.BranchNo,
                AuditActivity= Convert.ToChar(fData.AuditActivity),
                AuditDateTime= fData.AuditDateTime,
                AuditUsername= fData.AuditUsername,
                IsActive= fData.IsActive
            };

            return viewModel;
        }

        ////Create method for new user
        //public CreateEditUserViewModel GetCreateEdit()
        //{
        //    CreateEditUserViewModel viewModel = new CreateEditUserViewModel();
        //    return viewModel;
        //}

        ////Edit method for edited user
        //public CreateEditUserViewModel GetCreateEdit(string UserID)
        //{
        //    var user = repository.GetUser(UserID);
        //    CreateEditUserViewModel viewModel = new CreateEditUserViewModel();

        //    viewModel.Id = user.Id;
        //    viewModel.UserID = user.User_ID;
        //    viewModel.Username = user.Username;
        //    viewModel.Email = user.Email;
        //    viewModel.Phone = user.Phone;
        //    viewModel.Password = user.Password;
        //    viewModel.Role = user.mt_UserGroup.GroupName;
        //    viewModel.DeviceID = user.Device_ID;
        //    viewModel.RefreshToken = user.RefereshToken;
        //    viewModel.InvalidLogin = user.InvalidLogin;
        //    viewModel.Status = user.Status;
        //    viewModel.JoinAt = user.JoinAt;

        //    return viewModel;
        //}

        ////Delete method for one user
        //public ProcessResult GetDelete(string UserID)
        //{
        //    try
        //    {
        //        repository.DeleteUser(UserID);
        //        result.DeleteSucceed();
        //    }
        //    catch (Exception error)
        //    {
        //        result.ProcessFailed(error.Message);
        //    }
        //    return result;
        //}

        ////Save method for saving new user
        //public ProcessResult SaveUser(CreateEditUserViewModel model, string userLogin)
        //{
        //    try
        //    {
        //        if (model.Id == 0)
        //        {
        //            repository.InsertUser(model, userLogin);
        //            result.InsertSucceed();
        //        }
        //        else
        //        {
        //            repository.UpdateUser(model);
        //            result.UpdateSucceed();
        //        }
        //    }
        //    catch (Exception error)
        //    {
        //        result.ProcessFailed(error.Message);
        //    }
        //    return result;
        //}

        #region Login
        public UserViewModel GetUserLogged(string userName, string pass)
        {
            var userData = repository.GetUserByUsernameAndPass(userName, pass);
            UserViewModel data = new UserViewModel()
            {
                UserId=userData.UserId,
                Username = userData.Username,
                UserGroupNo=userData.UserGroupNo,
                CompanyNo=userData.CompanyNo,
                BranchNo=userData.BranchNo,
                IsActive=userData.IsActive
            };

            return data;
        }
        #endregion

        #region DropDown
        //-- Helper Method -----------------------------------------------------------------
        //Get data for Company drop down list
        public IEnumerable<SelectListItem> GetListCompany()
        {
            var ListStatus = from com in repoCompany.AllCompany()
                             select new SelectListItem()
                             {
                                 Value = com.CompanyNo,
                                 Text = com.CompanyName
                             };
            return ListStatus;
        }

        //Get data for Branch/Location drop down list
        public IEnumerable<SelectListItem> GetListLocation()
        {
            var ListSupplier = from loc in repoBranch.AllBranch()
                               select new SelectListItem()
                               {
                                   Value = loc.BranchNo,
                                   Text = loc.BranchNo + " - " + loc.BranchName
                               };
            return ListSupplier;
        }
        #endregion
    }
}
