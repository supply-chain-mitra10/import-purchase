﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using ViewModels.Commons;
using ViewModels.Dashboards;
using ViewModels.ProcessResult;

namespace Providers.Dashboards
{
    public class DashboardRepository
    {
        private REPLENISHMENTEntities entities = new REPLENISHMENTEntities();
        private ProcessResult result = new ProcessResult();

        public DashboardViewModel GetCountAllStat()
        {
            var dashboardCount = new DashboardViewModel()
            {
                TotalNew = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.New).Count(),
                TotalOpen = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.Open).Count(),
                TotalReject = entities.tr_SuggestHeader.Where(m => m.IsActive == false && m.SuggestDocStatus == SuggestDocStatus.Reject).Count(),
                TotalConfirm = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.Confirm).Count(),
                TotalApprove = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.ApprovedbyMD).Count(),
                TotalRevise = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.Revise).Count(),
                TotalRelease = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.Release).Count(),
                TotalClose = entities.tr_SuggestHeader.Where(m => m.IsActive == false && m.SuggestDocStatus == SuggestDocStatus.Close).Count(),
                TotalWait = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.WaitingICApproval).Count(),
                TotalSubmit = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.SubmittoFinance).Count(),
                TotalReturn = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.ReceivefromFinance).Count(),
                TotalLC = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.PaymentLC).Count(),
                TotalReceived = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.GoodsReceived).Count(),
                TotalOpenIM = entities.tr_SuggestHeader.Where(m => m.IsActive == true && m.SuggestDocStatus == SuggestDocStatus.OpenImport).Count()
            }; 
            return dashboardCount;
        } 
               
        public tr_SuggestHeader_Hist GetHistory(string suggestDocNoHist)
        {
            return entities.tr_SuggestHeader_Hist.SingleOrDefault(m => m.SuggestDocNo == suggestDocNoHist);
        }

        //Delete using Json
        public int GetDeleteHistory(string suggestDocNoHist)
        {
            return entities.tr_SuggestHeader_Hist.Where(m => m.SuggestDocNo == suggestDocNoHist).Count();
        }

        ////Insert new History
        //public void InsertUser(CreateEditUserViewModel model, string userLogon)
        //{
        //    //get latest ID for auto generate
        //    var latestID = entities.mt_User.OrderByDescending(m => m.User_ID).FirstOrDefault();
        //    int counterID = Convert.ToInt32(latestID.User_ID.Substring(3, 3)) + 1;

        //    try
        //    {
        //        var insertUser = new mt_User()
        //        {
        //            Id = model.Id,
        //            User_ID = "PIT" + counterID.ToString().PadLeft(3, '0'),
        //            Username = model.Username,
        //            Email = model.Email,
        //            Phone = model.Phone,
        //            Password = Crypto.GenerateSHA512String(model.Password),
        //            Role = Convert.ToInt32(model.Role),
        //            Device_ID = model.DeviceID,
        //            RefereshToken = model.RefreshToken,
        //            InvalidLogin = model.InvalidLogin,
        //            Status = model.Status,
        //            JoinAt = model.JoinAt,
        //            ExpiredAt = Convert.ToDateTime(model.JoinAt).AddYears(5),
        //            CreatedDate = DateTime.Now,
        //            UpdatedDate = DateTime.Now,
        //            LastUpdatedDate = DateTime.Now,
        //            CreatedBy = userLogon,
        //            IsActive = true
        //        };
        //        entities.mt_User.Add(insertUser);
        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        ////Update choosen user
        //public void UpdateUser(CreateEditUserViewModel model)
        //{
        //    try
        //    {
        //        var updateData = entities.mt_User.SingleOrDefault(m => m.User_ID == model.UserID);
        //        updateData.Username = model.Username;
        //        updateData.Email = model.Email;
        //        updateData.Phone = model.Phone;
        //        updateData.Password = Crypto.GenerateSHA512String(model.Password);
        //        updateData.Role = Convert.ToInt32(model.Role);
        //        updateData.Device_ID = model.DeviceID;
        //        updateData.RefereshToken = model.RefreshToken;
        //        updateData.InvalidLogin = model.InvalidLogin;
        //        updateData.Status = model.Status;
        //        updateData.JoinAt = model.JoinAt;
        //        updateData.ExpiredAt = Convert.ToDateTime(model.JoinAt).AddYears(5);
        //        updateData.UpdatedDate = DateTime.Now;
        //        updateData.LastUpdatedDate = DateTime.Now;
        //        updateData.CreatedBy = (model.CreatedBy == "" || model.CreatedBy == null) ? "UNKOWN" : model.CreatedBy;
        //        updateData.IsActive = model.IsActive;

        //        entities.SaveChanges();
        //    }
        //    catch (Exception error)
        //    {
        //        throw error;
        //    }
        //}

        //Delete choosen user
        public void DeleteHistory(string suggestDocNoHist)
        {
            try
            {
                var deleteHist = entities.tr_SuggestHeader_Hist.SingleOrDefault(m => m.SuggestDocNo == suggestDocNoHist);
                entities.tr_SuggestHeader_Hist.Remove(deleteHist);
                entities.SaveChanges();
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
