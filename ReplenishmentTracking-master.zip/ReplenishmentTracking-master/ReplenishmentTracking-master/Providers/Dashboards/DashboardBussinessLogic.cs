﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.Dashboards;
using ViewModels.InventoryControls;

namespace Providers.Dashboards
{
    public class DashboardBussinessLogic
    {
        private DashboardRepository repository = new DashboardRepository();

        public DashboardViewModel GetDashboard()
        {
            var fData = repository.GetCountAllStat();
            return fData;
        }
    }
}
